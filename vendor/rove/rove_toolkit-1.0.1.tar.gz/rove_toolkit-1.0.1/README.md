# Rove

> Cross-platform peer-built signed wheelhouse forge — ship Python+native code to any device the mesh can reach.

**Status**: Stable · v1.0.0 · [CHANGELOG](CHANGELOG.md)

## What it is

Rove builds reproducible, Ed25519-signed Python wheelhouses for any target platform — including the painful ones (Android/Termux, embedded ARM, musl/bionic) — and ships them peer-to-peer through a pluggable distribution layer.

It exists because the state of the art for shipping Python+Rust+C apps to non-mainstream targets is a graveyard of one-off patches: `psutil` rejects Android in `setup.py`, `cryptography` needs a 15-minute Rust build, `pydantic-core` needs `ANDROID_API_LEVEL` set just so. Rove turns those one-off patches into versioned, signed, distributable artifacts that the next builder doesn't have to rediscover.

## Why it's different

- **Cross-compile via Zig 0.14**: covers ~70% of native deps cleanly (glibc/musl/bionic) without per-target sysroots.
- **Patch registry**: companion repo [`rove-patches`](https://github.com/GredInLabsTechnologies/rove-patches) carries the long-tail fixes (`.patch` + `.env` + `.toml`) with metadata `(pkg, version_range, target)`. Apply automatically pre-build.
- **Ed25519-signed manifests** with key rotation support. No silent supply-chain risk.
- **Pluggable distribution**: HTTP server out of the box; plug in Iroh content-addressed P2P, mesh-native delivery, S3, scp, whatever your project needs.

## Install

```bash
pip install rove-toolkit
```

## Quick start

The flow below is the **exact** end-to-end smoke test we run before every release. Copy-paste runs as-is from a fresh clone of this repo (any OS). It builds Rove against itself, so you can verify the full pipeline without inventing a project first.

```bash
# 0. One-time setup
git clone https://github.com/GredInLabsTechnologies/rove.git
cd rove
python -m venv .venv
. .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -e .[dev]

# 1. Generate a signing keypair (one-time)
rove keygen --out ./keys/

# 2. Build a wheelhouse for the current host
rove build --target host --output ./dist/ --no-python

# 3. Sign it (the bundle is named rove-<os>-<arch>-1.0.0.tar.xz)
BUNDLE=$(ls ./dist/rove-*-1.0.0.tar.xz | head -1)
rove sign --bundle "$BUNDLE" --key ./keys/private.pem

# 4. Verify on the consumer side
rove verify --bundle "$BUNDLE" --pubkey ./keys/public.pem

# 5. Serve over HTTP for peers to fetch
rove serve --bundle-dir ./dist/ --port 8080 &
SERVER_PID=$!

# 6. Fetch on another machine (or the same box for the smoke test)
rove fetch --from http://127.0.0.1:8080 \
  --target host \
  --project-name rove --runtime-version 1.0.0 \
  --out ./fetched/ \
  --pubkey ./keys/public.pem

kill $SERVER_PID
```

All steps succeed on Linux/macOS/Windows with Python 3.11.4+, 3.12, or 3.13. The CI matrix covers all combinations on every push.

## Configuration

Add a `[tool.rove]` section to your `pyproject.toml`:

```toml
[tool.rove]
project_name = "myapp"
include = ["src/myapp", "data/"]
exclude = ["tests/", "*.pyc"]
targets = ["host", "android-arm64", "linux-x86_64"]
patches = ["python-bionic"]
sign_key = "${ROVE_SIGN_KEY_PATH}"
```

## Targets

| Target | Status |
|---|---|
| `host` | ✅ |
| `linux-x86_64` | ✅ |
| `linux-arm64` | ✅ |
| `darwin-x86_64` | ✅ |
| `darwin-arm64` | ✅ |
| `windows-x86_64` | ✅ |
| `android-arm64` | 🟡 alpha (with `rove-patches`) |
| `android-armv7` | 🟡 alpha |

## Documentation

| Doc | Covers |
|---|---|
| [`docs/COMMANDS.md`](docs/COMMANDS.md) | Every CLI subcommand, flag, exit code + worked examples. |
| [`docs/CONFIG.md`](docs/CONFIG.md) | Full `[tool.rove]` schema with validator rules. |
| [`docs/MANIFEST.md`](docs/MANIFEST.md) | Wire format of the signed manifest — re-implementable in any language. |
| [`docs/SECURITY.md`](docs/SECURITY.md) | Threat model, in-scope / out-of-scope attacks, key-rotation runbook. |
| [`docs/LIBRARY.md`](docs/LIBRARY.md) | Python library API (every public name, error taxonomy, stability rules). |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | Internal design, distribution plugin protocol, patch registry contract. |
| [`CHANGELOG.md`](CHANGELOG.md) | Release history, security advisories, migration notes. |
| [`CONTRIBUTING.md`](CONTRIBUTING.md) | Ground rules + local gates + end-to-end smoke test. |

## License

[MIT](LICENSE) © Gred In Labs Technologies

"""Tests for :mod:`rove.signing.keygen`."""
from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

from rove.signing import keygen


class TestGenerateInMemory:
    def test_returns_two_bytes(self) -> None:
        priv, pub = keygen.generate_inmemory()
        assert isinstance(priv, bytes)
        assert isinstance(pub, bytes)

    def test_pem_headers_present(self) -> None:
        priv, pub = keygen.generate_inmemory()
        assert b"BEGIN PRIVATE KEY" in priv
        assert b"END PRIVATE KEY" in priv
        assert b"BEGIN PUBLIC KEY" in pub
        assert b"END PUBLIC KEY" in pub

    def test_consecutive_calls_yield_distinct_keys(self) -> None:
        priv_a, pub_a = keygen.generate_inmemory()
        priv_b, pub_b = keygen.generate_inmemory()
        assert priv_a != priv_b
        assert pub_a != pub_b


class TestGenerateKeypair:
    def test_writes_both_files(self, tmp_path: Path) -> None:
        out = tmp_path / "keys"
        priv_path, pub_path = keygen.generate_keypair(out)
        assert priv_path.exists()
        assert pub_path.exists()
        assert priv_path.name == "private.pem"
        assert pub_path.name == "public.pem"

    def test_files_have_pem_content(self, tmp_path: Path) -> None:
        priv_path, pub_path = keygen.generate_keypair(tmp_path / "k")
        assert b"BEGIN PRIVATE KEY" in priv_path.read_bytes()
        assert b"BEGIN PUBLIC KEY" in pub_path.read_bytes()

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        nested = tmp_path / "a" / "b" / "c"
        priv_path, _pub_path = keygen.generate_keypair(nested)
        assert priv_path.parent == nested.resolve()

    def test_refuses_overwrite_by_default(self, tmp_path: Path) -> None:
        out = tmp_path / "keys"
        keygen.generate_keypair(out)
        with pytest.raises(FileExistsError):
            keygen.generate_keypair(out)

    def test_overwrite_true_replaces_files(self, tmp_path: Path) -> None:
        out = tmp_path / "keys"
        priv_a, _ = keygen.generate_keypair(out)
        priv_a_bytes = priv_a.read_bytes()
        priv_b, _ = keygen.generate_keypair(out, overwrite=True)
        priv_b_bytes = priv_b.read_bytes()
        assert priv_a_bytes != priv_b_bytes

    def test_returns_absolute_paths(self, tmp_path: Path) -> None:
        priv_path, pub_path = keygen.generate_keypair(tmp_path / "k")
        assert priv_path.is_absolute()
        assert pub_path.is_absolute()

    @pytest.mark.skipif(os.name != "posix", reason="POSIX file mode test")
    def test_private_key_mode_0o600(self, tmp_path: Path) -> None:
        priv_path, _ = keygen.generate_keypair(tmp_path / "k")
        mode = stat.S_IMODE(priv_path.stat().st_mode)
        assert mode == 0o600

    @pytest.mark.skipif(os.name != "posix", reason="POSIX file mode test")
    def test_public_key_mode_0o644(self, tmp_path: Path) -> None:
        _, pub_path = keygen.generate_keypair(tmp_path / "k")
        mode = stat.S_IMODE(pub_path.stat().st_mode)
        assert mode == 0o644

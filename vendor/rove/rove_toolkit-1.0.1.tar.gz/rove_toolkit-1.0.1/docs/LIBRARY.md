# Rove library API reference

`pip install rove-toolkit` gives you both the `rove` CLI and a Python library. The library exposes every surface the CLI uses — if the CLI can do it, you can do it from Python without invoking a subprocess.

## Package layout

```
rove/
├── manifest.py                     WheelhouseManifest (Pydantic wire contract)
├── targets.py                      Target enum, parse(), resolve(), detect_host()
├── config.py                       RoveConfig, load()
├── signing/
│   ├── ed25519.py                 sign, verify, sign_manifest, verify_manifest, sha256_file, RuntimeSignatureError
│   └── keygen.py                  generate_inmemory, generate_keypair
├── builder/
│   ├── tarball.py                 TarballBuildOptions, build_tarball, TarballBuildError
│   ├── pip_runner.py              PipRunOptions, run_pip_download, PipError
│   ├── python_standalone.py       fetch_standalone_python, StandaloneFetchError
│   ├── zig.py                     discover_toolchain, build_env_for, ZigNotFoundError
│   └── patches.py                 apply_env_patches, apply_unified_diff, read_toml_overrides, apply_all, PatchApplyError
├── patches/
│   └── loader.py                  PatchSet, PatchEntry, PatchKind, load_patch_set, resolve_patches, PatchLoadError
├── distribution/
│   ├── plugin.py                  DistributionBackend (Protocol), DistributionError
│   ├── http_server.py             HttpServerOptions, RoveHttpServer, NoFQDNThreadingHTTPServer, serve
│   └── http_fetcher.py            FetchOptions, FetchResult, fetch_bundle, HttpDistributionBackend
└── cli.py                          Typer entrypoint (rove.cli:main)
```

All public names are type-annotated; `mypy --strict` clean.

---

## Quickstart: build → sign → verify in Python

```python
from pathlib import Path
from rove.signing.keygen import generate_keypair
from rove.signing.ed25519 import sign_manifest, verify_manifest
from rove.targets import Target, resolve
from rove.builder.tarball import TarballBuildOptions, build_tarball

work = Path("./work"); work.mkdir(exist_ok=True)

# 1. Keypair
priv, pub = generate_keypair(work / "keys")

# 2. Build a wheelhouse tarball
result = build_tarball(
    TarballBuildOptions(
        project_name="myapp",
        runtime_version="0.1.0",
        target=resolve(Target.host),
        output_dir=work / "dist",
        wheels_dir=work / "wheels",   # populated by rove.builder.pip_runner
        project_root=Path("./src/myapp"),
        include=["."],
    )
)
print("built:", result.tarball_path, "sha256:", result.manifest.tarball_sha256)

# 3. Sign
signed_manifest = sign_manifest(result.manifest, priv)

# 4. Verify (any downstream consumer)
assert verify_manifest(signed_manifest, additional_keys=[pub])
```

---

## `rove.manifest`

### `WheelhouseManifest`

Pydantic model. Every field documented in [`MANIFEST.md`](MANIFEST.md).

```python
from rove.manifest import WheelhouseManifest

m = WheelhouseManifest.model_validate_json(sidecar_path.read_bytes())
assert m.target.value == "linux-x86_64"
signed_bytes = m.signing_payload()  # the exact bytes under the Ed25519 signature
```

### `signing_payload()`

Returns the canonical `<sha256>|<target>|<version>|<project_name>` byte string. Useful when re-verifying via a language other than Python — see [`MANIFEST.md`](MANIFEST.md#canonical-signing-payload).

---

## `rove.targets`

```python
from rove.targets import Target, parse, detect_host, resolve

Target.linux_x86_64            # StrEnum member
Target.linux_x86_64.value       # "linux-x86_64"

parse("android-aarch64")        # Target.android_arm64 (alias normalisation)
detect_host()                   # Target.linux_x86_64 (or whatever the running box is)
resolve(Target.host)            # detect_host() — safe to call unconditionally
```

`parse` is case-insensitive and accepts a curated alias set (see `rove.targets._ALIASES` in source). To extract the OS family from a target, use the string prefix: ``target.value.split("-", 1)[0]``.

---

## `rove.signing.ed25519`

All five public functions share a single `KeyInput` type alias: **any of** raw PEM bytes, PEM string, or `pathlib.Path` to a PEM file.

```python
from rove.signing.ed25519 import (
    sign, verify, sign_manifest, verify_manifest, sha256_file,
    RuntimeSignatureError,
)

# Low-level
sig_hex = sign(payload=b"arbitrary bytes", private_key_pem=Path("./keys/private.pem"))
assert verify(b"arbitrary bytes", sig_hex, additional_keys=[Path("./keys/public.pem")])

# Manifest-level (most common)
signed = sign_manifest(manifest, Path("./keys/private.pem"))
assert verify_manifest(signed, additional_keys=[Path("./keys/public.pem")])

# Hash utility (pure, no network, no state)
digest = sha256_file(Path("./dist/myapp.tar.xz"))
```

**Trust resolution** for `verify` / `verify_manifest`:

1. `ROVE_TRUSTED_PUBKEYS` env var — comma-separated entries (PEM blocks with `\n`-escaped newlines, or base64 of 32-byte raw keys).
2. `*.pem` files in `~/.config/rove/trusted_keys/`.
3. The explicit `additional_keys` kwarg.

If zero sources yield a key, `RuntimeSignatureError` is raised. Otherwise `verify` returns `True` on first match, `False` if no key validates.

---

## `rove.signing.keygen`

```python
from rove.signing.keygen import generate_inmemory, generate_keypair

# On-disk
priv_path, pub_path = generate_keypair(Path("./keys"), overwrite=False)

# In-memory (no disk side effect)
priv_pem, pub_pem = generate_inmemory()
```

See [`SECURITY.md`](SECURITY.md#generation) for the Windows ACL behaviour.

---

## `rove.builder.tarball`

```python
from rove.builder.tarball import TarballBuildOptions, build_tarball, TarballBuildError

try:
    result = build_tarball(
        TarballBuildOptions(
            project_name="myapp",
            runtime_version="0.1.0",
            target=Target.linux_x86_64,
            output_dir=Path("./dist"),
            wheels_dir=Path("./wheels"),
            project_root=Path("./src/myapp"),
            compression=Compression.xz,
            include=["src", "data"],
            exclude=["tests/", "*.pyc", "__pycache__/"],
            python_root=Path("./python"),        # optional — bundle a CPython tree
            patches_applied=["python-bionic"],    # audit trail; recorded in manifest
        )
    )
except TarballBuildError as exc:
    print("build failed:", exc)
```

`result` is a `TarballBuildResult` with `tarball_path`, `manifest` (unsigned — `signature` is the placeholder `"0" * 128`), `compressed_size_bytes`, `uncompressed_size_bytes`.

The tarball is **deterministic** — same inputs → byte-identical output.

---

## `rove.builder.pip_runner` / `python_standalone` / `zig` / `patches`

Lower-level builder primitives used by the CLI's `build` subcommand. See the module docstrings in source. Typical usage:

```python
from rove.builder.python_standalone import fetch_standalone_python
from rove.builder.pip_runner import PipRunOptions, run_pip_download

python_root = fetch_standalone_python(Target.linux_x86_64)  # idempotent cache

wheels_dir = Path("./wheels"); wheels_dir.mkdir(exist_ok=True)
run_pip_download(
    PipRunOptions(
        requirements=["cryptography>=43.0.0", "pydantic>=2.11"],
        target=Target.linux_x86_64,
        python_executable=python_root / "bin/python3",
        output_dir=wheels_dir,
        prefer_binary=True,
    )
)
```

---

## `rove.distribution.http_server`

```python
from rove.distribution.http_server import HttpServerOptions, RoveHttpServer

with RoveHttpServer(
    HttpServerOptions(bundle_dir=Path("./dist"), host="0.0.0.0", port=8080)
) as server:
    print("serving on", server.url())
    # ... server runs in a daemon thread ...
# automatic stop() on context exit
```

`NoFQDNThreadingHTTPServer` is exported for tests that need to spin up their own auxiliary HTTP server while avoiding the `socket.getfqdn('127.0.0.1')` hang on macOS CI runners.

---

## `rove.distribution.http_fetcher`

```python
from rove.distribution.http_fetcher import FetchOptions, fetch_bundle, HttpDistributionBackend

result = fetch_bundle(
    FetchOptions(
        source="http://192.168.0.16:8080",
        bundle_name="myapp-linux-x86_64-0.1.0.tar.xz",
        output_dir=Path("./fetched"),
        additional_pubkeys=[Path("./keys/public.pem")],
        expected_sha256=None,   # Fall back to manifest's value. Set explicitly for pinned fetches.
    )
)
print("fetched:", result.bundle_path, "from_cache:", result.from_cache)
```

### Protocol: `DistributionBackend`

Third parties can drop in their own transport by implementing this `Protocol`:

```python
from typing import Protocol
from pathlib import Path
from rove.manifest import WheelhouseManifest
from rove.targets import Target

class DistributionBackend(Protocol):
    def publish(self, manifest: WheelhouseManifest, payload: Path) -> str: ...
    def fetch(self, target: Target, version: str | None = None) -> tuple[WheelhouseManifest, Path]: ...
```

`HttpDistributionBackend` in `http_fetcher` is the stock implementation. A mesh-native backend (Iroh, BitTorrent, S3, scp) can be written without touching Rove core — it just needs to satisfy the `Protocol`.

---

## Error taxonomy

Every public function surfaces a domain exception. No `OSError` / `URLError` / `ValueError` leaks past the boundary.

| Exception | Module | Raised by |
|---|---|---|
| `DistributionError` | `rove.distribution.plugin` | fetcher (transport, size caps, scheme, redirect, sha mismatch), server (bundle_dir missing/empty). |
| `RuntimeSignatureError` | `rove.signing.ed25519` | sign/verify (malformed PEM, non-hex signature, no trusted keys). |
| `TarballBuildError` | `rove.builder.tarball` | build (missing wheels_dir, missing project_root, unsupported compression). |
| `PipError` | `rove.builder.pip_runner` | pip download non-zero exit. |
| `StandaloneFetchError` | `rove.builder.python_standalone` | Download / verify / extract failure. Android raises `NotImplementedError` directly. |
| `ZigNotFoundError` | `rove.builder.zig` | `zig` not on PATH. |
| `PatchApplyError` | `rove.builder.patches` | env patch parse, diff subprocess, TOML parse. |
| `PatchLoadError` | `rove.patches.loader` | missing manifest, sha mismatch, schema violation. |
| `ConfigError` | `rove.config` | validation / env-var expansion / bad toml. |

Every one of these is a `RuntimeError` subclass (or `ValueError` for `ConfigError`), so a broad `except RuntimeError` in a wrapper still catches them — but the domain-specific type is always preferable.

---

## Stability

All names listed in a module's `__all__` are **public**. They follow SemVer:

- Bug-fix release (`0.1.x`): behaviour preserved, signatures unchanged.
- Minor release (`0.x.0`): additive only. Optional kwargs may be introduced with sensible defaults.
- Major release (`x.0.0`): breaking changes require a migration note in [`CHANGELOG.md`](../CHANGELOG.md).

Names starting with `_` are **private** — free to change in any release.

The `signing_payload()` format is a wire contract (see [`MANIFEST.md`](MANIFEST.md)). It is frozen within a major version; a format change requires a major bump and a migration note in [`CHANGELOG.md`](../CHANGELOG.md). v1.0.0 locked the format at 4 fields (sha256 · target · runtime_version · project_name); pre-1.0 signatures built against the 3-field payload are not cross-verifiable.

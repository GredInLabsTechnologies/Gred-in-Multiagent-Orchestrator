# Rove manifest wire format

The `WheelhouseManifest` is Rove's canonical on-the-wire description of a signed bundle. Defined by the Pydantic model in [`src/rove/manifest.py`](../src/rove/manifest.py), it is stable across releases — the field set may grow (optional additions), but existing fields and their semantics are frozen. Breaking changes require a major version bump and a migration note in [`CHANGELOG.md`](../CHANGELOG.md).

## Purpose

Each signed bundle has two artifacts on disk:

1. `<bundle>.tar.xz` — the deterministic wheelhouse tarball.
2. `<bundle>.tar.xz.manifest.json` — a JSON document conforming to this schema, carrying the Ed25519 signature over the canonical payload.

Consumers (CLI `rove fetch` / `rove verify`, library callers, non-Python consumers like Kotlin or Rust launchers) read the sidecar, verify the signature, recompute the SHA-256 on the tarball, and reject any mismatch.

## Schema

All fields are UTF-8. Path fields are **relative** — leading slashes are stripped, `..` segments are rejected, Windows drive letters and UNC prefixes are rejected.

### Required

| Field | Type | Constraint | Semantics |
|---|---|---|---|
| `project_name` | string | `^[a-z0-9][a-z0-9._-]*$` | Project identifier. |
| `runtime_version` | string | no `\|` | SemVer of the bundle. Cannot contain `\|` because that character is the separator in `signing_payload()`. |
| `target` | string | `rove.targets.Target` enum value | Concrete build target (e.g. `linux-x86_64`). `host` is rejected — callers must resolve before building. |
| `tarball_name` | string | min_length=1, relative | Filename of the associated tarball. |
| `tarball_sha256` | string | `^[0-9a-f]{64}$` | Lowercase-hex SHA-256 of the compressed tarball. |
| `compressed_size_bytes` | int | ≥ 0 | On-disk size of the tarball. Used by `fetch_bundle` to enforce the oversized-payload cap (`* 1.01`). |
| `uncompressed_size_bytes` | int | ≥ 0 | Estimated size of the expanded tree. Informational. |
| `python_rel_path` | string | relative | Path to the bundled CPython binary inside the bundle (e.g. `python/bin/python3`). |
| `project_root_rel_path` | string | relative | Path to the project root inside the bundle (e.g. `project`). |
| `signature` | string | `^[0-9a-f]{128}$` | Lowercase-hex Ed25519 signature over `signing_payload()`. |

### Optional

| Field | Type | Default | Semantics |
|---|---|---|---|
| `compression` | string | `"xz"` | One of `xz`, `zstd`, `none`. |
| `wheels_rel_path` | string | `"wheelhouse"` | Where pre-built wheels live inside the bundle. |
| `python_path_entries` | list[string] | `[]` | Relative paths to prepend to `PYTHONPATH` when the bundle is executed. |
| `files` | list[string] | `[]` | Explicit bundle file list, used for integrity audits (not enforced by `verify_manifest`, informational). |
| `extra_env` | dict[string, string] | `{}` | Extra env vars to set when the bundle is executed. |
| `patches_applied` | list[string] | `[]` | Names of patches from `rove-patches` that were applied pre-build. Audit trail. |
| `python_version` | string or null | `null` | Bundled CPython version (e.g. `3.13.13`). Informational. |
| `built_at` | string or null | `null` | ISO-8601 UTC timestamp of the build. Informational. |
| `builder` | string or null | `null` | Free-form string identifying the build host / CI job. |

## Canonical signing payload

The `signing_payload()` method produces the exact bytes covered by `signature`:

```
<tarball_sha256>|<target>|<runtime_version>|<project_name>
```

UTF-8 encoded, no trailing newline. Example:

```
0048436301c0964af70d36bddbd559f868a23b461af5c639d6bae26be4bc884b|linux-x86_64|0.1.0|myapp
```

`project_name` is part of the payload so that a signer which produces bundles for multiple projects cannot have a signature from project A reused to authenticate a bundle served as project B (same sha/target/version but different identity).

The payload is intentionally trivial so any language can reproduce it:

**Python**:

```python
payload = f"{m.tarball_sha256}|{m.target.value}|{m.runtime_version}|{m.project_name}".encode()
```

**Kotlin** (Android):

```kotlin
val payload = "${m.tarball_sha256}|${m.target}|${m.runtime_version}|${m.project_name}".toByteArray(Charsets.UTF_8)
```

**Rust**:

```rust
let payload = format!(
    "{}|{}|{}|{}",
    m.tarball_sha256, m.target, m.runtime_version, m.project_name,
).into_bytes();
```

**Disambiguation.** `tarball_sha256` is a fixed 64-char lowercase hex string (no `|` possible); `target` is the Rove `Target` StrEnum (no value contains `|`); `runtime_version`'s Pydantic pattern rejects `|`; `project_name`'s pattern (`^[a-z0-9][a-z0-9._-]*$`) also forbids `|`. The 4-tuple is therefore unambiguously reversible — no length-prefix is needed.

## Example manifest

```json
{
  "project_name": "myapp",
  "runtime_version": "0.1.0",
  "target": "linux-x86_64",
  "compression": "xz",
  "tarball_name": "myapp-linux-x86_64-0.1.0.tar.xz",
  "tarball_sha256": "0048436301c0964af70d36bddbd559f868a23b461af5c639d6bae26be4bc884b",
  "compressed_size_bytes": 12458,
  "uncompressed_size_bytes": 47612,
  "python_rel_path": "python/bin/python3",
  "project_root_rel_path": "project",
  "wheels_rel_path": "wheelhouse",
  "python_path_entries": ["project", "wheelhouse"],
  "files": [
    "python/bin/python3",
    "project/src/myapp/__init__.py",
    "project/src/myapp/main.py",
    "wheelhouse/cryptography-46.0.7-cp313-abi3-manylinux2014_x86_64.whl"
  ],
  "extra_env": {"PYTHONDONTWRITEBYTECODE": "1"},
  "patches_applied": [],
  "python_version": "3.13.13",
  "built_at": "2026-04-17T15:18:20Z",
  "builder": "github-actions/workflow=ci/run=24572612394",
  "signature": "f7a1d4bc8e2f9a1b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e"
}
```

## Compatibility

- **Additive changes** (new optional fields) are non-breaking. Consumers using older schemas ignore unknown fields.
- **Semantic changes** to existing fields (format of `signature`, re-interpretation of `tarball_sha256`) require a major version bump and a migration note.
- **Changing `signing_payload()`** is a wire-protocol break — existing signed bundles would stop validating. Any such change requires a deprecation window where `verify_manifest` accepts both old and new payload formats against the same trusted key set.

## Why not JSON-canonicalise the whole manifest?

Because consumers may not all parse JSON the same way (trailing whitespace, key ordering, UTF-8 normalisation, number formatting). Pinning the signed payload to an explicit string triple sidesteps every JSON-canonicalisation rabbit hole. The JSON around it is transport — the cryptographic contract is the payload.

## Related

- Field types / validators: [`src/rove/manifest.py`](../src/rove/manifest.py)
- Target enum: [`src/rove/targets.py`](../src/rove/targets.py)
- Signing primitives: [`src/rove/signing/ed25519.py`](../src/rove/signing/ed25519.py)

# Rove CLI reference

The `rove` executable is the primary user surface. Every subcommand is a thin wrapper over a Python function in `src/rove/` — see [`LIBRARY.md`](LIBRARY.md) for programmatic use.

All commands exit `0` on success, `1` on operational failure, `2` on argument / configuration error.

---

## `rove keygen`

Generate an Ed25519 signing keypair.

```bash
rove keygen --out PATH [--overwrite]
```

| Flag | Required | Description |
|---|---|---|
| `--out` / `-o` | yes | Directory to write `private.pem` + `public.pem`. Created if missing. |
| `--overwrite` | no | Replace existing key files. Default is to refuse and exit 1. |

**File permissions.** On POSIX, `private.pem` is `chmod 0o600` and `public.pem` is `0o644`. On Windows, `private.pem`'s ACL is tightened via `icacls /inheritance:r /grant:r <user>:F` to strip the default `Users:R` inherited entry. If `icacls` is missing or the current `USERNAME` env var is unset, a WARNING is logged and the default ACL is preserved — secure the file manually or reinvoke on a box with `icacls` on PATH.

**Example.**

```bash
rove keygen --out ./keys
# [ok] private key: /abs/path/keys/private.pem
# [ok] public  key: /abs/path/keys/public.pem
```

---

## `rove build`

Assemble a deterministic wheelhouse tarball for a target platform.

```bash
rove build --target TARGET
           [--config PATH]
           [--output DIR]
           [--python-version VER]
           [--patch-set PATH]
           [--no-python]
           [--compression {xz|zstd|none}]
```

| Flag | Required | Description |
|---|---|---|
| `--target` / `-t` | yes | Target tuple. See [Targets](#supported-targets). |
| `--config` / `-c` | no | Path to `rove.toml` or `pyproject.toml`. Auto-detected if omitted. |
| `--output` / `-o` | no | Output directory. Default: `./dist`. |
| `--python-version` | no | Short (`3.13`) or full (`3.13.13`) CPython version. Default: `3.13`. |
| `--patch-set` | no | Path to a local `rove-patches` checkout or its `manifest.json`. |
| `--no-python` | no | Skip fetching `python-build-standalone`. The resulting bundle has no interpreter — useful for host-target smoke tests or when the consumer ships its own Python. |
| `--compression` | no | `xz` (default) / `zstd` / `none`. `zstd` requires the `zstandard` package. |

**Determinism.** Every tarball has normalised metadata: `mtime=0`, `uid=gid=0`, owner names blanked, directory mode `0o755`, file mode `0o644` (executable bit preserved for `python/bin/*`). Two builds of identical source trees produce byte-identical bundles.

**Output.** Two artifacts land in `--output`:

- `<project>-<target>-<version>.tar.xz` — the deterministic bundle.
- `<project>-<target>-<version>.tar.xz.manifest.json` — the unsigned manifest sidecar (signature is a `"0" * 128` placeholder). `rove sign` overwrites this file with the signed version; `rove verify` reads it.

**Example.**

```bash
rove build --target host --output ./dist --no-python
# [ok] target: windows-x86_64  project: myapp
# [ok] skipping python-build-standalone (--no-python)
# [ok] wheels downloaded: 17
# [ok] bundle:   ./dist/myapp-windows-x86_64-0.1.0.tar.xz
```

---

## `rove sign`

Sign an existing bundle's manifest with an Ed25519 private key.

```bash
rove sign --bundle PATH --key PATH [--output PATH]
```

| Flag | Required | Description |
|---|---|---|
| `--bundle` / `-b` | yes | Path to the tarball to sign. |
| `--key` / `-k` | yes | PEM-encoded Ed25519 private key (produced by `rove keygen`). |
| `--output` | no | Where to write the signed manifest JSON. Default: `<bundle>.manifest.json` (alongside the tarball). |

**What gets signed.** The Ed25519 signature covers the canonical payload `<tarball_sha256>|<target>|<runtime_version>|<project_name>` — see [`MANIFEST.md`](MANIFEST.md) for the exact wire format. The signature is stored in the `signature` field of the manifest.

**Example.**

```bash
rove sign --bundle ./dist/myapp-linux-x86_64-0.1.0.tar.xz --key ./keys/private.pem
# [ok] signed manifest: ./dist/myapp-linux-x86_64-0.1.0.tar.xz.sig
# [ok] updated:         ./dist/myapp-linux-x86_64-0.1.0.tar.xz.manifest.json
```

---

## `rove verify`

Verify a bundle's SHA-256 and Ed25519 signature.

```bash
rove verify --bundle PATH [--pubkey PATH ...]
```

| Flag | Required | Description |
|---|---|---|
| `--bundle` / `-b` | yes | Path to the bundle. |
| `--pubkey` / `-p` | no | Additional trusted public key. May be repeated for multi-key trust (rotation). |

**Trust sources.** `verify` aggregates trust from, in priority order:

1. `ROVE_TRUSTED_PUBKEYS` env var (comma-separated PEM-base64 or full PEM blocks with `\n`-escaped newlines).
2. Every `*.pem` file in `~/.config/rove/trusted_keys/`.
3. Each `--pubkey` on the command line.

If zero trusted keys resolve, `verify` exits 1 with a clear error. If at least one resolves, the signature is checked against every key in sequence and succeeds on the first match — this is the key-rotation pattern: publish bundles with the new key, clients trust both old and new, retire old after the rollout window.

**Exit codes.**

- `0` — SHA-256 matches, signature validates.
- `1` — SHA mismatch, signature invalid, or no trusted keys resolved.
- `2` — Manifest sidecar missing next to the bundle, or manifest fails schema validation. (A missing `--bundle` is rejected by Typer before the command body runs.)

**Example.**

```bash
rove verify --bundle ./dist/myapp-linux-x86_64-0.1.0.tar.xz --pubkey ./keys/public.pem
# [ok] sha256 ok: 0048436301c0964af70d36bddbd559f868a23b461af5c639d6bae26be4bc884b
# [ok] signature ok
# [ok] bundle verified: ./dist/myapp-linux-x86_64-0.1.0.tar.xz
```

---

## `rove serve`

Serve a directory of bundles over HTTP with `Range` request support.

```bash
rove serve --bundle-dir DIR [--host HOST] [--port PORT]
```

| Flag | Required | Description |
|---|---|---|
| `--bundle-dir` / `-d` | yes | Directory of `*.tar.xz` / `*.tar.zst` bundles. Must contain at least one. |
| `--host` | no | Bind address. Default: `0.0.0.0` (LAN-visible). Use `127.0.0.1` for local-only. |
| `--port` | no | TCP port. Default: `8080`. |

**Security notes.**

- The served directory is resolved via `os.path.realpath`; any symlink inside it pointing outside the tree is rejected (404). Prevents symlink-escape attacks on multi-user boxes.
- `Content-Type` is set correctly for `.tar.xz`, `.tar.zst`, `.json`. `Range` requests are honoured (single range — multi-range degrades to full 200).
- The server does NOT emit its own `Server:` header, so there is no FQDN leak (the stdlib `BaseHTTPServer` reverse-DNS call is bypassed).

**Example.**

```bash
rove serve --bundle-dir ./dist --host 0.0.0.0 --port 8080
# [ok] rove serve listening on http://0.0.0.0:8080/  (dir=./dist)
# Ctrl-C to stop.
```

---

## `rove fetch`

Download a bundle from a peer, verify its SHA-256 and signature, and write it to a local directory.

```bash
rove fetch --from URL
           --target TARGET
           --project-name NAME
           --runtime-version VERSION
           --out DIR
           [--pubkey PATH ...]
           [--compression {xz|zstd|none}]
```

| Flag | Required | Description |
|---|---|---|
| `--from` | yes | Base URL of the peer serving the bundle. `http://` and `https://` only — `file://`, `ftp://`, relative URLs and hostless URLs are rejected pre-socket. |
| `--target` / `-t` | yes | Target tuple to request. |
| `--project-name` | yes | Project identifier. Used to construct the canonical bundle filename. |
| `--runtime-version` | yes | SemVer of the bundle to download. |
| `--out` / `-o` | yes | Local directory. Created if missing. |
| `--pubkey` / `-p` | no | Additional trusted public key. May be repeated. |
| `--compression` | no | Expected bundle compression. Default `xz`. |

**Security guarantees.**

- Scheme allowlist: only `http` and `https`.
- Strict redirect handler: cross-host and cross-scheme `302`s are refused before the request body is ever read.
- Oversized-response DoS cap: the manifest body is hard-capped at 1 MiB. Bundle streams are bounded by `manifest.compressed_size_bytes * 1.01`.
- TOCTOU hardening: SHA-256 is computed AFTER the atomic rename into the output directory, not on a staging `.part` file.
- Resumable downloads: Range requests, exponential backoff on transient errors (1s / 2s / 4s), automatic fallback to a full GET if the server ignores `Range`.

**Example.**

```bash
rove fetch --from http://192.168.0.16:8080 \
           --target host \
           --project-name myapp --runtime-version 0.1.0 \
           --out ./fetched/ \
           --pubkey ./keys/public.pem
# [ok] fetching myapp-windows-x86_64-0.1.0.tar.xz from http://192.168.0.16:8080
# [ok] downloaded 12458 bytes
# [ok] sha256 ok: 0048436301c0964a...
# [ok] signature ok — bundle ready at ./fetched/myapp-windows-x86_64-0.1.0.tar.xz
```

---

## Supported targets

Pass as `--target` or in `[tool.rove].targets`. Aliases (hyphens and underscores interchangeable; case-insensitive) are curated in `src/rove/targets.py::_ALIASES`.

| Canonical | Aliases | Notes |
|---|---|---|
| `linux-x86_64` | `linux-x64`, `linux-amd64` | glibc |
| `linux-arm64` | `linux-aarch64` | glibc |
| `darwin-arm64` | `macos-arm64`, `darwin-aarch64`, `macos-aarch64` | Apple Silicon |
| `darwin-x86_64` | `macos-x86_64`, `darwin-amd64`, `darwin-x64`, `macos-x64`, `macos-amd64` | Intel Mac |
| `windows-x86_64` | `win-x64`, `win-amd64`, `windows-amd64`, … | |
| `android-arm64` | `android-aarch64`, `android-arm8` | Termux path; `python-build-standalone` not available — use `--no-python` and Termux's `pkg install python` on device |
| `android-armv7` | `android-arm`, `android-armv7a`, `android-armeabi-v7a` | same caveat |
| `host` | `current`, `native` | sentinel — resolved at runtime to the concrete target of the current machine |

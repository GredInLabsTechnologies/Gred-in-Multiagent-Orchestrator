# Changelog

All notable changes to Rove are documented here. Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). Rove adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] — 2026-04-18

First stable release. Every surface promised by the CLI and library
docs is implemented, tested at 100% line+branch coverage, and pinned
by the wire-protocol contract described in `docs/MANIFEST.md`. The
0.1.x series was pre-audit alpha; 1.0.0 rolls up the two security
hardening passes (0.1.3 and this one) and makes the signing payload
cross-project-safe.


### BREAKING

- **Wire-protocol change in `WheelhouseManifest.signing_payload()`**: the
  canonical signed payload is now the 4-tuple
  `<tarball_sha256>|<target>|<runtime_version>|<project_name>` (was a
  3-tuple without `project_name`). Bundles signed by 0.1.x do **not**
  validate against 0.2.x consumers, and vice versa. Non-Python
  verifiers (Kotlin/Rust launchers) must be updated to the new format
  — see [`docs/MANIFEST.md`](docs/MANIFEST.md#canonical-signing-payload).

  Rationale: without `project_name` in the payload, a signer that
  produces bundles for multiple projects let an attacker re-label a
  bundle from project A as project B (same sha/target/version) and
  still have a valid signature — a cross-project confusion attack.

### Added

- **`rove --version` flag.** Prints the package version and exits 0.
  Essential for bug reports and release scripting; typer's top-level
  `--version` is wired via a `_version_callback` + `@app.callback()`.

### Fixed

- **Poisoned python-build-standalone cache.** When `_verify_sha256`
  failed (truncated download, upstream re-publishing the asset, disk
  corruption), the on-disk tarball was left in place. The next
  `rove build` saw "cache hit: file exists, size > 0", skipped the
  re-download, and re-hit the same SHA mismatch forever. The verify
  step now `unlink(missing_ok=True)`s the offending tarball on failure
  so the next invocation re-downloads.
- **zstd bundles were potentially non-deterministic.** `ZstdCompressor`
  was constructed with `threads=-1` (auto-pick N CPUs). Multi-threaded
  `stream_writer` picks flush points based on thread scheduling, so
  two runs over identical inputs could produce byte-different but
  still-valid output — breaking the "byte-identical bundle for
  identical inputs" guarantee that `docs/COMMANDS.md` advertises.
  Switched to `threads=0` (single-threaded). New regression test
  `test_build_tarball_zstd_is_deterministic` covers the guarantee
  per-compression-mode.
- **`RuntimeSignatureError` inheritance.** It descended from `Exception`
  while every other Rove domain exception descends from `RuntimeError`
  (or `ValueError` for `ConfigError`). `docs/LIBRARY.md` promised the
  `except RuntimeError` umbrella would catch all of them — re-parented
  to `RuntimeError` so the promise holds.

### Security (second audit pass)

- **`tarfile.extractall` without `filter=` (CVE-2007-4559 class):**
  `python_standalone._extract_tarball` now passes `filter="data"` (PEP
  706) to reject absolute paths, `..` traversal, unsafe symlinks /
  hardlinks, devices, and setuid bits during extraction.
- **`requires-python` bumped to `>=3.11.4`:** `filter="data"` is a
  backport that is only present in Python 3.11.4+. The previous
  `>=3.11` allowed installs on 3.11.0-3.11.3 which would `TypeError`
  on extract.
- **Environment leakage into `pip download`:** `pip_runner._merged_env`
  replaced `os.environ.copy()` with an explicit allowlist (PATH, HOME,
  proxy vars, PIP_*, SSL_*, locale, Windows system vars). CI tokens,
  signing-key paths, and cloud credentials no longer bleed into pip
  subprocesses.
- **Shell word-split on `CC`/`CXX`/`AR`:** `zig.build_env_for` now
  `shlex.quote`s the zig path so installations under e.g.
  `C:\Program Files\Zig\zig.exe` do not split into `C:\Program` +
  `Files\Zig\zig.exe` when downstream build tools (cargo, setuptools,
  meson) re-parse the env var as a shell command.
- **Pydantic `extra="forbid"`:** `RoveConfig`, `WheelhouseManifest`,
  `PatchEntry`, and `PatchSet` now reject unknown keys. Typos like
  `requrements` instead of `requirements` fail the build instead of
  silently dropping the field.
- **Manifest path list validation:** `python_path_entries` and `files`
  now run through the same `..`/absolute/UNC check as the existing
  string path fields (`python_rel_path`, `project_root_rel_path`,
  `wheels_rel_path`, `tarball_name`). A compromised signer can no
  longer inject `"../../etc/passwd"` into either list.
- **Patch set path traversal:** `builder/patches._resolve_path` and
  `patches/loader.load_patch_set` now verify with `is_relative_to`
  that every referenced file resolves inside `patch_set_root`. A
  tampered patch index can no longer point at arbitrary host files
  (SSH keys, CI secrets, `/etc/passwd`).
- **Keygen private-key write race:** `generate_keypair` on POSIX now
  opens the private key file with `O_EXCL | mode=0o600` from the start
  instead of `write_bytes` + later `chmod`. Closes the short window in
  which a local user could snapshot the key while it still had the
  umask-default mode.

### Documentation

- `docs/MANIFEST.md`, `docs/ARCHITECTURE.md`, `docs/COMMANDS.md`,
  `docs/LIBRARY.md`, and the `ed25519.py` module docstring updated to
  the 4-tuple `signing_payload` format with Python/Kotlin/Rust
  examples.
- `docs/SECURITY.md` extended with the new defenses (CVE-2007-4559,
  env allowlist, shlex.quote, cross-project binding, patches traversal,
  keygen atomic, extra=forbid, path-list validators).
- `docs/COMMANDS.md` — removed `ios-arm64` target row (was listed but
  the enum member never landed); rewrote build output section (was
  `"Three artifacts land"` but only bundle + sidecar exist); fixed
  `verify` exit-code semantics for manifest-missing vs bundle-missing.
- `docs/CONFIG.md` — removed stale `rove ship` reference (the subcommand
  was reverted in 0.1.2).
- `docs/LIBRARY.md` — removed import of non-existent `os_family`; updated
  stability section to describe `signing_payload` as frozen-per-major
  rather than frozen-forever (the 1.0.0 bump locks in the 4-field form).
- `README.md` bumped to v1.0.0; quick-start now quotes Python 3.11.4+
  (was 3.11); example filenames match the new version.

### Repo hygiene

- `.gitignore` excludes `*.pem` and `keys/` so a contributor running
  the CONTRIBUTING.md smoke test cannot accidentally commit a freshly
  generated private key into a PR (SECURITY.md already stated the
  policy; this is the belt to the suspenders).

### Gates

- ruff clean on 20 source files + all tests.
- mypy strict clean.
- pytest **510 passed**, 3 skipped (2 POSIX-only file-mode tests, 1
  Windows-only symlink test), 0 failed.
- Coverage **100.00%** line + branch.

## [0.1.8] — 2026-04-18

### Added — Reference documentation

Five new documents under `docs/`, each covering one facet of the public
surface. Every link in the site is internally resolved (no broken
anchors). Together with README, CHANGELOG, CONTRIBUTING and
ARCHITECTURE, the doc set now covers every user-facing promise Rove
makes.

- [`docs/COMMANDS.md`](docs/COMMANDS.md) (233 lines) — every CLI
  subcommand, every flag, every exit code, worked examples.
- [`docs/CONFIG.md`](docs/CONFIG.md) (137 lines) — full `[tool.rove]`
  schema with validator rules and examples (minimal, multi-target,
  Android cross-build).
- [`docs/MANIFEST.md`](docs/MANIFEST.md) (128 lines) — wire format of
  the signed manifest, re-implementable in any language; Python +
  Kotlin + Rust worked examples of the signing payload.
- [`docs/SECURITY.md`](docs/SECURITY.md) (120 lines) — threat model
  (what Rove defends against, what it does not), key-rotation
  runbook (planned + emergency), backup, responsible disclosure
  pointer.
- [`docs/LIBRARY.md`](docs/LIBRARY.md) (295 lines) — Python library
  API — every public name in every module, error taxonomy,
  stability rules.

README now surfaces the documentation index as a table. No source
code changed; pyproject + `__init__.py` bumped to 0.1.8 for the
release tag.

## [0.1.7] — 2026-04-17

### Fixed

- V0.1.6's `_NoFQDNThreadingHTTPServer` fix was applied only to
  `RoveHttpServer.start()` — the redirect integration test in
  `tests/test_security_hardening.py` still instantiated stdlib
  `http.server.ThreadingHTTPServer` directly and re-hit the macOS
  `socket.getfqdn` hang. Promoted the workaround class to the public
  module name `NoFQDNThreadingHTTPServer` (exported from
  `rove.distribution.http_server`) and rewrote the test to use it.
  Same pattern available to any downstream user who spins up an
  auxiliary test server.

## [0.1.6] — 2026-04-17

### Fixed

- macOS GHA runners hung for 20+ s inside
  `ThreadingHTTPServer.server_bind` because stdlib calls
  `socket.getfqdn(host)` on the bound address, and the reverse-DNS
  lookup for ``127.0.0.1`` can block indefinitely on those runners.
  Replaced the concrete server class with a thin
  `_NoFQDNThreadingHTTPServer` subclass that skips the `getfqdn` call
  (the FQDN is cosmetic, used only in the stdlib ``Server:`` header
  which Rove doesn't emit).
- Coverage branch gap in `_get_safe_opener`'s double-checked-lock
  re-check (timing-dependent branch) is now annotated with
  `# pragma: no branch` + an explanation.
- `_resolve_icacls` tagged `# platform: windows` so Linux CI excludes
  the function from its coverage report.

## [0.1.5] — 2026-04-17

### Fixed

- CI on `ubuntu-latest` failed the `--cov-fail-under=100` gate (98.85 %
  line coverage) because Windows-only code paths in
  `src/rove/signing/keygen.py` (the `icacls` ACL tightener) are
  skipped on Linux but still counted against the coverage total.
  Switched to platform-tagged ``# platform: windows`` / ``# platform:
  posix`` pragmas in the coverage config — each OS excludes the
  branch it cannot reach. Tests still run on the relevant OS in the
  matrix, so behaviour is verified on both platforms.

## [0.1.4] — 2026-04-17

### Fixed

- CI on `macos-latest` with Python 3.11/3.13 spuriously timed out on
  `test_http_server_serves_get_200_and_404` (≈20s soft limit from
  `@pytest.mark.timeout`) despite the underlying work completing in
  milliseconds. Root cause: `pytest-timeout` defaults to a signal-based
  timer on POSIX that interferes with `ThreadingHTTPServer` daemon
  threads under some Python 3.13 arm64 builds. Switched to
  ``timeout_method = "thread"`` globally in `pyproject.toml`, which is
  what the plugin already used on Windows — behaviour is now identical
  across the matrix. Raised the wall-clock default timeout to 60 s to
  absorb the extra slack.

### Changed

- README Quick Start updated to the `0.1.4` bundle-name pattern.

## [0.1.3] — 2026-04-17

### Security (production hardening pass)

- **HTTP fetcher — oversized-response OOM DoS (CVE-class):** `_http_get_bytes` now caps manifest responses at 1 MiB. Checks `Content-Length` up-front and streams in 64 KiB chunks with a running total; aborts on overrun with `DistributionError`.
- **HTTP fetcher — disk-fill DoS on bundle download:** `_http_download_streaming` accepts an explicit `max_total_bytes` parameter, propagated from `fetch_bundle` as `int(manifest.compressed_size_bytes * 1.01)`. Peers that advertise small sizes and stream huge payloads are cut off mid-chunk.
- **Manifest — path traversal latent bug:** `_no_absolute_paths` now rejects `..` segments (both path separators), UNC prefixes (`\\server\share`, `//server/share`) and the existing Windows-drive / POSIX-absolute guards. A signed manifest with `python_rel_path="../../etc/passwd"` is refused at validation time.
- **HTTP server — symlink escape:** `_BundleRequestHandler.do_GET` now `realpath`s both the requested file and the served root, refusing anything that is not a prefix-child of the root. Prevents a symlink in `bundle_dir` from serving out-of-tree files.
- **HTTP fetcher — cross-host/cross-scheme redirect (#12 follow-up):** integration test added against a live HTTP server returning `302 Location: <off-host>`; closes the audit gap that the handler was only unit-tested in isolation.
- **HTTP fetcher — TOCTOU hardening (#6 follow-up):** OSError from `sha256_file` on both the cache and the holding path now surfaces as `DistributionError` instead of leaking the raw stdlib exception.
- **HTTP fetcher — thread-safety:** `_get_safe_opener` uses double-checked locking; concurrent first-calls can no longer leak a duplicate opener.
- **Signing — `signing_payload` disambiguation:** `runtime_version` rejects the `|` separator via Pydantic pattern. Makes the `<sha>|<target>|<version>` payload unambiguously reversible.
- **Keygen — Windows ACL tightening:** `private.pem` on Windows is now restricted to the current user via `icacls /inheritance:r /grant:r <user>:F`. Removes the inherited `Users:R` entry that made the key world-readable by default. Best-effort: on editions without `icacls` or when `USERNAME` is unset, a warning is logged and the default ACL is left in place.

### Added

- `Target.ios_arm64` in the target enum (hook only — downstream flows raise `NotImplementedError` until the iOS packaging story is resolved).
- Windows ARM64 host detection: `detect_host` on Surface Pro X / Copilot+ PCs now raises a specific `RuntimeError` pointing at the cross-build workflow instead of the generic "Unsupported host".
- `rove-patches` loader emits an explicit `WARNING` that the patch index is consumed without Ed25519 signature verification — callers must curate the source path out-of-band.

### Removed

- Reverted V0.2 `ship` + `update` subcommands. Post-audit they were a facade: per-OS builders crashed on first live invocation, PyApp env-vars were misused, and the "Tauri-compat" manifest carried Ed25519 hex signatures instead of Tauri's minisign format. The V0.2 feature set returns to the backlog with integration tests against real `fpm`/`cargo-wix`/`appimagetool` as the new gate.

### Gates

- ruff clean on 20 source files + all tests.
- mypy strict clean.
- pytest 503 passed, 3 skipped (2 POSIX-only chmod, 1 symlink test Windows-skipped), 0 failed.
- Coverage **100.00%** line + branch (with each `# pragma: no cover` documented inline).

## [0.1.2] — 2026-04-17

### Security (first audit pass)

- Reverted V0.2 ship + update subsystems after the production audit showed they were never validated against real toolchains.
- TOCTOU hardening in `fetch_bundle`: hash the bundle **after** the atomic rename into the output directory (`.incoming` holding file), not on the staging `.part`.
- URL scheme allowlist: `file://`, `ftp://`, relative URLs and hostless URLs are rejected before any socket is opened.
- `_StrictRedirectHandler`: cross-host and cross-scheme redirects are refused; same-host canonicalisation still works.
- Patches loader emits a WARNING that the index is not Ed25519-signed.

## [0.1.0] — 2026-04-17

Initial public release.

### Added

- `rove keygen` — generate Ed25519 signing keypair.
- `rove build` — assemble a deterministic `.tar.xz` / `.tar` / `.tar.zst` wheelhouse bundle for a target.
- `rove sign` — sign an existing bundle's manifest.
- `rove verify` — verify a bundle's SHA-256 + Ed25519 signature.
- `rove serve` — serve a directory of bundles with HTTP Range support.
- `rove fetch` — download a bundle with Range-resume + retry; verify SHA-256 + signature.
- Multi-key trust rotation: `ROVE_TRUSTED_PUBKEYS` env + `~/.config/rove/trusted_keys/*.pem` + explicit `--pubkey`.
- Patch registry loader for the companion `rove-patches` repo.

[1.0.0]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v1.0.0
[0.1.8]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.8
[0.1.7]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.7
[0.1.6]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.6
[0.1.5]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.5
[0.1.4]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.4
[0.1.3]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.3
[0.1.2]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.2
[0.1.0]: https://github.com/GredInLabsTechnologies/rove/releases/tag/v0.1.0

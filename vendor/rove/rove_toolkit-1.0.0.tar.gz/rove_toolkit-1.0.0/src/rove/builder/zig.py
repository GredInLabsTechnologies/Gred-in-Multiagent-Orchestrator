"""
Zig 0.14 cross-compile environment for native Rust/C dependencies.

Rove uses Zig as a portable C/C++ cross-compiler driver because it
ships a baked-in libc per target (``glibc 2.17``, ``musl``, NDK API
levels, mingw, etc.) and removes the need to assemble an Android NDK
or macOS SDK by hand.

This module is *pure configuration*: it discovers a local ``zig``
binary and returns a :class:`ZigBuildEnv` describing the compiler
wrapper, archiver, and Cargo target triple to use for a given
:class:`~rove.targets.Target`. Actual subprocess invocation is left to
the build pipeline (the wheelhouse forge in ``builder/`` step B3 and
the ``rove`` CLI).

Reference target triples (Zig side, glibc 2.17 baseline keeps the
resulting binaries compatible with most LTS distros):

================================  ==============================  ============================
Rove target                       Zig ``-target``                 Cargo target triple
================================  ==============================  ============================
``linux-x86_64``                  ``x86_64-linux-gnu.2.17``        ``x86_64-unknown-linux-gnu``
``linux-arm64``                   ``aarch64-linux-gnu.2.17``       ``aarch64-unknown-linux-gnu``
``darwin-arm64``                  ``aarch64-macos-none``           ``aarch64-apple-darwin``
``darwin-x86_64``                 ``x86_64-macos-none``            ``x86_64-apple-darwin``
``windows-x86_64``                ``x86_64-windows-gnu``           ``x86_64-pc-windows-gnu``
``android-arm64``                 ``aarch64-linux-android.<api>``  ``aarch64-linux-android``
``android-armv7``                 ``arm-linux-androideabi.<api>``  ``armv7-linux-androideabi``
================================  ==============================  ============================
"""
from __future__ import annotations

import re
import shlex
import shutil
import subprocess
from pathlib import Path

from pydantic import BaseModel, Field

from rove.targets import Target

__all__ = [
    "ZigBuildEnv",
    "ZigNotFoundError",
    "ZigToolchain",
    "build_env_for",
    "discover_toolchain",
]


class ZigNotFoundError(RuntimeError):
    """Raised when a usable ``zig`` binary cannot be located."""


class ZigToolchain(BaseModel):
    """A discovered Zig installation."""

    zig_path: Path
    version: str


class ZigBuildEnv(BaseModel):
    """Cross-compile environment for a single Rove target."""

    target: Target
    cc: str
    cxx: str
    ar: str
    cargo_build_target: str
    extra_env: dict[str, str] = Field(default_factory=dict)


_VERSION_RE = re.compile(r"\b(\d+\.\d+(?:\.\d+)?(?:[-+][\w.]+)?)")


def _parse_zig_version(output: str) -> str:
    """Pull a semver-ish token out of ``zig version`` output."""
    match = _VERSION_RE.search(output.strip())
    if not match:
        raise ZigNotFoundError(
            f"could not parse 'zig version' output: {output!r}"
        )
    return match.group(1)


def discover_toolchain() -> ZigToolchain:
    """Locate the ``zig`` binary on ``PATH`` and read its version.

    Returns:
        A :class:`ZigToolchain` with the resolved path and version
        string (e.g. ``"0.14.0"``).

    Raises:
        ZigNotFoundError: ``zig`` is not on ``PATH``, fails to run, or
            prints output that does not contain a parseable version.
    """
    zig_path_str = shutil.which("zig")
    if zig_path_str is None:
        raise ZigNotFoundError(
            "'zig' was not found on PATH. Install Zig 0.14+ from "
            "https://ziglang.org/download/ and ensure it is on PATH."
        )
    zig_path = Path(zig_path_str)

    try:
        completed = subprocess.run(
            [str(zig_path), "version"],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise ZigNotFoundError(
            f"failed to invoke '{zig_path} version': {exc}"
        ) from exc

    if completed.returncode != 0:
        raise ZigNotFoundError(
            f"'{zig_path} version' exited non-zero ({completed.returncode}): "
            f"{completed.stderr.strip() or completed.stdout.strip()}"
        )

    version = _parse_zig_version(completed.stdout or completed.stderr)
    return ZigToolchain(zig_path=zig_path, version=version)


_CARGO_TARGETS: dict[Target, str] = {
    Target.linux_x86_64: "x86_64-unknown-linux-gnu",
    Target.linux_arm64: "aarch64-unknown-linux-gnu",
    Target.darwin_arm64: "aarch64-apple-darwin",
    Target.darwin_x86_64: "x86_64-apple-darwin",
    Target.windows_x86_64: "x86_64-pc-windows-gnu",
    Target.android_arm64: "aarch64-linux-android",
    Target.android_armv7: "armv7-linux-androideabi",
}


def _zig_target_triple(target: Target, android_api_level: int) -> str:
    """Return the ``-target`` argument Zig expects for a Rove target."""
    if target is Target.linux_x86_64:
        return "x86_64-linux-gnu.2.17"
    if target is Target.linux_arm64:
        return "aarch64-linux-gnu.2.17"
    if target is Target.darwin_arm64:
        return "aarch64-macos-none"
    if target is Target.darwin_x86_64:
        return "x86_64-macos-none"
    if target is Target.windows_x86_64:
        return "x86_64-windows-gnu"
    if target is Target.android_arm64:
        return f"aarch64-linux-android.{android_api_level}"
    if target is Target.android_armv7:
        return f"arm-linux-androideabi.{android_api_level}"
    raise ValueError(f"no zig triple mapping for target {target!r}")


def build_env_for(
    target: Target,
    *,
    toolchain: ZigToolchain | None = None,
    android_api_level: int = 24,
) -> ZigBuildEnv:
    """Compose the cross-compile environment for ``target``.

    Args:
        target: A concrete Rove target. Pass through
            :func:`rove.targets.resolve` first if you might be holding
            :attr:`Target.host`.
        toolchain: Pre-discovered :class:`ZigToolchain`; if ``None``
            the function calls :func:`discover_toolchain` itself.
        android_api_level: Android NDK API level to bake into the
            ``aarch64-linux-android.<api>`` and
            ``arm-linux-androideabi.<api>`` triples. Default 24
            (matches ``minSdkVersion`` of most modern Android apps).

    Returns:
        A :class:`ZigBuildEnv` carrying ``cc`` / ``cxx`` / ``ar``
        wrapper commands, the matching Cargo target triple, and any
        extra env vars the consumer should export.

    Raises:
        ValueError: ``target`` is :attr:`Target.host` (resolve it first)
            or otherwise unmapped.
        ZigNotFoundError: ``toolchain`` is ``None`` and discovery failed.
    """
    if target is Target.host:
        raise ValueError("resolve target before building env")

    if toolchain is None:
        toolchain = discover_toolchain()

    triple = _zig_target_triple(target, android_api_level)
    cargo_target = _CARGO_TARGETS[target]
    # Downstream build tools (cargo, setuptools, meson) shell-parse CC/CXX/AR.
    # Quote the binary path so installs under e.g. ``C:\Program Files\Zig``
    # do not word-split into ``C:\Program`` + ``Files\Zig\zig.exe``.
    zig = shlex.quote(str(toolchain.zig_path))

    cc = f"{zig} cc -target {triple}"
    cxx = f"{zig} c++ -target {triple}"
    ar = f"{zig} ar"

    extra_env: dict[str, str] = {}
    if target in (Target.android_arm64, Target.android_armv7):
        extra_env["ANDROID_API_LEVEL"] = str(android_api_level)

    return ZigBuildEnv(
        target=target,
        cc=cc,
        cxx=cxx,
        ar=ar,
        cargo_build_target=cargo_target,
        extra_env=extra_env,
    )

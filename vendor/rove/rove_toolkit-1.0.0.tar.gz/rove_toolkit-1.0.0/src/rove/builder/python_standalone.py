"""Fetch + extract a CPython distribution from python-build-standalone.

Idempotent caching, caller-controlled cache directory, SHA-256
verification against the upstream ``.sha256`` companion file, and an
explicit :class:`NotImplementedError` for Android targets
(python-build-standalone does not ship Android tarballs — Termux's
``pkg install python`` is the recommended path on Android).

Public API:

* :func:`fetch_standalone_python` — idempotent fetch + extract.
* :class:`StandaloneFetchError`   — download/extract failures.
"""
from __future__ import annotations

import hashlib
import logging
import os
import shutil
import sys
import tarfile
import urllib.error
import urllib.request
from pathlib import Path

from rove.targets import Target

__all__ = ["StandaloneFetchError", "fetch_standalone_python"]

logger = logging.getLogger("rove.builder.python_standalone")

# ---------------------------------------------------------------------------
# Pinned upstream release. Bump explicitly — never auto-track.
# ---------------------------------------------------------------------------
_DEFAULT_RELEASE = "20260414"
_DEFAULT_PYTHON_VERSION = "3.13"

# Map Target → python-build-standalone target triple. Android entries are
# absent on purpose: python-build-standalone does not publish Android.
_TARGET_TRIPLE: dict[Target, str] = {
    Target.linux_x86_64: "x86_64-unknown-linux-gnu",
    Target.linux_arm64: "aarch64-unknown-linux-gnu",
    Target.darwin_arm64: "aarch64-apple-darwin",
    Target.darwin_x86_64: "x86_64-apple-darwin",
    Target.windows_x86_64: "x86_64-pc-windows-msvc",
}

_ANDROID_TARGETS: frozenset[Target] = frozenset(
    {Target.android_arm64, Target.android_armv7}
)

_RELEASE_URL_TMPL = (
    "https://github.com/astral-sh/python-build-standalone/releases/download/"
    "{release}/{asset}"
)
_ASSET_TMPL = "cpython-{pyver}+{release}-{triple}-install_only.tar.gz"
_CACHE_ENV_VAR = "ROVE_STANDALONE_CACHE"
_DOWNLOAD_TIMEOUT = 60
_DOWNLOAD_RETRIES = 3
_CHUNK_SIZE = 64 * 1024
_STANDALONE_ROOT = "python"


class StandaloneFetchError(RuntimeError):
    """Download, extraction, or verification failure."""


def _default_cache_dir() -> Path:
    override = os.environ.get(_CACHE_ENV_VAR, "").strip()
    if override:
        return Path(override)
    return Path.home() / ".cache" / "rove" / "python-standalone"


def _resolve_release(python_version: str) -> tuple[str, str]:
    """Resolve (release_tag, full_python_version) for a given short pyver.

    ``python_version`` may be either ``"3.13"`` (short) or the upstream
    full triple ``"3.13.13"``. The short form is mapped to the pinned
    full version for ``_DEFAULT_RELEASE``.
    """
    full_version_map = {"3.13": "3.13.13"}
    if python_version in full_version_map:
        return _DEFAULT_RELEASE, full_version_map[python_version]
    return _DEFAULT_RELEASE, python_version


def _asset_url(target: Target, *, release: str, full_pyver: str) -> tuple[str, str]:
    """Return (asset_filename, download_url) for ``target``."""
    triple = _TARGET_TRIPLE.get(target)
    if triple is None:
        raise StandaloneFetchError(
            f"target {target.value!r} has no python-build-standalone mapping"
        )
    asset = _ASSET_TMPL.format(pyver=full_pyver, release=release, triple=triple)
    url = _RELEASE_URL_TMPL.format(release=release, asset=asset)
    return asset, url


def _download_streaming(url: str, dest: Path) -> None:
    """Stream ``url`` to ``dest`` in 64 KiB chunks with retries."""
    if dest.exists() and dest.stat().st_size > 0:
        logger.debug("cache hit: %s", dest)
        return

    dest.parent.mkdir(parents=True, exist_ok=True)
    last_err: Exception | None = None
    for attempt in range(1, _DOWNLOAD_RETRIES + 1):
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            logger.info(
                "downloading %s (attempt %d/%d)", url, attempt, _DOWNLOAD_RETRIES
            )
            with urllib.request.urlopen(
                url, timeout=_DOWNLOAD_TIMEOUT
            ) as resp:
                if resp.status != 200:
                    raise StandaloneFetchError(f"HTTP {resp.status} on {url}")
                with tmp.open("wb") as fh:
                    while True:
                        chunk = resp.read(_CHUNK_SIZE)
                        if not chunk:
                            break
                        fh.write(chunk)
            tmp.replace(dest)
            return
        except (urllib.error.URLError, OSError, StandaloneFetchError) as exc:
            last_err = exc
            logger.warning("download failed (%s); attempt=%d", exc, attempt)
            if tmp.exists():
                tmp.unlink(missing_ok=True)

    raise StandaloneFetchError(
        f"failed to download {url} after {_DOWNLOAD_RETRIES} attempts: {last_err}"
    )


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(_CHUNK_SIZE)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _verify_sha256(tarball: Path, sha_url: str) -> None:
    """Fetch ``<asset>.sha256`` and compare it to the local digest."""
    try:
        with urllib.request.urlopen(
            sha_url, timeout=_DOWNLOAD_TIMEOUT
        ) as resp:
            if resp.status != 200:
                raise StandaloneFetchError(
                    f"HTTP {resp.status} fetching {sha_url}"
                )
            payload = resp.read().decode("utf-8", errors="replace").strip()
    except (urllib.error.URLError, OSError) as exc:
        raise StandaloneFetchError(
            f"cannot fetch checksum {sha_url}: {exc}"
        ) from exc

    # Companion files are usually `<sha>  <filename>` or just `<sha>`.
    expected = payload.split()[0].lower() if payload else ""
    if len(expected) != 64:
        raise StandaloneFetchError(
            f"checksum payload at {sha_url} is not a SHA-256 hex"
        )

    actual = _sha256_file(tarball)
    if actual != expected:
        raise StandaloneFetchError(
            f"SHA-256 mismatch for {tarball.name}: "
            f"expected {expected}, got {actual}"
        )


def _extract_tarball(tarball: Path, extract_root: Path) -> Path:
    """Extract ``tarball`` (single ``python/`` root) under ``extract_root``.

    Returns the path to the extracted ``python/`` tree.
    """
    if extract_root.exists():
        shutil.rmtree(extract_root)
    extract_root.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(tarball, "r:gz") as tf:
            # filter="data" (PEP 706) rejects absolute paths, ``..`` traversal,
            # unsafe symlinks/hardlinks, devices, and setuid bits — CVE-2007-4559
            # defense-in-depth on top of the upstream SHA-256 check.
            tf.extractall(extract_root, filter="data")
    except (tarfile.TarError, OSError) as exc:
        shutil.rmtree(extract_root, ignore_errors=True)
        raise StandaloneFetchError(
            f"failed to extract {tarball}: {exc}"
        ) from exc

    python_root = extract_root / _STANDALONE_ROOT
    if not python_root.is_dir():
        shutil.rmtree(extract_root, ignore_errors=True)
        raise StandaloneFetchError(
            f"unexpected python-build-standalone layout — "
            f"missing {_STANDALONE_ROOT}/ inside {tarball.name}"
        )
    return python_root


def fetch_standalone_python(
    target: Target,
    *,
    python_version: str = _DEFAULT_PYTHON_VERSION,
    cache_dir: Path | None = None,
) -> Path:
    """Fetch + extract a CPython distribution for ``target``.

    Idempotent: if the extracted tree already exists in ``cache_dir``, it
    is returned without re-downloading or re-extracting. The downloaded
    tarball is verified against its upstream ``.sha256`` companion.

    Args:
        target: Concrete :class:`Target` (must not be :attr:`Target.host`
            — resolve before calling).
        python_version: Short ``"3.13"`` or full ``"3.13.13"``. Defaults
            to the pinned ``"3.13"``.
        cache_dir: Directory for cached tarballs and extracted trees.
            Defaults to ``$ROVE_STANDALONE_CACHE`` or
            ``~/.cache/rove/python-standalone``.

    Returns:
        Absolute path to the extracted ``python/`` tree
        (e.g. ``<cache>/cpython-3.13.13-linux-x86_64/python``).

    Raises:
        NotImplementedError: ``target`` is one of the Android variants.
        StandaloneFetchError: download, checksum, or extract failure.
    """
    if target is Target.host:
        raise StandaloneFetchError(
            "Target.host must be resolved to a concrete target before "
            "calling fetch_standalone_python (use rove.targets.resolve)."
        )

    if target in _ANDROID_TARGETS:
        raise NotImplementedError(
            "python-build-standalone does not publish Android tarballs; "
            "use the Termux Python via patches instead"
        )

    if target not in _TARGET_TRIPLE:  # pragma: no cover - defensive: every non-android, non-host Target is in _TARGET_TRIPLE
        raise StandaloneFetchError(
            f"target {target.value!r} has no python-build-standalone mapping"
        )

    release, full_pyver = _resolve_release(python_version)
    cache = (cache_dir or _default_cache_dir()).resolve()
    cache.mkdir(parents=True, exist_ok=True)

    asset, url = _asset_url(target, release=release, full_pyver=full_pyver)
    tarball_path = cache / asset
    extract_root = cache / f"cpython-{full_pyver}-{target.value}"
    python_root = extract_root / _STANDALONE_ROOT

    if python_root.is_dir():
        logger.debug("standalone python cache hit: %s", python_root)
        return python_root

    _download_streaming(url, tarball_path)
    try:
        _verify_sha256(tarball_path, url + ".sha256")
    except StandaloneFetchError:
        # Poisoned cache: the on-disk tarball no longer matches upstream
        # (truncated download that raced the ``.part`` rename, disk
        # corruption, or upstream re-publishing the asset). Remove it so
        # the next invocation re-downloads instead of re-hitting the
        # same mismatch forever.
        tarball_path.unlink(missing_ok=True)
        raise
    return _extract_tarball(tarball_path, extract_root)


# Re-export for tests / introspection.
def _supported_targets() -> list[Target]:  # pragma: no cover — trivial
    return sorted(_TARGET_TRIPLE.keys(), key=lambda t: t.value)


# Touch sys to keep import-only side effects explicit on Windows.
_ = sys.version_info

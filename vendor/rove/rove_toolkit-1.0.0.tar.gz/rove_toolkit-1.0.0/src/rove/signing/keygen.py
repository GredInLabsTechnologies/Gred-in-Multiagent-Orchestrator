"""
Rove Wheelhouse Signing — Ed25519 keypair generation
=====================================================

Library-only helpers for producing Ed25519 keypairs used to sign
:class:`rove.manifest.WheelhouseManifest` bundles. The CLI wrapper that
exposes :func:`generate_keypair` to end users lives in :mod:`rove.cli`;
this module is intentionally CLI-free so it can be imported by tests
and downstream tooling without side effects.

Two flavours are provided:

* :func:`generate_keypair` — write ``private.pem`` + ``public.pem`` to
  disk under a chosen directory, with tight ACL on the private key.
* :func:`generate_inmemory` — return PEM bytes without touching disk;
  intended for unit tests and ephemeral signing flows.

File permissions
----------------
On POSIX, ``private.pem`` is chmod'd to ``0o600`` (owner read/write
only) and ``public.pem`` to ``0o644``. On Windows the private key ACL
is rewritten via ``icacls`` to grant access only to the current user
(DACL = Owner:F, inheritance disabled). This removes the default
``Users:R`` inherited entry that would otherwise let any local user
read the key. The call is best-effort: filesystems without POSIX perms
or without ``icacls`` on PATH will silently fall back to defaults and
the module logs a warning rather than failing the keygen.
"""
from __future__ import annotations

import contextlib
import logging
import os
import subprocess
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    NoEncryption,
    PrivateFormat,
    PublicFormat,
)

__all__ = ["generate_inmemory", "generate_keypair"]

logger = logging.getLogger("rove.signing.keygen")

_PRIVATE_FILENAME = "private.pem"
_PUBLIC_FILENAME = "public.pem"


def generate_inmemory() -> tuple[bytes, bytes]:
    """Generate an Ed25519 keypair entirely in memory.

    Returns:
        A ``(private_pem_bytes, public_pem_bytes)`` tuple where the
        private key is PKCS#8 / PEM with no passphrase and the public
        key is ``SubjectPublicKeyInfo`` / PEM.
    """
    priv = Ed25519PrivateKey.generate()
    private_pem = priv.private_bytes(
        encoding=Encoding.PEM,
        format=PrivateFormat.PKCS8,
        encryption_algorithm=NoEncryption(),
    )
    public_pem = priv.public_key().public_bytes(
        encoding=Encoding.PEM,
        format=PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def _restrict_windows_acl(path: Path) -> None:  # platform: windows
    """Restrict ``path`` to the current user only via ``icacls``.

    Uses the stdlib ``subprocess`` (no new deps). On failure the ACL
    falls back to the filesystem default — the keygen itself still
    succeeds, but a warning is logged so the operator can investigate.
    Best-effort: on filesystems / Windows editions where ``icacls`` is
    missing (e.g. some container images), we skip with a warning.
    """
    icacls = _resolve_icacls()
    if icacls is None:
        logger.warning(
            "icacls not found on PATH — %s was written with default ACL "
            "which may grant read to other local users; please secure it "
            "manually or run rove on a supported Windows edition.",
            path,
        )
        return

    username = os.environ.get("USERNAME") or os.environ.get("USER")
    if not username:
        logger.warning(
            "cannot determine current username (USERNAME/USER env unset) — "
            "skipping ACL tightening on %s; please secure it manually.",
            path,
        )
        return

    # icacls grammar:
    #   /inheritance:r   — remove inherited ACEs (strip Users/Authenticated)
    #   /grant:r <user>:F — grant Full control to current user, replacing any
    #                        existing grant for that SID
    # Two invocations so we get a deterministic "clean + owner-only" DACL.
    for argv in (
        [str(icacls), str(path), "/inheritance:r"],
        [str(icacls), str(path), "/grant:r", f"{username}:F"],
    ):
        completed = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode != 0:
            logger.warning(
                "icacls %s failed (rc=%s): %s — %s may retain default ACL.",
                argv[2:],
                completed.returncode,
                (completed.stderr or completed.stdout).strip(),
                path,
            )
            return


def _resolve_icacls() -> Path | None:  # platform: windows
    """Locate ``icacls.exe`` on PATH. Returns None when not found."""
    import shutil

    found = shutil.which("icacls")
    return Path(found) if found else None


def generate_keypair(
    out_dir: Path,
    *,
    overwrite: bool = False,
) -> tuple[Path, Path]:
    """Generate an Ed25519 keypair and persist it to ``out_dir``.

    Writes ``private.pem`` (mode ``0o600`` on POSIX, ACL restricted to
    the current user on Windows via ``icacls``) and ``public.pem``
    (mode ``0o644`` on POSIX). On filesystems without POSIX perms the
    ``chmod`` calls are silently ignored; on Windows editions without
    ``icacls`` a warning is logged and the default ACL is left in place.

    Args:
        out_dir: Directory to write the two PEM files into. It is
            created (with parents) if it does not exist.
        overwrite: If ``False`` (default) and either output file already
            exists, raise :class:`FileExistsError` instead of clobbering.

    Returns:
        A ``(private_path, public_path)`` tuple of absolute
        :class:`pathlib.Path` objects.

    Raises:
        FileExistsError: ``overwrite=False`` and a key file already
            exists at the target location.
        OSError: The directory cannot be created or the files cannot be
            written.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    private_path = out_dir / _PRIVATE_FILENAME
    public_path = out_dir / _PUBLIC_FILENAME

    if not overwrite:
        for existing in (private_path, public_path):
            if existing.exists():
                raise FileExistsError(
                    f"refusing to overwrite existing key file: {existing} "
                    "(pass overwrite=True to replace)"
                )

    private_pem, public_pem = generate_inmemory()

    if os.name == "posix":  # platform: posix
        # Atomic open-with-mode: creating the file with ``O_EXCL | mode=0o600``
        # closes the race where a plain ``write_bytes`` + later ``chmod``
        # would expose the private key at the default umask (typically
        # 0o644 world-readable) for a short window. Any local user polling
        # the directory could snapshot the key during that window.
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        if not overwrite:
            flags |= os.O_EXCL
        fd = os.open(str(private_path), flags, 0o600)
        with os.fdopen(fd, "wb") as fh:
            fh.write(private_pem)
        # Re-chmod after the fact: on filesystems where ``O_CREAT`` respects
        # umask rather than the explicit mode (some NFS / FAT mounts),
        # ``chmod`` still tightens the perms best-effort.
        with contextlib.suppress(OSError):
            private_path.chmod(0o600)
        public_path.write_bytes(public_pem)
        with contextlib.suppress(OSError):
            public_path.chmod(0o644)
    else:
        # Windows: no POSIX mode on ``open``; we write first and then
        # tighten the DACL via ``icacls``. The default NTFS ACL grants
        # Users:R, which ``_restrict_windows_acl`` strips. The window is
        # the same order-of-operations as the POSIX path above, but
        # exploitation requires a local interactive user on the build
        # host — documented in SECURITY.md as out-of-scope.
        private_path.write_bytes(private_pem)
        public_path.write_bytes(public_pem)
        if os.name == "nt":  # pragma: no branch - Windows is the only non-POSIX branch we target; other platforms fall through with default perms
            _restrict_windows_acl(private_path)

    return private_path.resolve(), public_path.resolve()

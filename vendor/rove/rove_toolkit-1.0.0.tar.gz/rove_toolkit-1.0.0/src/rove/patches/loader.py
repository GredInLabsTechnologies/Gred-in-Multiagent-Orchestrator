"""
Rove patch-set loader.

Loads and validates a patch index produced by the companion
``rove-patches`` registry repo, then resolves the subset that applies to
a given ``(packages, target)`` build context.

A patch set is a JSON document of the shape::

    {
      "version": 1,
      "patches": [
        {
          "id": "psutil/android-platform-allow",
          "package": "psutil",
          "version_spec": ">=6.0.0",
          "targets": ["android-arm64", "android-armv7"],
          "kind": "patch",
          "path": "patches/psutil/android-platform-allow.patch",
          "sha256": "<hex>",
          "description": "Skip the platform=='android' refusal in setup.py."
        }
      ]
    }

Three patch *kinds* are supported:

* ``patch`` — a unified diff applied with GNU ``patch -p1`` against an
  unpacked sdist.
* ``env`` — a ``KEY=VALUE`` file merged into the build environment.
* ``toml`` — an arbitrary TOML document surfaced to a downstream
  consumer (e.g. ``cryptography`` package fallback config).

The loader verifies that each referenced file exists on disk and that
its SHA-256 matches the index. Version specifiers are checked
best-effort using :mod:`packaging` if available.
"""
from __future__ import annotations

import json
import logging
from enum import StrEnum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, ValidationError, field_validator

from rove.signing.ed25519 import sha256_file
from rove.targets import Target
from rove.targets import parse as parse_target

logger = logging.getLogger("rove.patches.loader")

__all__ = [
    "PatchEntry",
    "PatchKind",
    "PatchLoadError",
    "PatchSet",
    "load_patch_set",
    "resolve_patches",
]


# Soft-import packaging — fall back gracefully when unavailable.
try:  # pragma: no cover - exercised via fallback path
    from packaging.specifiers import InvalidSpecifier, SpecifierSet

    _HAS_PACKAGING = True
except ImportError:  # pragma: no cover - exercised via fallback path
    _HAS_PACKAGING = False


class PatchLoadError(RuntimeError):
    """Raised on missing files, hash mismatches, or schema violations."""


class PatchKind(StrEnum):
    """Kind of artifact a patch entry points at."""

    patch = "patch"
    env = "env"
    toml = "toml"


class PatchEntry(BaseModel):
    """A single entry in a patch index."""

    # Reject unknown keys: a typo like ``targe`` instead of ``target`` would
    # otherwise silently drop a constraint and apply the patch everywhere.
    model_config = ConfigDict(extra="forbid")

    id: str
    package: str
    version_spec: str = ""
    targets: list[Target]
    kind: PatchKind
    path: str
    sha256: str
    description: str | None = None

    @field_validator("sha256")
    @classmethod
    def _normalize_sha256(cls, value: str) -> str:
        """Lowercase the SHA-256 hex digest for stable comparison."""
        normalized = value.strip().lower()
        if len(normalized) != 64:
            raise ValueError(
                f"sha256 must be 64 hex chars, got {len(normalized)}"
            )
        try:
            int(normalized, 16)
        except ValueError as exc:
            raise ValueError(f"sha256 is not valid hex: {exc}") from exc
        return normalized

    @field_validator("targets", mode="before")
    @classmethod
    def _coerce_targets(cls, value: Any) -> list[Target]:
        """Accept either Target enum members or string aliases."""
        if not isinstance(value, list):
            raise ValueError("targets must be a list")
        out: list[Target] = []
        for item in value:
            if isinstance(item, Target):
                out.append(item)
            elif isinstance(item, str):
                out.append(parse_target(item))
            else:
                raise ValueError(
                    f"target entries must be str or Target, got {type(item).__name__}"
                )
        return out


class PatchSet(BaseModel):
    """A versioned collection of patch entries."""

    model_config = ConfigDict(extra="forbid")

    version: int = 1
    patches: list[PatchEntry] = Field(default_factory=list)


def _read_index(index_path: Path) -> dict[str, Any]:
    """Read and JSON-parse a patch index file."""
    try:
        raw = index_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise PatchLoadError(f"cannot read patch index {index_path}: {exc}") from exc
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise PatchLoadError(
            f"patch index {index_path} is not valid JSON: {exc}"
        ) from exc
    if not isinstance(data, dict):
        raise PatchLoadError(
            f"patch index {index_path} must be a JSON object, got {type(data).__name__}"
        )
    return data


def load_patch_set(source: Path) -> PatchSet:
    """Load a :class:`PatchSet` from a directory or JSON file.

    Args:
        source: Either a directory containing ``manifest.json`` (and the
            referenced patch files), or a path to the index JSON itself.
            Patch file paths inside the index are interpreted relative to
            the JSON's parent directory.

    Returns:
        The validated :class:`PatchSet`.

    Raises:
        PatchLoadError: Index missing/malformed, file missing on disk, or
            SHA-256 mismatch.
    """
    if source.is_dir():
        index_path = source / "manifest.json"
        if not index_path.is_file():
            raise PatchLoadError(
                f"patch directory {source} has no manifest.json"
            )
    else:
        index_path = source
        if not index_path.is_file():
            raise PatchLoadError(f"patch index {index_path} does not exist")

    data = _read_index(index_path)
    try:
        patch_set = PatchSet.model_validate(data)
    except ValidationError as exc:
        raise PatchLoadError(
            f"patch index {index_path} failed schema validation: {exc}"
        ) from exc

    # TRUST MODEL: the patch index itself is NOT covered by Ed25519 signing
    # in the current Rove release — only individual patch files are
    # fingerprinted by their ``sha256`` entries inside the index, which is
    # trust-on-first-use. Until the release manifest format extends to the
    # patch set, ``load_patch_set`` must only be pointed at a path the
    # caller curates and audits out-of-band. Surface the caveat loudly so
    # it never gets buried in a silent default.
    logger.warning(
        "patch index %s is consumed without Ed25519 signature verification. "
        "The sha256 entries protect patch files against drift but NOT "
        "against a tampered index — source %s must be curated by the "
        "caller (e.g. a pinned commit of the rove-patches repo).",
        index_path,
        source,
    )

    root = index_path.parent
    root_resolved = root.resolve()
    for entry in patch_set.patches:
        file_path = (root / entry.path).resolve()
        # Defense-in-depth: a tampered index could point at arbitrary host
        # files. Reject any entry whose resolved path escapes the patch set
        # root before any read/hash operation touches it.
        if not file_path.is_relative_to(root_resolved):
            raise PatchLoadError(
                f"patch entry {entry.id!r} path {entry.path!r} escapes "
                f"patch set root {root}"
            )
        if not file_path.is_file():
            raise PatchLoadError(
                f"patch entry {entry.id!r} references missing file {file_path}"
            )
        actual = sha256_file(file_path)
        if actual != entry.sha256:
            raise PatchLoadError(
                f"sha256 mismatch for patch entry {entry.id!r}: "
                f"index={entry.sha256} disk={actual} (path={file_path})"
            )

    return patch_set


def _spec_matches(version_spec: str, packages: list[str], package: str) -> bool:
    """Best-effort check that ``package`` satisfies ``version_spec``.

    The caller passes bare package names (no version pin), so we can
    only check the *form* of the specifier — we cannot know the
    concrete version of the dependency that pip will resolve. This
    function is therefore intentionally permissive: an empty or
    syntactically-invalid spec passes, and when :mod:`packaging` is
    unavailable the check is skipped entirely.
    """
    del packages, package  # unused — reserved for future tightening
    if not version_spec.strip():
        return True
    if not _HAS_PACKAGING:
        return True
    try:
        SpecifierSet(version_spec)
    except InvalidSpecifier:
        return False
    return True


def resolve_patches(
    patch_set: PatchSet,
    *,
    packages: list[str],
    target: Target,
) -> list[PatchEntry]:
    """Filter a patch set to entries that apply to the build context.

    An entry matches when its ``package`` is in ``packages`` *and* the
    requested ``target`` is in ``entry.targets``. The ``version_spec``
    field is checked best-effort (see :func:`_spec_matches`).

    Args:
        patch_set: The loaded patch set.
        packages: Bare package names being built (e.g.
            ``["psutil", "maturin"]``). Requirement strings like
            ``"pkg==1.0"`` should be parsed by the caller, not here.
        target: Concrete build target (resolve :attr:`Target.host`
            beforehand with :func:`rove.targets.resolve`).

    Returns:
        The list of matching :class:`PatchEntry` items, preserving the
        order they appear in ``patch_set.patches``.
    """
    package_set = {p.strip() for p in packages if p and p.strip()}
    matches: list[PatchEntry] = []
    for entry in patch_set.patches:
        if entry.package not in package_set:
            continue
        if target not in entry.targets:
            continue
        if not _spec_matches(entry.version_spec, packages, entry.package):
            continue
        matches.append(entry)
    return matches

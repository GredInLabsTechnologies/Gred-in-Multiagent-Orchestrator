"""Patches subsystem — load and resolve patches from the rove-patches registry."""

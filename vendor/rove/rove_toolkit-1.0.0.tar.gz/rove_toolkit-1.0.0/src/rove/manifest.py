"""
Rove Wheelhouse Manifest — canonical schema.

Describes a wheelhouse bundle (CPython + pre-built wheels + project
tree) produced by Rove and consumed by downstream installers and
runtime peers.

The manifest is signed with Ed25519; the signature covers the SHA-256
of the compressed tarball, not the manifest JSON itself. The exact
payload format is exposed by :meth:`WheelhouseManifest.signing_payload`
and is stable across implementations (Python, Kotlin, Rust) so that
non-Python consumers can re-derive and verify it without ambiguity.

The schema is intentionally minimal and stable so downstream runtime
bootstrappers (Kotlin/Android, Rust, plain Python) can re-derive the
signing payload from the JSON without depending on a specific
serializer.
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from rove.targets import Compression, Target


class WheelhouseManifest(BaseModel):
    """Canonical manifest for a Rove wheelhouse bundle.

    Example::

        manifest = WheelhouseManifest(
            project_name="my-app",
            runtime_version="0.1.0",
            target=Target.linux_x86_64,
            compression=Compression.zstd,
            tarball_name="my-app-runtime.tar.zst",
            tarball_sha256="abc123...",
            compressed_size_bytes=13_500_000,
            uncompressed_size_bytes=47_200_000,
            python_rel_path="python/bin/python3.11",
            project_root_rel_path="project",
            wheels_rel_path="wheelhouse",
            python_path_entries=["project", "site-packages"],
            files=["python/bin/python3.11", "site-packages/fastapi/__init__.py"],
            extra_env={"PYTHONDONTWRITEBYTECODE": "1"},
            patches_applied=["cpython-android-ssl"],
            signature="ed25519-hex",
        )
    """

    # ``extra="forbid"``: a manifest with unknown fields is never signed by
    # this producer, so consumers should treat it as malformed and refuse it.
    model_config = ConfigDict(extra="forbid")

    # Identification --------------------------------------------------------
    project_name: str = Field(
        description=(
            "Project identifier — lowercase letters, digits, dots, "
            "hyphens and underscores; must start with [a-z0-9]."
        ),
        min_length=1,
        pattern=r"^[a-z0-9][a-z0-9._-]*$",
    )
    runtime_version: str = Field(
        description=(
            "SemVer of the bundle — incremented on every release. "
            "The ``|`` character is forbidden because it is the payload "
            "separator in :meth:`signing_payload` and would otherwise "
            "allow a collision between ``(target, version)`` tuples."
        ),
        min_length=1,
        pattern=r"^[^|]+$",
    )
    target: Target = Field(
        description=(
            "Concrete target OS+arch of the bundle "
            "(android-arm64, windows-x86_64, ...). The ``host`` sentinel "
            "must be resolved before constructing the manifest."
        ),
    )

    # Payload ---------------------------------------------------------------
    compression: Compression = Field(
        default=Compression.xz,
        description="Compression algorithm applied to the tarball.",
    )
    tarball_name: str = Field(
        description="Tarball filename (e.g. ``my-app-runtime.tar.xz``).",
        min_length=1,
    )
    tarball_sha256: str = Field(
        description="SHA-256 hex (lowercase) of the compressed tarball.",
        pattern=r"^[0-9a-f]{64}$",
    )
    compressed_size_bytes: int = Field(
        ge=0,
        description="Size in bytes of the compressed tarball.",
    )
    uncompressed_size_bytes: int = Field(
        ge=0,
        description="Size in bytes of the expanded tree.",
    )

    # Layout (paths are relative to the extraction root) --------------------
    python_rel_path: str = Field(
        description="Path to the bundled CPython binary inside the bundle.",
        min_length=1,
    )
    project_root_rel_path: str = Field(
        description="Path to the project root inside the bundle.",
        min_length=1,
    )
    wheels_rel_path: str = Field(
        default="wheelhouse",
        description=(
            "Path inside the bundle where pre-built wheels live. "
            "Defaults to ``wheelhouse``."
        ),
        min_length=1,
    )
    python_path_entries: list[str] = Field(
        default_factory=list,
        description="Relative paths injected into ``PYTHONPATH``.",
    )
    files: list[str] = Field(
        default_factory=list,
        description="Explicit file list (used for bundle integrity checks).",
    )
    extra_env: dict[str, str] = Field(
        default_factory=dict,
        description="Extra environment variables for the runtime process.",
    )
    patches_applied: list[str] = Field(
        default_factory=list,
        description=(
            "IDs/names of patches applied during the build, kept for "
            "audit trail."
        ),
    )

    # Signature -------------------------------------------------------------
    signature: str = Field(
        description=(
            "Ed25519 signature (hex, lowercase) over the canonical "
            "signing payload — see :meth:`signing_payload`."
        ),
        pattern=r"^[0-9a-f]{128}$",
    )

    # Optional informative metadata -----------------------------------------
    python_version: str | None = Field(
        default=None,
        description="Bundled CPython version (informative).",
    )
    built_at: str | None = Field(
        default=None,
        description="ISO-8601 UTC timestamp of the build.",
    )
    builder: str | None = Field(
        default=None,
        description="Producer identifier (e.g. CI job ID or 'local-dev').",
    )

    @field_validator("tarball_sha256", "signature", mode="before")
    @classmethod
    def _lowercase_hex(cls, v: Any) -> Any:
        """Normalize hex strings to lowercase before pattern validation.

        SHA-256 and Ed25519 hex are canonical in lowercase; we accept
        uppercase input for convenience and normalize before applying
        the regex pattern.
        """
        if isinstance(v, str):
            return v.lower()
        return v

    @staticmethod
    def _check_rel_path(v: str) -> str:
        """Validate a single manifest-relative path string.

        Rejects:
          * Leading ``/`` (POSIX absolute) — silently stripped for
            compatibility with producers that prepend one by habit.
          * Windows drive letters (``C:\\...``) and UNC prefixes (``\\\\``).
          * Any ``..`` segment anywhere in the path. Without this check a
            signed manifest carrying ``python_rel_path="../../etc/passwd"``
            would pass validation and poison any downstream consumer that
            joins the field to an extraction root.
        """
        raw = v.strip()
        normalized = raw.lstrip("/").lstrip("\\")
        # Reject Windows drive-letter absolute paths (``C:/...``).
        if len(normalized) > 2 and normalized[1] == ":":
            raise ValueError(
                f"path must be relative, not an absolute Windows path: {v!r}"
            )
        # Reject UNC-style prefixes (``\\\\server\\share\\...``). We look at
        # the raw (pre-strip) form because the UNC leading ``\\\\`` gets
        # collapsed to ``\\`` + path otherwise.
        if raw.startswith("\\\\") or raw.startswith("//"):
            raise ValueError(
                f"path must be relative, not a UNC path: {v!r}"
            )
        # Reject ``..`` traversal anywhere in the path. Using os-agnostic
        # splitting on both separators so Windows producers cannot sneak
        # past by using backslashes.
        parts = normalized.replace("\\", "/").split("/")
        if any(p == ".." for p in parts):
            raise ValueError(
                f"path must not contain '..' segments: {v!r}"
            )
        return normalized

    @field_validator(
        "python_rel_path",
        "project_root_rel_path",
        "wheels_rel_path",
        "tarball_name",
    )
    @classmethod
    def _no_absolute_paths(cls, v: str) -> str:
        return cls._check_rel_path(v)

    @field_validator("python_path_entries", "files")
    @classmethod
    def _no_absolute_paths_list(cls, v: list[str]) -> list[str]:
        """Apply the relative-path check to every entry of a path list.

        ``python_path_entries`` is concatenated into ``PYTHONPATH`` by the
        runtime bootstrapper and ``files`` is consumed by integrity
        checkers that join each entry to the extraction root — both must
        be immune to traversal even though they are carried by a signed
        manifest, because a compromised signer is still a valid threat
        in the supply-chain model Rove defends against.
        """
        return [cls._check_rel_path(entry) for entry in v]

    def signing_payload(self) -> bytes:
        """Return the canonical bytes signed by :attr:`signature`.

        Stable format:
        ``<tarball_sha256>|<target>|<runtime_version>|<project_name>``
        encoded as UTF-8. This format is intentionally trivial so that
        any language (Python, Kotlin, Rust, ...) can re-derive it and
        verify the Ed25519 signature without depending on a specific
        JSON serializer.

        ``project_name`` is part of the payload to prevent cross-project
        confusion: without it, a key that signs multiple projects would
        let an attacker re-label a bundle from project A as project B
        (same sha/target/version) and still have a valid signature.

        Disambiguation: ``tarball_sha256`` is a fixed 64-char lowercase
        hex string (no ``|`` possible); ``target`` is constrained to the
        :class:`rove.targets.Target` StrEnum values (none contain
        ``|``); ``runtime_version`` has a Pydantic validator that
        forbids ``|`` explicitly; ``project_name`` is constrained by its
        regex pattern (``^[a-z0-9][a-z0-9._-]*$``) which forbids ``|``.
        The 4-tuple is therefore unambiguously reversible — no
        length-prefix needed.
        """
        return (
            f"{self.tarball_sha256}"
            f"|{self.target.value}"
            f"|{self.runtime_version}"
            f"|{self.project_name}"
        ).encode()

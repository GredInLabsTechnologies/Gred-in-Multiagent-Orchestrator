# Rove security model & operator runbook

Rove's scope is **signed wheelhouse distribution on a trusted LAN mesh**. Every claim below is what Rove v1.0.0 actually defends against in code today — no aspirational language.

## Threat model

### In scope

1. **Malicious peer on the mesh serving a tampered bundle.** Rove rejects it via Ed25519 signature verification + SHA-256 re-check on the final file. Tests: `test_verify_tampered_bundle_fails`, `test_fetch_bundle_sha_mismatch_cleans_up_holding`.

2. **Malicious peer serving an oversized manifest or bundle (OOM / disk-fill DoS).** Cap at 1 MiB for manifests, `compressed_size_bytes * 1.01` for bundles. Aborts mid-chunk with `DistributionError`. Tests: `test_http_get_bytes_refuses_*`, `test_http_download_streaming_refuses_oversized_payload`.

3. **Malicious peer redirecting the fetch off-host via 302.** `_StrictRedirectHandler` refuses cross-host and cross-scheme redirects at the urllib opener layer. Integration-tested live: `test_fetch_bundle_rejects_cross_host_redirect_live`.

4. **Malicious `--from` URL (`file://`, `ftp://`, `javascript://`, relative, hostless).** Rejected before any socket opens by `_validate_scheme`. Tests: `test_http_get_bytes_rejects_{file,ftp,relative,missing_host}`.

5. **Path traversal via a signed manifest.** `_no_absolute_paths` on the scalar fields (`python_rel_path`, `project_root_rel_path`, `wheels_rel_path`, `tarball_name`) **and** `_no_absolute_paths_list` on the list fields (`python_path_entries`, `files`) both route through the same `_check_rel_path` helper, which rejects `..` segments (both separators), UNC prefixes (`\\`, `//`), Windows drive letters, and strips leading `/`. A manifest carrying `python_rel_path="../../etc/passwd"` or `python_path_entries=["../../etc"]` fails validation before any downstream consumer can join the string to an extraction root.

6. **Symlink escape on a multi-user `rove serve` box.** `_BundleRequestHandler.do_GET` realpaths both the request target and the served root; anything not a prefix-child is 404'd. POSIX symlink test: `test_http_server_refuses_symlink_escape`; cross-platform mock test: `test_http_server_refuses_realpath_escape_mocked`.

7. **TOCTOU between hash check and file exposure.** SHA-256 is computed on the bundle **after** the atomic `os.replace` into the final output directory. Attacker-controlled staging can't swap the payload post-hash. Tests: `test_fetch_bundle_no_leftover_holding_file_on_success` + `test_fetch_bundle_cleans_stale_holding_file_before_rename`.

8. **Concurrent update daemons corrupting state.** Not applicable in V1 scope — `rove update` was reverted post-V0.2 audit. `_SAFE_OPENER` uses double-checked locking so concurrent `fetch_bundle` calls don't leak duplicate opener instances.

9. **Private key world-readable by default on Windows.** `rove keygen` invokes `icacls /inheritance:r /grant:r <user>:F` on `private.pem` to strip the inherited `Users:R` entry. Best-effort with explicit WARNING on failure.

10. **Private key race between create and chmod (POSIX).** `rove keygen` on POSIX opens `private.pem` with `O_EXCL | mode=0o600` from the start rather than `write_bytes()` followed by `chmod(0o600)`. Closes the short window in which a local user could snapshot the key while it still had the umask-default mode.

11. **`tarfile` path traversal / symlink escape (CVE-2007-4559 class).** `python_standalone._extract_tarball` passes `filter="data"` (PEP 706) when extracting the upstream CPython tarball, which strips setuid bits and rejects absolute paths, `..` traversal, and unsafe symlinks / hardlinks. Requires Python 3.11.4+ (hence `requires-python = ">=3.11.4"` in pyproject).

12. **Environment leakage from `pip download`.** `pip_runner._merged_env` replaces `os.environ.copy()` with an explicit allowlist (PATH, HOME, proxy vars, PIP_*, SSL_*, locale, Windows system vars). CI tokens, signing-key paths, and cloud credentials are no longer passed to pip subprocesses or the build hooks they invoke.

13. **Shell word-split in cross-compile env (`CC`/`CXX`/`AR`).** `zig.build_env_for` `shlex.quote`s the zig path so an install under `C:\Program Files\Zig\zig.exe` does not split into `C:\Program` + `Files\Zig\zig.exe` when cargo/setuptools/meson re-parse the env var as a shell command.

14. **Cross-project signature reuse.** `signing_payload()` is `<sha256>|<target>|<runtime_version>|<project_name>` — `project_name` is part of the payload so a key that signs bundles for multiple projects cannot have a signature from project A reused to authenticate a bundle re-labelled as project B. Test: `test_payload_binds_project_name`.

15. **Path traversal via a tampered `rove-patches` index.** `builder/patches._resolve_path` and `patches/loader.load_patch_set` both verify with `is_relative_to` that every referenced file resolves inside the patch-set root before any read/hash/apply. A tampered index with a `path` field like `"../../etc/passwd"` is rejected at load time. Tests: `test_resolve_path_rejects_escape`, `test_load_patch_set_rejects_traversal`.

16. **Unknown-field silent drop in typed configs.** `RoveConfig`, `WheelhouseManifest`, `PatchEntry`, and `PatchSet` have `model_config = ConfigDict(extra="forbid")`. Typos in `[tool.rove]` (`requrements` instead of `requirements`) or in a signed manifest fail validation instead of being silently ignored and producing a malformed bundle.

### Out of scope

- **Supply chain attack on PyPI packages in the wheelhouse.** Rove signs the *bundle*, not the individual wheels. If `pip download` pulls a compromised wheel, Rove's signature still validates — the poison was present at build time. Mitigation: pin every dependency, run `pip-audit` / Snyk before `rove build`, use a private index for sensitive projects.

- **Compromised signer.** Ed25519 signatures prove the bundle came from someone with the private key. If the key itself is stolen, the attacker can publish bundles Rove will happily verify. Mitigations: key rotation (see below), hardware-backed keys (out of scope for v0.1.x), external audit of signed bundles.

- **Compromise of the `rove-patches` registry.** The patch index is NOT Ed25519-signed in V1 — per-file SHA-256 protects against drift but a tampered index with re-computed hashes would pass unnoticed. The loader emits a loud WARNING. Treat `rove-patches` as a trust root you audit by pinning to a specific commit you reviewed. (Defense-in-depth: the loader **does** reject index entries whose resolved path escapes the patch-set root — a tampered index can still lie about content via re-hashing, but it cannot read arbitrary host files.)

- **Code signing for OS-native installers.** Rove does not produce `.msi`/`.app`/`.deb` (V0.2 was reverted pending proper integration work). When V0.2 returns, Authenticode / Apple Developer signing will be a user-supplied artifact — Rove will not broker the certs.

- **Network-level attacks beyond TLS**: Rove's fetch supports both `http://` and `https://`; on `http://` the signature still protects integrity but not confidentiality. Use `https://` endpoints for anything where the mere fact of requesting a particular version is sensitive.

- **Replay of old signed bundles.** An attacker with access to a previously-signed bundle can re-serve it. Rove has no version-monotonicity check on fetch — the consumer is responsible for tracking which version they want. Consumers that care about replay should pin `--runtime-version`.

## Key management runbook

### Generation

```bash
rove keygen --out ./keys
```

Two files land in `./keys/`: `private.pem` and `public.pem`.

**POSIX:** `private.pem` is `0o600`, `public.pem` is `0o644`.

**Windows:** `private.pem`'s ACL is tightened to `<current_user>:F`, inheritance disabled. If `icacls` is missing or `USERNAME` is unset, a WARNING fires — the key is still written but with default ACL. Secure it manually before use.

### Storage

- Keep `private.pem` **off** the mesh. It signs; it never travels. Store on an operator workstation or a hardware token (out of scope today).
- Distribute `public.pem` freely — every peer that needs to `verify` or `fetch` needs to trust it.
- Never commit `private.pem` to git. Add `*.pem` to `.gitignore` unless the repo *is* the pubkey distribution channel.

### Trust distribution

Three ways to tell `rove verify` / `rove fetch` which public keys to trust (any of these works; all three can coexist):

1. **Environment variable** (per-session, best for CI):

   ```bash
   export ROVE_TRUSTED_PUBKEYS="$(cat key1.pem),$(cat key2.pem)"
   ```

   Accepts a comma-separated list; each entry is either a full PEM block (newlines may be `\n`-escaped) or base64 of a 32-byte raw Ed25519 pubkey.

2. **User-wide directory** (per-operator, best for workstations):

   ```bash
   mkdir -p ~/.config/rove/trusted_keys
   cp ./keys/public.pem ~/.config/rove/trusted_keys/prod-2026.pem
   ```

   Every `*.pem` in the directory is loaded.

3. **Explicit CLI flag** (per-invocation, best for scripts):

   ```bash
   rove verify --bundle … --pubkey ./keys/public.pem --pubkey ./keys/backup.pem
   ```

### Rotation

Ed25519 keys do not need emergency rotation on a schedule — but you will want a planned key rollover to migrate away from a key shared too widely.

**Roll-forward procedure (no downtime):**

1. Generate key B: `rove keygen --out ./keys-b`.
2. Distribute `public_b.pem` alongside the existing `public_a.pem`. Every `rove verify` / `rove fetch` consumer now trusts both.
3. For some grace window (days / weeks), keep signing with key A.
4. Cut over: start signing with key B.
5. When enough bundles have rotated (peers have re-fetched), retire `public_a.pem` — remove it from `ROVE_TRUSTED_PUBKEYS` and `~/.config/rove/trusted_keys/`.

At every step, `verify_manifest` succeeds on the first trusted key that matches — callers with `[pub_a, pub_b]` in the trust set handle both old and new bundles seamlessly.

**Emergency rotation (compromised key):**

1. Immediately generate key B on a clean workstation.
2. Re-sign every in-flight bundle you want to keep valid: `rove sign --bundle X --key ./keys-b/private.pem` for each. The sidecar manifest is replaced; tarballs are untouched.
3. Push the re-signed bundles to every serve node.
4. Remove `public_a.pem` from trust stores **across every consumer**. Until this step is done on every consumer, the compromised key can still sign bundles that validate.
5. Rotate any credentials that had access to the old private key (CI secrets, workstation encryption, etc.).

### Backup

Back up `private.pem` out-of-band — encrypted, physical separation from the workstation. Losing the key without a backup means emergency rotation on every peer. Keeping it on the same disk as the public key means a single-device compromise yields everything.

## Reporting a vulnerability

Open an issue with the `security` label in this repository until a private disclosure channel is formalised. Provide: reproduction steps, affected version, impact assessment, and whether you believe the finding is already public. Do not open a public PR that includes an exploit before we've had a chance to ship a fix.

## Audit log

Every release that closes a security finding documents it in [`CHANGELOG.md`](../CHANGELOG.md) under `Security`. The V0.1.2 / V0.1.3 entries capture the post-audit hardening pass; future security-only releases land as patch versions.

# Rove configuration reference

Rove reads project-level settings from the **`[tool.rove]`** table in your `pyproject.toml`, or — if you prefer to keep it separate — from a standalone **`rove.toml`** at the project root. If both exist, `rove.toml` is read first and `pyproject.toml` is ignored.

The full schema lives in [`src/rove/config.py`](../src/rove/config.py) as a Pydantic model; the file below is the source of truth for user-facing semantics.

## Location resolution

`rove build` / `rove sign` / `rove verify` search for config in this order, walking **upward** from the current working directory:

1. Explicit `--config PATH` on the command line.
2. `rove.toml` in any ancestor directory.
3. `pyproject.toml` with a `[tool.rove]` table.
4. `pyproject.toml` without `[tool.rove]` — the `[project]` table alone is acceptable; Rove fills in defaults.

If none of the above is found, the command exits `2` with a clear error. No implicit fallback to `$HOME` or system-wide config.

## Fields

### `project_name` (string, required)

Project identifier used in the bundle filename and the signed manifest. Must match `^[a-z0-9][a-z0-9._-]*$`: lowercase letters, digits, dots, underscores, hyphens. Starts with `[a-z0-9]`.

Defaults to `[project].name` from `pyproject.toml` if unset.

### `version` (string, default `"0.0.0"`)

SemVer of the produced bundle. Stamped into `runtime_version` in the manifest and into the bundle filename.

**Restriction:** cannot contain the `|` character — that's the separator in the Ed25519 signing payload and the Pydantic validator will reject. Semver, CalVer (`2026.04.17`), pre-release (`1.0.0-rc.1`) and build-metadata (`1.0.0+build.42`) are all fine.

Defaults to `[project].version` from `pyproject.toml` if unset.

### `include` (list of strings, default `["src"]`)

Paths or globs (relative to the config file's parent directory) to bundle. Each entry is either a literal subpath (`src`) or a glob (`packages/*`). Missing literal entries are silently skipped — a project may declare optional dirs.

Examples:

```toml
include = ["src", "data", "config/templates"]
include = ["packages/*", "vendor/*/src"]
```

### `exclude` (list of strings, default `["tests/", "*.pyc", "__pycache__/"]`)

`fnmatch` patterns applied to every file candidate produced by `include`. Matches against basename, full POSIX path, any path segment, or path prefix (directory-style). Trailing `/` marks the pattern as a directory match — `tests/` excludes the `tests` dir and everything below.

### `targets` (list of strings, default `["host"]`)

Target tuples the project is built for. Each string parses via `rove.targets.parse`. Use `host` for the current machine; concrete targets for cross-platform builds. See [`COMMANDS.md`](COMMANDS.md#supported-targets) for the full list.

```toml
targets = ["host"]
targets = ["linux-x86_64", "linux-arm64", "darwin-arm64", "windows-x86_64"]
```

### `patches` (list of strings, default `[]`)

Names of patch sets from the `rove-patches` registry to apply pre-build. Each string matches a directory (or a manifest.json) in your local `rove-patches` checkout.

```toml
patches = ["python-bionic"]   # apply Android/Termux long-tail fixes
```

**Trust.** The patch index is loaded without Ed25519 signature verification in V1 — per-file SHA-256 protects against file drift but NOT against a tampered index. Curate the `rove-patches` path out-of-band (pin to a commit you audited). See [`SECURITY.md`](SECURITY.md) "Out of scope" section for the trust implications.

### `sign_key` (string or null, default `null`)

Path to the Ed25519 private key used by `rove sign`. Supports `${ENV_VAR}` expansion — the `rove sign` command refuses to run if a referenced env var is unset (no silent fallback to empty string).

```toml
sign_key = "${ROVE_SIGN_KEY_PATH}"
sign_key = "./keys/private.pem"
```

### `requirements` (list of strings, default `null`)

Explicit Python dependency list. When set, overrides `[project].dependencies` from `pyproject.toml`.

```toml
requirements = [
    "cryptography>=43.0.0",
    "pydantic>=2.11",
    "typer>=0.12",
]
```

If `requirements` is `null`, Rove reads `[project].dependencies` from `pyproject.toml`. If that is also missing, the bundle is built without any pre-installed wheels (useful when the consumer manages its own pip install).

## Example: minimal

```toml
[tool.rove]
project_name = "myapp"
version = "0.1.0"
```

Produces a `myapp-<host>-0.1.0.tar.xz` with `./src` bundled and the target's default wheels.

## Example: multi-target with signing

```toml
[project]
name = "myapp"
version = "0.1.0"
dependencies = ["cryptography>=43.0.0", "pydantic>=2.11"]

[tool.rove]
project_name = "myapp"
include = ["src", "data"]
exclude = ["tests/", "docs/", "*.pyc", "__pycache__/"]
targets = ["linux-x86_64", "linux-arm64", "darwin-arm64", "windows-x86_64"]
sign_key = "${ROVE_SIGN_KEY_PATH}"
```

## Example: Android cross-build with patch set

```toml
[project]
name = "myapp"
version = "0.1.0"
dependencies = ["psutil>=6.0.0", "cryptography>=43.0.0"]

[tool.rove]
project_name = "myapp"
include = ["src"]
targets = ["android-arm64"]
patches = ["python-bionic"]   # point at local rove-patches checkout
sign_key = "${ROVE_SIGN_KEY_PATH}"
```

With `rove build --target android-arm64 --patch-set ../rove-patches --no-python`, the `psutil` platform-android refusal is patched pre-build.

## Validation

Every field is Pydantic-validated. Type mismatches, unknown targets, `|` in `version`, empty `project_name`, non-list `targets` etc. all raise `ConfigError` with a clear message pointing at the bad field. No silent coercion.

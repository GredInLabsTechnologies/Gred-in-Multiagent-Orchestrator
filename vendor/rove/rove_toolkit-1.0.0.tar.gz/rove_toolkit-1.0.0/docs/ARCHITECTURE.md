# Rove — Architecture

**Status**: living document, evolves with the implementation.

## Concepts

### Wheelhouse Capsule

The unit Rove produces and consumes is a **Capsule**: a deterministic `.tar.xz` containing
- a wheelhouse (resolved `.whl` files for one target tuple)
- a CPython runtime (optional, when `python_standalone=true`)
- a `manifest.json` (Pydantic-validated, `WheelhouseManifest` schema)
- an Ed25519 signature over the canonical signing payload

The signing payload is intentionally minimal and stable across format revisions:
```
<tarball_sha256>|<target>|<runtime_version>|<project_name>
```
Easy to reproduce in any language (Python, Kotlin, Rust) without JSON serialization
ambiguities. `project_name` is part of the payload so a key that signs multiple
projects cannot have a signature from project A reused to authenticate project B.

### Target

A `Target` is an `(os, arch)` tuple that maps to a `python-build-standalone` triple
plus, when relevant, a libc family (glibc/musl/bionic). See `rove.targets.Target`.

### Patch

A `Patch` is a versioned, metadata-tagged fix applied **pre-build** to make a Python
distribution build cleanly on a specific target. Three kinds:

- `*.patch` — unified diff applied to a downloaded sdist
- `*.env` — environment variable injections for the build subprocess
- `*.toml` — declarative substitutions (e.g. force `--prefer-binary` for a package)

Patches live in the companion repo
[`GredInLabsTechnologies/rove-patches`](https://github.com/GredInLabsTechnologies/rove-patches)
with metadata `(pkg_name, version_range, target_match)` so they apply only when relevant.

## Subsystems

```
   ┌─────────────────────────────────────────────────────────────┐
   │  rove.cli (Typer)                                            │
   │   keygen · build · sign · verify · serve · fetch             │
   └────────────┬────────────────────┬───────────────┬───────────┘
                │                    │               │
   ┌────────────▼─────────┐ ┌────────▼────────┐ ┌────▼──────────────┐
   │  rove.builder        │ │  rove.signing   │ │  rove.distribution│
   │   pip_runner         │ │   ed25519       │ │   http_server     │
   │   python_standalone  │ │   keygen        │ │   http_fetcher    │
   │   zig                │ └────────┬────────┘ │   plugin (Protocol)│
   │   patches            │          │          └────┬──────────────┘
   │   tarball            │          │               │
   └────────────┬─────────┘          │               │
                │                    │               │
                └────────┬───────────┴───────────────┘
                         │
                ┌────────▼─────────┐
                │  rove.manifest   │
                │  rove.targets    │
                │  rove.config     │
                └──────────────────┘
                         │
                ┌────────▼─────────┐
                │  rove.patches    │  ← rove-patches repo (data only)
                └──────────────────┘
```

## Distribution plugin protocol

Out of the box, Rove ships an HTTP backend (`rove serve`, `rove fetch`). Any external
project can implement a custom `DistributionBackend` to plug in content-addressed P2P
(Iroh), mesh-native delivery (a peer-to-peer mesh dispatcher + signed-trust gateway),
object storage (S3, GCS), or anything else.

```python
from typing import Protocol
from pathlib import Path
from rove.manifest import WheelhouseManifest
from rove.targets import Target

class DistributionBackend(Protocol):
    def publish(
        self,
        manifest: WheelhouseManifest,
        payload: Path,
    ) -> str:
        """Make the bundle available; return a discovery URI/handle."""
        ...

    def fetch(
        self,
        target: Target,
        version: str | None = None,
    ) -> tuple[WheelhouseManifest, Path]:
        """Resolve, download, verify; return (manifest, local_payload_path)."""
        ...
```

The plugin stays in the consumer's repo — Rove does not vendor mesh/P2P libraries
into its core dependency tree.

## Trust model

- **Signing**: Ed25519 over the canonical payload (`sha256|target|version|project_name`).
- **Verification**: trusted public keys are loaded from (in order) `ROVE_TRUSTED_PUBKEYS`
  env var (comma-separated PEM-base64 list), `~/.config/rove/trusted_keys/`, and the
  `--pubkey` CLI flag. Multiple keys allow rotation without breaking older bundles.
- **Patches**: must be signed by a trusted patch-maintainer key (separate trust root from
  the bundle signing key, to allow community contributions to `rove-patches` without
  granting bundle-signing authority).

## Out of scope (for V1)

- Application-level governance gating (cost / risk / trust evaluation) — those policies belong in the consumer's adapter, not in Rove core
- Iroh/QUIC peer-routing (plug-in)
- PyPI publishing automation (deferred to `release.yml`)
- Reproducible-builds bit-for-bit identity (best-effort determinism only)

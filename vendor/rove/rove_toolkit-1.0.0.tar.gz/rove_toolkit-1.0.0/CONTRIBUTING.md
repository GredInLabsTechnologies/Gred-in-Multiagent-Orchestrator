# Contributing to Rove

Thanks for your interest. Rove is an alpha-stage project under [Gred In Labs Technologies](https://github.com/GredInLabsTechnologies); the public API is not yet frozen, but we take correctness and security seriously.

## Ground rules

1. **Mocks are not proof.** A test that monkey-patches the function it claims to verify is a tautology. Integration tests against real subprocesses / real HTTP servers are required for any security-relevant path.
2. **100% line + branch coverage is the floor, not the ceiling.** Every `# pragma: no cover` entry must carry a one-line comment explaining why the line is genuinely unreachable. PRs that exclude coverage without justification will be asked to rewrite.
3. **Minimal diffs.** Touch the fewest files and lines needed to solve the problem cleanly. Avoid drive-by refactors — file a separate issue instead.
4. **Honest error types.** Every public function must surface a domain exception (`DistributionError`, `RuntimeSignatureError`, `PatchLoadError`, `ConfigError`, `TarballBuildError`). Leaking `OSError` / `URLError` / `ValueError` through a public boundary is a bug.
5. **No new dependencies without justification.** Rove deliberately ships on stdlib + `cryptography` + `pydantic` + `typer` + `rich`. Proposing an additional dep requires evidence that stdlib cannot solve the problem cleanly.

## Dev setup

```bash
git clone https://github.com/GredInLabsTechnologies/rove.git
cd rove
python -m venv .venv
. .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -e .[dev]
```

## Running the gates locally

All four must pass before a PR is mergeable:

```bash
ruff check src/ tests/           # style + common bug patterns
mypy src/rove                    # strict type checking (enforced)
pytest tests/ --cov=src/rove --cov-fail-under=100
```

On Windows, three tests skip (two POSIX chmod, one real-symlink). That's expected. CI covers the POSIX paths.

## End-to-end smoke test

Before requesting review for any change that touches `cli.py`, `http_fetcher.py`, `http_server.py`, `manifest.py`, `signing/`, or `builder/tarball.py`, run this on your local machine:

```bash
# 1. Keygen
python -m rove.cli keygen --out ./keys/

# 2. Build (self-hosting: rove builds itself for the host target)
python -m rove.cli build --target host --output ./dist/

# 3. Sign
BUNDLE=$(ls ./dist/*.tar.xz | head -1)
python -m rove.cli sign --bundle "$BUNDLE" --key ./keys/private.pem

# 4. Verify
python -m rove.cli verify --bundle "$BUNDLE" --pubkey ./keys/public.pem

# 5. Tamper-detection
echo "TAMPER" >> "$BUNDLE"
python -m rove.cli verify --bundle "$BUNDLE" --pubkey ./keys/public.pem  # expect exit 1

# 6. Scheme rejection
python -m rove.cli fetch --from "file:///etc/passwd" --target host \
  --project-name foo --runtime-version 0.1.0 --out ./fetched/  # expect exit 1
```

## Filing a PR

- One bounded objective per PR.
- Include a description: what changed, why, what alternatives you rejected.
- Attach the output of the four gates above.
- For security-relevant changes, include the attack scenario the fix closes.
- Changes to `src/rove/manifest.py` `signing_payload` semantics require a migration note in `CHANGELOG.md` — the payload format is a wire contract.

## Reporting a vulnerability

Email security@example (placeholder — open an issue labelled `security` for now; we will rotate to a private disclosure channel once the v0.2 track is active).

## Licence

By contributing you agree that your contribution is licensed under the [MIT License](LICENSE) that covers this repository.

"""Tests for :mod:`rove.targets`."""
from __future__ import annotations

import pytest

from rove import targets as targets_module
from rove.targets import Compression, Target, detect_host, parse, resolve


class TestEnumIntegrity:
    def test_target_values_are_unique(self) -> None:
        values = [t.value for t in Target]
        assert len(values) == len(set(values))

    def test_target_has_host_sentinel(self) -> None:
        assert Target.host.value == "host"

    @pytest.mark.parametrize(
        "member,value",
        [
            (Compression.xz, "xz"),
            (Compression.zstd, "zstd"),
            (Compression.none, "none"),
        ],
    )
    def test_compression_members(self, member: Compression, value: str) -> None:
        assert member.value == value

    def test_compression_values_unique(self) -> None:
        values = [c.value for c in Compression]
        assert len(values) == len(set(values))


class TestParseRoundTrip:
    @pytest.mark.parametrize("target", list(Target))
    def test_parse_roundtrips_each_value(self, target: Target) -> None:
        assert parse(target.value) is target

    @pytest.mark.parametrize(
        "raw,expected",
        [
            ("linux-x86_64", Target.linux_x86_64),
            ("linux_x86_64", Target.linux_x86_64),
            ("LINUX-X86_64", Target.linux_x86_64),
            ("Linux-X86_64", Target.linux_x86_64),
            ("ANDROID-ARM64", Target.android_arm64),
            ("Windows-X86_64", Target.windows_x86_64),
        ],
    )
    def test_parse_case_and_separator_insensitive(
        self, raw: str, expected: Target
    ) -> None:
        assert parse(raw) is expected


class TestParseAliases:
    @pytest.mark.parametrize(
        "alias,expected",
        [
            ("linux-x64", Target.linux_x86_64),
            ("linux-amd64", Target.linux_x86_64),
            ("linux-aarch64", Target.linux_arm64),
            ("android-aarch64", Target.android_arm64),
            ("android-arm", Target.android_armv7),
            ("win-amd64", Target.windows_x86_64),
            ("win-x64", Target.windows_x86_64),
            ("windows-amd64", Target.windows_x86_64),
            ("macos-arm64", Target.darwin_arm64),
            ("macos-x64", Target.darwin_x86_64),
            ("darwin-aarch64", Target.darwin_arm64),
        ],
    )
    def test_curated_aliases(self, alias: str, expected: Target) -> None:
        assert parse(alias) is expected

    @pytest.mark.parametrize("alias", ["host", "current", "native", "HOST", "Native"])
    def test_host_aliases(self, alias: str) -> None:
        assert parse(alias) is Target.host


class TestParseRejects:
    @pytest.mark.parametrize("bad", ["", "   ", "\t", "\n"])
    def test_rejects_empty_or_whitespace(self, bad: str) -> None:
        with pytest.raises(ValueError):
            parse(bad)

    @pytest.mark.parametrize(
        "bad",
        ["not-a-target", "linux", "x86_64", "android", "freebsd-x86_64", "linux-mips"],
    )
    def test_rejects_unknown_targets(self, bad: str) -> None:
        with pytest.raises(ValueError):
            parse(bad)

    def test_rejects_non_string(self) -> None:
        with pytest.raises(ValueError):
            parse(None)  # type: ignore[arg-type]


class TestDetectHost:
    def test_returns_concrete_target(self) -> None:
        host = detect_host()
        assert host in set(Target) - {Target.host}

    def test_consistent_across_calls(self) -> None:
        assert detect_host() is detect_host()

    def test_raises_on_unsupported_platform(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(
            targets_module.platform, "system", lambda: "Plan9"
        )
        monkeypatch.setattr(
            targets_module.platform, "machine", lambda: "alpha"
        )
        with pytest.raises(RuntimeError):
            detect_host()

    def test_raises_on_unknown_machine(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(
            targets_module.platform, "system", lambda: "Linux"
        )
        monkeypatch.setattr(
            targets_module.platform, "machine", lambda: "mips64"
        )
        with pytest.raises(RuntimeError):
            detect_host()

    @pytest.mark.parametrize(
        "system,machine,expected",
        [
            ("Linux", "x86_64", Target.linux_x86_64),
            ("Linux", "amd64", Target.linux_x86_64),
            ("Linux", "aarch64", Target.linux_arm64),
            ("Linux", "arm64", Target.linux_arm64),
            ("Darwin", "arm64", Target.darwin_arm64),
            ("Darwin", "x86_64", Target.darwin_x86_64),
            ("Windows", "AMD64", Target.windows_x86_64),
        ],
    )
    def test_detects_known_platforms(
        self,
        monkeypatch: pytest.MonkeyPatch,
        system: str,
        machine: str,
        expected: Target,
    ) -> None:
        monkeypatch.setattr(targets_module.platform, "system", lambda: system)
        monkeypatch.setattr(targets_module.platform, "machine", lambda: machine)
        assert detect_host() is expected

    @pytest.mark.parametrize(
        "system,machine",
        [
            # Darwin matched, machine doesn't → covers branch 115->121
            ("Darwin", "ppc64"),
            # Windows matched, machine doesn't → covers branch 118->121
            ("Windows", "ia64"),
        ],
    )
    def test_known_system_unknown_machine_raises(
        self,
        monkeypatch: pytest.MonkeyPatch,
        system: str,
        machine: str,
    ) -> None:
        """Cover the falls-through branches when system matches but machine doesn't."""
        monkeypatch.setattr(targets_module.platform, "system", lambda: system)
        monkeypatch.setattr(targets_module.platform, "machine", lambda: machine)
        with pytest.raises(RuntimeError):
            detect_host()


class TestResolve:
    def test_resolve_host_equals_detect_host(self) -> None:
        assert resolve(Target.host) is detect_host()

    @pytest.mark.parametrize(
        "concrete",
        [t for t in Target if t is not Target.host],
    )
    def test_resolve_concrete_is_identity(self, concrete: Target) -> None:
        assert resolve(concrete) is concrete

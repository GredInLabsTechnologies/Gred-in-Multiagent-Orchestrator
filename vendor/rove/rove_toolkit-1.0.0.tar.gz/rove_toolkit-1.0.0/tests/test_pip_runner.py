"""Tests for rove.builder.pip_runner — pip download wrapper."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest
from pydantic import ValidationError

from rove.builder import pip_runner
from rove.builder.pip_runner import (
    PipError,
    PipRunOptions,
    run_pip_download,
)
from rove.targets import Target


@pytest.fixture
def fake_python(tmp_path: Path) -> Path:
    p = tmp_path / "python_exe"
    p.write_text("#!/bin/sh\n")
    p.chmod(0o755)
    return p


@pytest.fixture
def opts(fake_python: Path, tmp_path: Path) -> PipRunOptions:
    return PipRunOptions(
        requirements=["psutil==6.0.0"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels",
    )


def test_empty_requirements_rejected(fake_python: Path, tmp_path: Path) -> None:
    with pytest.raises(ValidationError):
        PipRunOptions(
            requirements=[],
            target=Target.linux_x86_64,
            python_executable=fake_python,
            output_dir=tmp_path / "wheels",
        )


def test_whitespace_only_requirements_rejected(
    fake_python: Path, tmp_path: Path
) -> None:
    with pytest.raises(ValidationError):
        PipRunOptions(
            requirements=["   ", ""],
            target=Target.linux_x86_64,
            python_executable=fake_python,
            output_dir=tmp_path / "wheels",
        )


def test_missing_python_executable_rejected(tmp_path: Path) -> None:
    with pytest.raises(ValidationError):
        PipRunOptions(
            requirements=["psutil"],
            target=Target.linux_x86_64,
            python_executable=tmp_path / "does_not_exist",
            output_dir=tmp_path / "wheels",
        )


def test_run_pip_download_invokes_subprocess(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        captured["kwargs"] = kwargs
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="ok", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    result = run_pip_download(opts)

    assert result.returncode == 0
    assert result.stdout == "ok"
    argv = captured["argv"]
    assert argv[0] == str(opts.python_executable)
    assert argv[1:4] == ["-m", "pip", "download"]
    assert "--dest" in argv
    assert str(opts.output_dir) in argv
    assert "psutil==6.0.0" in argv


def test_wheels_collected_from_output_dir(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    def fake_run(argv, **kwargs):
        opts.output_dir.mkdir(parents=True, exist_ok=True)
        (opts.output_dir / "psutil-6.0.0-cp313-cp313-linux_x86_64.whl").write_bytes(
            b"fake wheel"
        )
        (opts.output_dir / "extra-1.0.0-py3-none-any.whl").write_bytes(b"x")
        (opts.output_dir / "not_a_wheel.txt").write_text("ignore me")
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    result = run_pip_download(opts)

    assert len(result.wheels_collected) == 2
    assert all(p.suffix == ".whl" for p in result.wheels_collected)


def test_failed_pip_run_raises(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    def fake_run(argv, **kwargs):
        return subprocess.CompletedProcess(
            args=argv,
            returncode=1,
            stdout="",
            stderr="ERROR: could not resolve psutil==999.999.999",
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    with pytest.raises(PipError, match="could not resolve"):
        run_pip_download(opts)


def test_extra_env_merged_into_subprocess(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch, fake_python: Path, tmp_path: Path
) -> None:
    opts2 = PipRunOptions(
        requirements=["psutil"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels2",
        extra_env={"PIP_INDEX_URL": "https://my.index/", "FOO": "bar"},
    )
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["env"] = kwargs.get("env")
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    run_pip_download(opts2)

    env = captured["env"]
    assert env["PIP_INDEX_URL"] == "https://my.index/"
    assert env["FOO"] == "bar"
    # Original env should also be present (PATH at least).
    assert "PATH" in env or len(env) > 2


def test_extra_args_appended(
    fake_python: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    opts = PipRunOptions(
        requirements=["psutil"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels",
        extra_args=["--platform", "manylinux2014_x86_64", "--only-binary", ":all:"],
    )
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    run_pip_download(opts)

    argv = captured["argv"]
    assert "--platform" in argv
    assert "manylinux2014_x86_64" in argv
    assert "--only-binary" in argv


def test_prefer_binary_flag(
    fake_python: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    opts = PipRunOptions(
        requirements=["psutil"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels",
        prefer_binary=True,
    )
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    run_pip_download(opts)
    assert "--prefer-binary" in captured["argv"]


def test_prefer_binary_disabled(
    fake_python: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    opts = PipRunOptions(
        requirements=["psutil"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels",
        prefer_binary=False,
    )
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    run_pip_download(opts)
    assert "--prefer-binary" not in captured["argv"]


def test_timeout_propagates(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch, fake_python: Path, tmp_path: Path
) -> None:
    opts2 = PipRunOptions(
        requirements=["psutil"],
        target=Target.linux_x86_64,
        python_executable=fake_python,
        output_dir=tmp_path / "wheels_t",
        timeout_seconds=42,
    )
    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["timeout"] = kwargs.get("timeout")
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    run_pip_download(opts2)
    assert captured["timeout"] == 42


def test_timeout_expired_raises_piperror(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    def fake_run(argv, **kwargs):
        raise subprocess.TimeoutExpired(cmd=argv, timeout=opts.timeout_seconds)

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    with pytest.raises(PipError, match="timed out"):
        run_pip_download(opts)


def test_failed_pip_run_with_empty_stderr(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Non-zero exit with empty stderr → covers _stderr_tail early-return (line 139)."""
    def fake_run(argv, **kwargs):
        return subprocess.CompletedProcess(
            args=argv, returncode=2, stdout="", stderr=""
        )

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    with pytest.raises(PipError) as ei:
        run_pip_download(opts)
    # The tail should have been the empty string, so the message has no
    # appended stderr content.
    assert "rc=2" in str(ei.value)


def test_python_executable_filenotfound_raises_piperror(
    opts: PipRunOptions, monkeypatch: pytest.MonkeyPatch
) -> None:
    """subprocess.run raises FileNotFoundError → covers lines 187-188."""
    def fake_run(argv, **kwargs):
        raise FileNotFoundError("python missing")

    monkeypatch.setattr(pip_runner.subprocess, "run", fake_run)
    with pytest.raises(PipError, match="python executable not found"):
        run_pip_download(opts)

"""Tests for rove.builder.patches — env/diff/toml appliers."""
from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

import pytest

from rove.builder import patches as patches_mod
from rove.builder.patches import (
    AppliedPatches,
    PatchApplyError,
    apply_all,
    apply_env_patches,
    apply_unified_diff,
    read_toml_overrides,
)
from rove.patches.loader import PatchEntry, PatchKind
from rove.targets import Target


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _entry(
    root: Path,
    *,
    rel_path: str,
    kind: PatchKind,
    content: str,
    package: str = "demo",
    targets: list[Target] | None = None,
    eid: str | None = None,
) -> PatchEntry:
    full = root / rel_path
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content, encoding="utf-8")
    return PatchEntry(
        id=eid or f"demo/{rel_path}",
        package=package,
        version_spec="",
        targets=targets or [Target.linux_x86_64],
        kind=kind,
        path=rel_path,
        sha256=_sha256(full),
    )


def test_env_patches_simple_kv(tmp_path: Path) -> None:
    entry = _entry(
        tmp_path,
        rel_path="env/a.env",
        kind=PatchKind.env,
        content="FOO=bar\nBAZ=qux\n",
    )
    out = apply_env_patches([entry], tmp_path)
    assert out == {"FOO": "bar", "BAZ": "qux"}


def test_env_patches_skip_comments_and_blanks(tmp_path: Path) -> None:
    entry = _entry(
        tmp_path,
        rel_path="env/b.env",
        kind=PatchKind.env,
        content="# header comment\n\nFOO=bar\n  # leading-space comment\nBAZ=qux\n\n",
    )
    out = apply_env_patches([entry], tmp_path)
    assert out == {"FOO": "bar", "BAZ": "qux"}


def test_env_patches_malformed_raises(tmp_path: Path) -> None:
    entry = _entry(
        tmp_path,
        rel_path="env/bad.env",
        kind=PatchKind.env,
        content="GOODKEY=value\nbadlinewithnoequals\n",
    )
    with pytest.raises(PatchApplyError, match="malformed"):
        apply_env_patches([entry], tmp_path)


def test_env_patches_later_overrides_earlier(tmp_path: Path) -> None:
    e1 = _entry(
        tmp_path,
        rel_path="env/first.env",
        kind=PatchKind.env,
        content="SHARED=first\nUNIQUE_A=a\n",
        eid="first",
    )
    e2 = _entry(
        tmp_path,
        rel_path="env/second.env",
        kind=PatchKind.env,
        content="SHARED=second\nUNIQUE_B=b\n",
        eid="second",
    )
    out = apply_env_patches([e1, e2], tmp_path)
    assert out["SHARED"] == "second"
    assert out["UNIQUE_A"] == "a"
    assert out["UNIQUE_B"] == "b"


def test_apply_unified_diff_success(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    entry = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )

    monkeypatch.setattr(patches_mod.shutil, "which", lambda name: "/usr/bin/patch")

    captured: dict = {}

    def fake_run(argv, **kwargs):
        captured["argv"] = argv
        captured["cwd"] = kwargs.get("cwd")
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        )

    monkeypatch.setattr(patches_mod.subprocess, "run", fake_run)
    result = apply_unified_diff(entry, tmp_path, sdist)
    assert result is None
    assert "patch" in captured["argv"][0]
    assert captured["cwd"] == str(sdist)


def test_apply_unified_diff_failure_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    entry = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )

    monkeypatch.setattr(patches_mod.shutil, "which", lambda name: "/usr/bin/patch")
    monkeypatch.setattr(
        patches_mod.subprocess,
        "run",
        lambda argv, **kw: subprocess.CompletedProcess(
            args=argv, returncode=1, stdout="", stderr="hunk failed"
        ),
    )

    with pytest.raises(PatchApplyError, match="failed"):
        apply_unified_diff(entry, tmp_path, sdist)


def test_apply_unified_diff_missing_patch_binary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    entry = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )

    monkeypatch.setattr(patches_mod.shutil, "which", lambda name: None)

    with pytest.raises(PatchApplyError, match="patch"):
        apply_unified_diff(entry, tmp_path, sdist)


def test_read_toml_overrides_in_order(tmp_path: Path) -> None:
    e1 = _entry(
        tmp_path,
        rel_path="toml/a.toml",
        kind=PatchKind.toml,
        content='[section]\nfoo = "first"\n',
        eid="t1",
    )
    e2 = _entry(
        tmp_path,
        rel_path="toml/b.toml",
        kind=PatchKind.toml,
        content='[section]\nbar = "second"\n',
        eid="t2",
    )
    out = read_toml_overrides([e1, e2], tmp_path)
    assert len(out) == 2
    assert out[0]["section"]["foo"] == "first"
    assert out[1]["section"]["bar"] == "second"


def test_apply_all_dispatches_by_kind(tmp_path: Path) -> None:
    env = _entry(
        tmp_path,
        rel_path="env/x.env",
        kind=PatchKind.env,
        content="FOO=bar\n",
        eid="e1",
    )
    toml_e = _entry(
        tmp_path,
        rel_path="toml/x.toml",
        kind=PatchKind.toml,
        content='[meta]\nname = "demo"\n',
        eid="t1",
    )
    result = apply_all([env, toml_e], tmp_path)
    assert isinstance(result, AppliedPatches)
    assert result.env_overrides == {"FOO": "bar"}
    assert len(result.toml_overrides) == 1
    assert result.toml_overrides[0]["meta"]["name"] == "demo"
    assert result.applied_diffs == []


def test_apply_all_patch_without_sdist_raises(tmp_path: Path) -> None:
    diff_e = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )
    with pytest.raises(PatchApplyError, match="sdist_dir"):
        apply_all([diff_e], tmp_path, sdist_dir=None)


# ---------------------------------------------------------------------------
# Coverage-completion tests for the remaining error paths.
# ---------------------------------------------------------------------------


def test_resolve_path_missing_file_raises(tmp_path: Path) -> None:
    """File referenced by the entry doesn't exist on disk → covers line 58."""
    # Build an entry whose path points at a file that we then delete.
    entry = _entry(
        tmp_path,
        rel_path="env/will-be-deleted.env",
        kind=PatchKind.env,
        content="X=1\n",
    )
    (tmp_path / "env" / "will-be-deleted.env").unlink()
    with pytest.raises(PatchApplyError, match="file missing"):
        apply_env_patches([entry], tmp_path)


def test_env_file_unreadable_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """OSError reading the env file → covers lines 69-70."""
    entry = _entry(
        tmp_path,
        rel_path="env/unread.env",
        kind=PatchKind.env,
        content="OK=1\n",
    )

    real_read_text = Path.read_text

    def raising_read_text(self: Path, *a: object, **kw: object) -> str:
        if self.name == "unread.env":
            raise OSError("permission denied")
        return real_read_text(self, *a, **kw)  # type: ignore[arg-type]

    monkeypatch.setattr(Path, "read_text", raising_read_text)
    with pytest.raises(PatchApplyError, match="cannot read env"):
        apply_env_patches([entry], tmp_path)


def test_env_empty_key_raises(tmp_path: Path) -> None:
    """``=value`` line has empty key → covers line 83."""
    entry = _entry(
        tmp_path,
        rel_path="env/empty_key.env",
        kind=PatchKind.env,
        content="=novalue\n",
    )
    with pytest.raises(PatchApplyError, match="empty key"):
        apply_env_patches([entry], tmp_path)


def test_env_strips_quoted_value(tmp_path: Path) -> None:
    """Quoted values are unquoted → covers the unquote branch (line 94)."""
    entry = _entry(
        tmp_path,
        rel_path="env/quoted.env",
        kind=PatchKind.env,
        content='SINGLE=\'hello world\'\nDOUBLE="goodbye"\nBARE=raw\n',
    )
    out = apply_env_patches([entry], tmp_path)
    assert out["SINGLE"] == "hello world"
    assert out["DOUBLE"] == "goodbye"
    assert out["BARE"] == "raw"


def test_apply_unified_diff_wrong_kind_raises(tmp_path: Path) -> None:
    """Calling apply_unified_diff on env entry → covers line 145."""
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    env_e = _entry(
        tmp_path,
        rel_path="env/x.env",
        kind=PatchKind.env,
        content="A=1\n",
    )
    with pytest.raises(PatchApplyError, match="non-patch entry"):
        apply_unified_diff(env_e, tmp_path, sdist)


def test_apply_unified_diff_missing_sdist_raises(tmp_path: Path) -> None:
    """sdist_dir doesn't exist → covers line 150."""
    entry = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )
    with pytest.raises(PatchApplyError, match="sdist dir does not exist"):
        apply_unified_diff(entry, tmp_path, tmp_path / "missing_sdist")


def test_apply_unified_diff_oserror_invoking_patch(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``subprocess.run`` raises OSError → covers lines 169-170."""
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    entry = _entry(
        tmp_path,
        rel_path="diffs/x.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
    )
    monkeypatch.setattr(patches_mod.shutil, "which", lambda name: "/usr/bin/patch")

    def raising_run(*a: object, **kw: object) -> object:
        raise OSError("exec format error")

    monkeypatch.setattr(patches_mod.subprocess, "run", raising_run)
    with pytest.raises(PatchApplyError, match="failed to invoke 'patch'"):
        apply_unified_diff(entry, tmp_path, sdist)


def test_read_toml_overrides_unreadable_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Open failure on toml file → covers lines 206-209."""
    entry = _entry(
        tmp_path,
        rel_path="toml/unread.toml",
        kind=PatchKind.toml,
        content='[m]\nname = "x"\n',
    )

    real_open = Path.open

    def raising_open(self: Path, *a: object, **kw: object) -> object:
        if self.name == "unread.toml":
            raise OSError("denied")
        return real_open(self, *a, **kw)  # type: ignore[arg-type]

    monkeypatch.setattr(Path, "open", raising_open)
    with pytest.raises(PatchApplyError, match="cannot read toml"):
        read_toml_overrides([entry], tmp_path)


def test_read_toml_overrides_malformed_raises(tmp_path: Path) -> None:
    """Malformed TOML → covers lines 210-213."""
    entry = _entry(
        tmp_path,
        rel_path="toml/bad.toml",
        kind=PatchKind.toml,
        content='[m\nname = unterminated\n',
    )
    with pytest.raises(PatchApplyError, match="malformed"):
        read_toml_overrides([entry], tmp_path)


def test_apply_all_dispatches_patch_kind_with_sdist(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """End-to-end ``apply_all`` with a patch entry → covers lines 250-251."""
    sdist = tmp_path / "sdist"
    sdist.mkdir()
    diff_e = _entry(
        tmp_path,
        rel_path="diffs/y.patch",
        kind=PatchKind.patch,
        content="--- a\n+++ b\n",
        eid="diff-1",
    )
    monkeypatch.setattr(patches_mod.shutil, "which", lambda name: "/usr/bin/patch")
    monkeypatch.setattr(
        patches_mod.subprocess,
        "run",
        lambda argv, **kw: __import__("subprocess").CompletedProcess(
            args=argv, returncode=0, stdout="", stderr=""
        ),
    )
    result = apply_all([diff_e], tmp_path, sdist_dir=sdist)
    assert result.applied_diffs == ["diff-1"]


def test_resolve_path_rejects_escape(tmp_path: Path) -> None:
    """A patch entry whose resolved path escapes the patch set root is rejected."""
    outside = tmp_path / "outside.env"
    outside.write_text("LEAK=1\n", encoding="utf-8")
    root = tmp_path / "pset"
    root.mkdir()
    entry = PatchEntry(
        id="bad/escape",
        package="demo",
        version_spec="",
        targets=[Target.linux_x86_64],
        kind=PatchKind.env,
        path="../outside.env",
        sha256=_sha256(outside),
    )
    with pytest.raises(PatchApplyError, match="escapes"):
        apply_env_patches([entry], root)

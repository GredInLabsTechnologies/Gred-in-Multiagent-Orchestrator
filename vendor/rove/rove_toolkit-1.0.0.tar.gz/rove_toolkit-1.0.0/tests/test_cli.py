"""Tests for :mod:`rove.cli`."""
from __future__ import annotations

import hashlib
import json
import os
import sys
from collections.abc import Callable
from pathlib import Path

import pytest
from typer.testing import CliRunner

from rove import cli as cli_module
from rove.builder.patches import PatchApplyError
from rove.builder.pip_runner import PipRunResult
from rove.builder.tarball import TarballBuildError, TarballBuildResult
from rove.builder.zig import ZigBuildEnv, ZigNotFoundError
from rove.cli import app
from rove.config import ConfigError
from rove.distribution.http_fetcher import FetchResult
from rove.distribution.http_server import HttpServerOptions
from rove.distribution.plugin import DistributionError
from rove.patches.loader import PatchEntry, PatchKind, PatchLoadError, PatchSet
from rove.signing import keygen
from rove.signing.ed25519 import RuntimeSignatureError, sha256_file
from rove.targets import Compression, Target


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
@pytest.fixture
def runner() -> CliRunner:
    # Default mix_stderr=True is fine for most assertions.
    return CliRunner()


def _make_project_tree(root: Path) -> None:
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "__init__.py").write_text("", encoding="utf-8")
    (src / "main.py").write_text("def go(): return 1\n", encoding="utf-8")


def _make_pyproject(
    root: Path, *, project_name: str = "myapp", version: str = "0.0.1"
) -> Path:
    pyproject = root / "pyproject.toml"
    pyproject.write_text(
        f'''
[project]
name = "{project_name}"
version = "{version}"
dependencies = ["fakepkg==1.0"]

[tool.rove]
project_name = "{project_name}"
version = "{version}"
include = ["src"]
exclude = ["tests/", "*.pyc", "__pycache__/"]
targets = ["host"]
''',
        encoding="utf-8",
    )
    return pyproject


# ---------------------------------------------------------------------------
# --version
# ---------------------------------------------------------------------------
def test_version_flag_prints_package_version(runner: CliRunner) -> None:
    """``rove --version`` prints the installed version and exits 0."""
    from rove import __version__

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.stdout


def test_no_args_invokes_help(runner: CliRunner) -> None:
    """Running ``rove`` with no args should print help, not crash.

    Covers the ``_root`` callback's default-None branch (no ``--version``
    passed) so the callback body executes with ``version=None``.
    """
    result = runner.invoke(app, [])
    # ``no_args_is_help=True`` → Typer prints help and exits with code 2
    # (conventional "usage error"). Any non-crash exit is acceptable.
    assert result.exit_code in (0, 2)
    assert "Commands" in result.stdout or "Usage" in result.stdout


# ---------------------------------------------------------------------------
# keygen
# ---------------------------------------------------------------------------
def test_keygen_writes_pair(runner: CliRunner, tmp_path: Path) -> None:
    out = tmp_path / "keys"
    result = runner.invoke(app, ["keygen", "--out", str(out)])

    assert result.exit_code == 0, result.stdout
    assert (out / "private.pem").exists()
    assert (out / "public.pem").exists()


def test_keygen_refuses_overwrite_by_default(
    runner: CliRunner, tmp_path: Path
) -> None:
    out = tmp_path / "keys"
    first = runner.invoke(app, ["keygen", "--out", str(out)])
    assert first.exit_code == 0

    private_before = (out / "private.pem").read_bytes()

    second = runner.invoke(app, ["keygen", "--out", str(out)])
    assert second.exit_code != 0
    # Private key untouched.
    assert (out / "private.pem").read_bytes() == private_before


def test_keygen_overwrite_flag_succeeds(runner: CliRunner, tmp_path: Path) -> None:
    out = tmp_path / "keys"
    runner.invoke(app, ["keygen", "--out", str(out)])
    private_before = (out / "private.pem").read_bytes()

    result = runner.invoke(app, ["keygen", "--out", str(out), "--overwrite"])
    assert result.exit_code == 0
    # New keys generated → bytes change.
    assert (out / "private.pem").read_bytes() != private_before


# ---------------------------------------------------------------------------
# sign + verify roundtrip
# ---------------------------------------------------------------------------
@pytest.fixture
def synthetic_bundle(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., object],
) -> tuple[Path, Path]:
    """Build a fake on-disk bundle (tarball + matching manifest sibling).

    The tarball is just opaque bytes; the manifest's ``tarball_sha256`` is
    set to match. Suitable for sign/verify exercise without a full build.
    """
    bundle_dir = tmp_path / "bundle"
    bundle_dir.mkdir()
    bundle_path = bundle_dir / "myapp-linux-x86_64-0.1.0.tar.xz"
    bundle_path.write_bytes(b"opaque tarball bytes\nfor signing test\n")
    actual_sha = sha256_file(bundle_path)

    manifest = synthetic_manifest_factory(
        project_name="myapp",
        runtime_version="0.1.0",
        tarball_name=bundle_path.name,
        tarball_sha256=actual_sha,
        compressed_size_bytes=bundle_path.stat().st_size,
    )

    manifest_path = bundle_path.with_name(bundle_path.name + ".manifest.json")
    manifest_path.write_text(
        json.dumps(manifest.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return bundle_path, manifest_path


def test_sign_then_verify_roundtrip(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    bundle_path, _ = synthetic_bundle
    keys_dir = tmp_path / "keys"
    priv, pub = keygen.generate_keypair(keys_dir)

    sign_result = runner.invoke(
        app,
        [
            "sign",
            "--bundle",
            str(bundle_path),
            "--key",
            str(priv),
        ],
    )
    assert sign_result.exit_code == 0, sign_result.stdout

    verify_result = runner.invoke(
        app,
        [
            "verify",
            "--bundle",
            str(bundle_path),
            "--pubkey",
            str(pub),
        ],
    )
    assert verify_result.exit_code == 0, verify_result.stdout
    assert "signature ok" in verify_result.stdout


def test_verify_with_wrong_pubkey_fails(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    bundle_path, _ = synthetic_bundle
    keys_dir_a = tmp_path / "keys_a"
    keys_dir_b = tmp_path / "keys_b"
    priv_a, _ = keygen.generate_keypair(keys_dir_a)
    _, pub_b = keygen.generate_keypair(keys_dir_b)

    sign_result = runner.invoke(
        app, ["sign", "--bundle", str(bundle_path), "--key", str(priv_a)]
    )
    assert sign_result.exit_code == 0

    verify_result = runner.invoke(
        app,
        [
            "verify",
            "--bundle",
            str(bundle_path),
            "--pubkey",
            str(pub_b),
        ],
    )
    assert verify_result.exit_code != 0


def test_verify_tampered_bundle_fails(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    bundle_path, _ = synthetic_bundle
    keys_dir = tmp_path / "keys"
    priv, pub = keygen.generate_keypair(keys_dir)

    sign_result = runner.invoke(
        app, ["sign", "--bundle", str(bundle_path), "--key", str(priv)]
    )
    assert sign_result.exit_code == 0

    # Tamper with the bundle bytes after signing.
    bundle_path.write_bytes(b"tampered!" * 10)

    verify_result = runner.invoke(
        app,
        ["verify", "--bundle", str(bundle_path), "--pubkey", str(pub)],
    )
    # Non-zero exit is the contract; the human-readable error goes to
    # ``err_console`` (stderr) which CliRunner does not split out by default.
    assert verify_result.exit_code != 0


def test_sign_refuses_when_manifest_sha_mismatches_bundle(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    bundle_path, _ = synthetic_bundle
    keys_dir = tmp_path / "keys"
    priv, _ = keygen.generate_keypair(keys_dir)

    # Mutate bundle so the on-disk sha != manifest sha.
    bundle_path.write_bytes(b"different bytes")

    result = runner.invoke(
        app, ["sign", "--bundle", str(bundle_path), "--key", str(priv)]
    )
    assert result.exit_code != 0


def test_sign_missing_manifest_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    bundle = tmp_path / "lonely.tar.xz"
    bundle.write_bytes(b"contents")
    keys = tmp_path / "keys"
    priv, _ = keygen.generate_keypair(keys)

    result = runner.invoke(
        app, ["sign", "--bundle", str(bundle), "--key", str(priv)]
    )
    assert result.exit_code == 2


def test_verify_missing_manifest_errors(runner: CliRunner, tmp_path: Path) -> None:
    bundle = tmp_path / "lonely.tar.xz"
    bundle.write_bytes(b"contents")
    keys = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys)

    result = runner.invoke(
        app, ["verify", "--bundle", str(bundle), "--pubkey", str(pub)]
    )
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# build (with mocked sub-fetchers)
# ---------------------------------------------------------------------------
def _patch_pip_runner(
    monkeypatch: pytest.MonkeyPatch,
    *,
    fail: bool = False,
) -> None:
    """Replace ``cli.run_pip_download`` so no real pip subprocess runs."""

    from rove.builder.pip_runner import PipError, PipRunResult

    def _fake_run(opts: object) -> PipRunResult:
        # opts.output_dir is the wheels temp dir created by the CLI.
        out_dir: Path = opts.output_dir  # type: ignore[attr-defined]
        out_dir.mkdir(parents=True, exist_ok=True)
        wheel = out_dir / "fakepkg-1.0-py3-none-any.whl"
        wheel.write_bytes(b"fake wheel")
        if fail:
            raise PipError("simulated pip failure")
        return PipRunResult(
            returncode=0,
            stdout="",
            stderr="",
            wheels_collected=[wheel],
        )

    monkeypatch.setattr(cli_module, "run_pip_download", _fake_run)


def _patch_standalone_python_ok(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> Path:
    """Replace ``cli.fetch_standalone_python`` with a no-network stub."""
    py_root = tmp_path / "fake_pyroot"
    bin_dir = py_root / "bin"
    bin_dir.mkdir(parents=True)
    (bin_dir / "python3").write_bytes(b"#!/bin/sh\nexit 0\n")
    if os.name == "posix":
        (bin_dir / "python3").chmod(0o755)

    def _fake_fetch(target, *, python_version: str = "3.13") -> Path:
        return py_root

    monkeypatch.setattr(cli_module, "fetch_standalone_python", _fake_fetch)
    return py_root


def _patch_standalone_python_android(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise_android(target, *, python_version: str = "3.13") -> Path:
        raise NotImplementedError(
            "Android targets must be built inside Termux (no python-build-standalone asset)"
        )

    monkeypatch.setattr(cli_module, "fetch_standalone_python", _raise_android)


def test_build_no_python_smoke(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_pip_runner(monkeypatch)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
        ],
    )
    assert result.exit_code == 0, result.stdout

    bundles = list(out.glob("myapp-linux-x86_64-0.0.1.tar"))
    assert len(bundles) == 1
    manifests = list(out.glob("myapp-linux-x86_64-0.0.1.tar.manifest.json"))
    assert len(manifests) == 1


def test_build_with_python_smoke(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_standalone_python_ok(monkeypatch, tmp_path)
    _patch_pip_runner(monkeypatch)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--compression",
            "xz",
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert (out / "myapp-linux-x86_64-0.0.1.tar.xz").exists()


def test_build_android_without_no_python_errors(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_standalone_python_android(monkeypatch)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "android-arm64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
        ],
    )
    assert result.exit_code == 2, result.stdout
    # The error message hints the user toward the Termux/--no-python path.
    combined = (result.stdout or "") + (result.stderr or "")
    assert "Termux" in combined or "--no-python" in combined


def test_build_invalid_target_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "plan9-x64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
        ],
    )
    assert result.exit_code != 0


def test_build_invalid_compression_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
            "--compression",
            "bzip77",
        ],
    )
    assert result.exit_code != 0


def test_build_missing_requirements_errors(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    # pyproject WITHOUT dependencies and without [tool.rove].requirements.
    pyproject = project / "pyproject.toml"
    pyproject.write_text(
        '''
[project]
name = "needy"
version = "0.0.1"

[tool.rove]
project_name = "needy"
version = "0.0.1"
include = ["src"]
targets = ["host"]
''',
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
        ],
    )
    assert result.exit_code == 2
    combined = (result.stdout or "") + (result.stderr or "")
    assert "requirements" in combined.lower()


def test_build_missing_config_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    bogus = tmp_path / "no_such.toml"
    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(bogus),
            "--no-python",
        ],
    )
    assert result.exit_code == 2


def test_build_pip_failure_propagates(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_pip_runner(monkeypatch, fail=True)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
        ],
    )
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# serve (mock http_serve)
# ---------------------------------------------------------------------------
def test_serve_invokes_http_serve(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    bundles = tmp_path / "bundles"
    bundles.mkdir()

    captured: dict[str, HttpServerOptions] = {}

    def _fake_serve(opts: HttpServerOptions) -> None:
        captured["opts"] = opts

    monkeypatch.setattr(cli_module, "http_serve", _fake_serve)

    result = runner.invoke(
        app,
        [
            "serve",
            "--bundle-dir",
            str(bundles),
            "--port",
            "12345",
            "--host",
            "127.0.0.1",
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert "opts" in captured
    opts = captured["opts"]
    assert isinstance(opts, HttpServerOptions)
    assert opts.bundle_dir == bundles.resolve()
    assert opts.host == "127.0.0.1"
    assert opts.port == 12345


def test_serve_propagates_distribution_error(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    bundles = tmp_path / "bundles"
    bundles.mkdir()

    def _fake_serve(opts: HttpServerOptions) -> None:
        raise DistributionError("server failed to bind")

    monkeypatch.setattr(cli_module, "http_serve", _fake_serve)

    result = runner.invoke(
        app, ["serve", "--bundle-dir", str(bundles)]
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "server failed to bind" in combined


def test_serve_clean_keyboard_interrupt(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    bundles = tmp_path / "bundles"
    bundles.mkdir()

    def _fake_serve(opts: HttpServerOptions) -> None:
        raise KeyboardInterrupt

    monkeypatch.setattr(cli_module, "http_serve", _fake_serve)

    result = runner.invoke(app, ["serve", "--bundle-dir", str(bundles)])
    assert result.exit_code == 0


# ---------------------------------------------------------------------------
# fetch (mock fetch_bundle)
# ---------------------------------------------------------------------------
def test_fetch_downloads_and_verifies(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    synthetic_manifest_factory: Callable[..., object],
    clean_trusted_env: Path,
) -> None:
    """CLI delegates to ``fetch_bundle`` and reports success on the FetchResult."""
    bundle_name = "myapp-linux-x86_64-0.0.1.tar.xz"
    out = tmp_path / "dl"

    keys_dir = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys_dir)

    fake_payload = b"server bundle bytes for fetch test"
    manifest = synthetic_manifest_factory(
        project_name="myapp",
        runtime_version="0.0.1",
        tarball_name=bundle_name,
        tarball_sha256=sha256_file(_write_throwaway(tmp_path, fake_payload)),
        compressed_size_bytes=len(fake_payload),
    )

    captured: dict[str, object] = {}

    def _fake_fetch(opts):  # type: ignore[no-untyped-def]
        captured["opts"] = opts
        # CLI expects a real bundle path it can reference in the success message.
        bundle_path = opts.output_dir / opts.bundle_name
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        bundle_path.write_bytes(fake_payload)
        return FetchResult(
            bundle_path=bundle_path,
            manifest=manifest,
            bytes_downloaded=len(fake_payload),
            from_cache=False,
        )

    monkeypatch.setattr(cli_module, "fetch_bundle", _fake_fetch)

    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(out),
            "--pubkey",
            str(pub),
            "--project-name",
            "myapp",
            "--runtime-version",
            "0.0.1",
            "--compression",
            "xz",
        ],
    )
    assert result.exit_code == 0, result.stdout
    # Confirm the CLI built the canonical bundle name + forwarded the pubkey.
    opts = captured["opts"]
    assert opts.bundle_name == bundle_name  # type: ignore[attr-defined]
    assert opts.source == "https://example.com/bundles"  # type: ignore[attr-defined]
    assert pub in opts.additional_pubkeys  # type: ignore[attr-defined]


def test_fetch_requires_project_name_and_version(
    runner: CliRunner, tmp_path: Path
) -> None:
    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(tmp_path / "dl"),
        ],
    )
    assert result.exit_code != 0


def test_fetch_download_failure_errors(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _fake_fetch(opts):  # type: ignore[no-untyped-def]
        raise DistributionError("connection refused")

    monkeypatch.setattr(cli_module, "fetch_bundle", _fake_fetch)

    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(tmp_path / "dl"),
            "--project-name",
            "myapp",
            "--runtime-version",
            "0.0.1",
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "connection refused" in combined


def test_fetch_sha_mismatch_after_download(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    clean_trusted_env: Path,
) -> None:
    """Fetcher reports SHA-256 mismatch → CLI exits 1 with the error surfaced."""

    def _fake_fetch(opts):  # type: ignore[no-untyped-def]
        raise DistributionError(
            "bundle SHA-256 mismatch after download: have=deadbeef want=cafebabe"
        )

    monkeypatch.setattr(cli_module, "fetch_bundle", _fake_fetch)

    keys_dir = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys_dir)

    out = tmp_path / "dl"
    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(out),
            "--pubkey",
            str(pub),
            "--project-name",
            "myapp",
            "--runtime-version",
            "0.0.1",
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "SHA-256 mismatch" in combined


def _write_throwaway(tmp_path: Path, payload: bytes) -> Path:
    """Helper: write ``payload`` to a temp file and return its path (for sha256_file)."""
    p = tmp_path / "_sha_input"
    p.write_bytes(payload)
    return p


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def test_app_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    for sub in ("keygen", "build", "sign", "verify", "serve", "fetch"):
        assert sub in result.stdout


# ---------------------------------------------------------------------------
# Internal helper coverage
# ---------------------------------------------------------------------------
def test_internal_helpers_info_and_warn(capsys: pytest.CaptureFixture[str]) -> None:
    """Direct call to ``_info`` / ``_warn`` so the styling lines execute."""
    cli_module._info("hello info")
    cli_module._warn("hello warn")
    captured = capsys.readouterr()
    assert "hello info" in captured.out
    assert "hello warn" in captured.err


def test_parse_compression_zstd_alias() -> None:
    """``zst`` is accepted as an alias for ``zstd`` (covers line 120)."""
    assert cli_module._parse_compression("zst") is Compression.zstd
    assert cli_module._parse_compression("zstd") is Compression.zstd


def test_requirement_package_strips_version() -> None:
    """A version-pinned requirement returns its lowercased package name."""
    assert cli_module._requirement_package("FakePkg==1.0") == "fakepkg"


def test_requirement_package_unparseable_returns_input() -> None:
    """A spec that does not start with a name char returns the stripped input."""
    # Leading '@' does not match _REQ_NAME_RE so the no-match branch is hit.
    assert cli_module._requirement_package("  @weird  ") == "@weird"


def test_python_executable_for_none_returns_sys_executable() -> None:
    """When no python_root is supplied the running interpreter is returned."""
    assert cli_module._python_executable_for(None) == Path(sys.executable)


def test_python_executable_for_no_candidate_falls_back(tmp_path: Path) -> None:
    """An empty python_root falls through to ``sys.executable``."""
    empty_root = tmp_path / "empty_pyroot"
    empty_root.mkdir()
    # No bin/python3 / python.exe etc → loop exhausts → fall back.
    assert cli_module._python_executable_for(empty_root) == Path(sys.executable)


def test_python_executable_for_finds_candidate(tmp_path: Path) -> None:
    """A python_root containing a candidate returns that candidate path."""
    root = tmp_path / "pyroot"
    bin_dir = root / "bin"
    bin_dir.mkdir(parents=True)
    candidate = bin_dir / "python3"
    candidate.write_bytes(b"#!/bin/sh\n")
    assert cli_module._python_executable_for(root) == candidate


# ---------------------------------------------------------------------------
# Manifest-loading error paths (exercised via sign/verify)
# ---------------------------------------------------------------------------
def test_load_manifest_missing_file_raises(tmp_path: Path) -> None:
    """Direct call: ``_load_manifest`` on a missing file raises ``typer.Exit``.

    Subcommands pre-check existence, but ``_load_manifest`` is a defensive
    helper and must surface a typed ``Exit`` when called with a path that
    does not exist on disk.
    """
    import typer as _typer

    missing = tmp_path / "no_such.manifest.json"
    with pytest.raises(_typer.Exit) as excinfo:
        cli_module._load_manifest(missing)
    assert excinfo.value.exit_code == 2


def test_load_manifest_unparseable_json_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    """``_load_manifest`` surfaces malformed JSON via a non-zero exit."""
    bundle = tmp_path / "bundle.tar.xz"
    bundle.write_bytes(b"opaque")
    manifest_path = bundle.with_name(bundle.name + ".manifest.json")
    manifest_path.write_text("{not valid json", encoding="utf-8")

    keys = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys)

    result = runner.invoke(
        app, ["verify", "--bundle", str(bundle), "--pubkey", str(pub)]
    )
    assert result.exit_code == 2


def test_load_manifest_schema_violation_errors(
    runner: CliRunner, tmp_path: Path
) -> None:
    """A JSON file that does not match the schema fails validation."""
    bundle = tmp_path / "bundle.tar.xz"
    bundle.write_bytes(b"opaque")
    manifest_path = bundle.with_name(bundle.name + ".manifest.json")
    # Valid JSON, missing required fields.
    manifest_path.write_text(json.dumps({"unrelated": "payload"}), encoding="utf-8")

    keys = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys)

    result = runner.invoke(
        app, ["verify", "--bundle", str(bundle), "--pubkey", str(pub)]
    )
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# keygen OSError surface
# ---------------------------------------------------------------------------
def test_keygen_oserror_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """An OSError while writing the keypair surfaces as exit-code 1."""

    def _boom(out_dir: Path, *, overwrite: bool = False) -> tuple[Path, Path]:
        raise OSError("disk full")

    monkeypatch.setattr(cli_module, "generate_keypair", _boom)
    result = runner.invoke(app, ["keygen", "--out", str(tmp_path / "k")])
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "disk full" in combined


# ---------------------------------------------------------------------------
# build error / branch coverage
# ---------------------------------------------------------------------------
def test_build_config_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``ConfigError`` from ``load`` is surfaced with exit-code 2."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)

    def _bad_load(path: Path | None) -> object:
        raise ConfigError("malformed pyproject")

    monkeypatch.setattr(cli_module, "load", _bad_load)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
        ],
    )
    assert result.exit_code == 2
    combined = (result.stdout or "") + (result.stderr or "")
    assert "malformed pyproject" in combined


def test_build_standalone_fetch_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A non-Android ``StandaloneFetchError`` surfaces with exit-code 1."""
    from rove.builder.python_standalone import StandaloneFetchError

    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)

    def _boom(target: Target, *, python_version: str = "3.13") -> Path:
        raise StandaloneFetchError("network down")

    monkeypatch.setattr(cli_module, "fetch_standalone_python", _boom)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "network down" in combined


def test_build_tarball_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``TarballBuildError`` from ``build_tarball`` surfaces with exit-code 1."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)

    _patch_pip_runner(monkeypatch)

    def _boom(opts: object) -> TarballBuildResult:
        raise TarballBuildError("could not write archive")

    monkeypatch.setattr(cli_module, "build_tarball", _boom)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "could not write archive" in combined


def test_build_host_target_skips_zig(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``resolved`` matches the detected host, the zig branch is skipped."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_pip_runner(monkeypatch)

    # Force detect_host (looked up via the builder's own import path) to
    # return the same target the CLI is going to resolve. The CLI imports
    # detect_host *inside* the function via ``from rove.targets import
    # detect_host as _detect_host``, so we patch the source module.
    import rove.targets as targets_module

    monkeypatch.setattr(targets_module, "detect_host", lambda: Target.linux_x86_64)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
        ],
    )
    assert result.exit_code == 0, result.stdout
    # When the zig branch is skipped, the warn / ok lines about the cross
    # env do not appear.
    assert "zig cross env" not in result.stdout


def test_build_detect_host_runtime_error_branch(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``detect_host`` raising ``RuntimeError`` is caught and host_target=None."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_pip_runner(monkeypatch)

    import rove.targets as targets_module

    def _no_host() -> Target:
        raise RuntimeError("unsupported test platform")

    monkeypatch.setattr(targets_module, "detect_host", _no_host)
    # Make build_env_for raise a ZigNotFoundError so we cleanly exercise
    # the warn-but-continue path without depending on a real zig install.
    monkeypatch.setattr(
        cli_module,
        "build_env_for",
        lambda target: (_ for _ in ()).throw(ZigNotFoundError("no zig")),
    )

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
        ],
    )
    assert result.exit_code == 0, result.stdout


def test_build_zig_env_success_path(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A successful ``build_env_for`` call reports the cargo build target."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_pip_runner(monkeypatch)

    fake_env = ZigBuildEnv(
        target=Target.linux_arm64,
        cc="zig cc -target aarch64-linux-gnu",
        cxx="zig c++ -target aarch64-linux-gnu",
        ar="zig ar",
        cargo_build_target="aarch64-unknown-linux-gnu",
        extra_env={"PIP_NO_DEPS": "0"},
    )
    monkeypatch.setattr(cli_module, "build_env_for", lambda target: fake_env)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-arm64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert "zig cross env ready" in result.stdout
    assert "aarch64-unknown-linux-gnu" in result.stdout


# ---------------------------------------------------------------------------
# build patch-set processing (lines 318-351)
# ---------------------------------------------------------------------------
def _make_env_patch_entry(env_file: Path, package: str = "fakepkg") -> PatchEntry:
    sha = hashlib.sha256(env_file.read_bytes()).hexdigest()
    return PatchEntry(
        id=f"env-{package}",
        package=package,
        version_spec="",
        targets=[Target.linux_x86_64, Target.linux_arm64],
        kind=PatchKind.env,
        path=env_file.name,
        sha256=sha,
        description="env override for test",
    )


def test_build_patch_set_missing_path_errors(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``--patch-set`` pointing at a nonexistent path errors out."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    missing = tmp_path / "no_such_patches"

    _patch_pip_runner(monkeypatch)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
            "--patch-set",
            str(missing),
        ],
    )
    assert result.exit_code == 2
    combined = (result.stdout or "") + (result.stderr or "")
    assert "patch set does not exist" in combined


def test_build_patch_set_load_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``PatchLoadError`` from ``load_patch_set`` surfaces as exit-code 1."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    patches_dir = tmp_path / "patches"
    patches_dir.mkdir()

    _patch_pip_runner(monkeypatch)

    def _bad_load(source: Path) -> PatchSet:
        raise PatchLoadError("malformed index")

    monkeypatch.setattr(cli_module, "load_patch_set", _bad_load)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
            "--patch-set",
            str(patches_dir),
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "malformed index" in combined


def test_build_patch_apply_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``PatchApplyError`` from ``apply_env_patches`` surfaces as exit 1."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    patches_dir = tmp_path / "patches"
    patches_dir.mkdir()
    env_file = patches_dir / "fakepkg.env"
    env_file.write_text("FOO=bar\n", encoding="utf-8")

    _patch_pip_runner(monkeypatch)

    entry = _make_env_patch_entry(env_file)
    fake_set = PatchSet(version=1, patches=[entry])

    monkeypatch.setattr(cli_module, "load_patch_set", lambda source: fake_set)
    monkeypatch.setattr(
        cli_module,
        "resolve_patches",
        lambda ps, *, packages, target: list(ps.patches),
    )

    def _boom(entries: list[PatchEntry], root: Path) -> dict[str, str]:
        raise PatchApplyError("env file unreadable")

    monkeypatch.setattr(cli_module, "apply_env_patches", _boom)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--no-python",
            "--patch-set",
            str(patches_dir),
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "patch application failed" in combined


def test_build_full_patch_pipeline(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Full happy-path through the patch-set processing branch.

    Exercises: env patch parsing, toml override pickup, diff-deferral
    warning, ``patches_applied`` accumulation, and the success-summary
    ``_ok`` line for resolved patches.
    """
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    patches_dir = tmp_path / "patches"
    patches_dir.mkdir()
    env_file = patches_dir / "fakepkg.env"
    env_file.write_text("CFLAGS=-O2\n", encoding="utf-8")
    toml_file = patches_dir / "fakepkg.toml"
    toml_file.write_text("[fakepkg]\nopt = true\n", encoding="utf-8")
    diff_file = patches_dir / "fakepkg.patch"
    diff_file.write_bytes(b"--- a\n+++ b\n@@ -0 +0 @@\n")

    env_entry = _make_env_patch_entry(env_file)
    toml_entry = PatchEntry(
        id="toml-fakepkg",
        package="fakepkg",
        version_spec="",
        targets=[Target.linux_x86_64],
        kind=PatchKind.toml,
        path=toml_file.name,
        sha256=hashlib.sha256(toml_file.read_bytes()).hexdigest(),
    )
    diff_entry = PatchEntry(
        id="diff-fakepkg",
        package="fakepkg",
        version_spec="",
        targets=[Target.linux_x86_64],
        kind=PatchKind.patch,
        path=diff_file.name,
        sha256=hashlib.sha256(diff_file.read_bytes()).hexdigest(),
    )
    fake_set = PatchSet(version=1, patches=[env_entry, toml_entry, diff_entry])

    _patch_pip_runner(monkeypatch)
    monkeypatch.setattr(cli_module, "load_patch_set", lambda source: fake_set)
    monkeypatch.setattr(
        cli_module,
        "resolve_patches",
        lambda ps, *, packages, target: list(ps.patches),
    )

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
            "--patch-set",
            str(patches_dir),
        ],
    )
    assert result.exit_code == 0, result.stdout
    combined = (result.stdout or "") + (result.stderr or "")
    assert "patches resolved" in combined
    assert "deferred" in combined
    assert "toml overrides parsed" in combined


def test_build_patch_set_resolves_empty(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A patch set whose ``resolve_patches`` yields nothing skips the ok line.

    Exercises the false branches of ``if env_overrides`` and
    ``if patches_applied`` (lines 345 and 350).
    """
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    patches_dir = tmp_path / "patches"
    patches_dir.mkdir()

    _patch_pip_runner(monkeypatch)
    monkeypatch.setattr(
        cli_module,
        "load_patch_set",
        lambda source: PatchSet(version=1, patches=[]),
    )
    monkeypatch.setattr(
        cli_module,
        "resolve_patches",
        lambda ps, *, packages, target: [],
    )

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
            "--patch-set",
            str(patches_dir),
        ],
    )
    assert result.exit_code == 0, result.stdout
    # Neither summary line fires on an empty resolution.
    assert "patches resolved" not in result.stdout
    assert "toml overrides parsed" not in result.stdout


def test_build_patch_set_as_file_pointer(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``--patch-set`` is a JSON file, the parent dir is used as root."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    patches_dir = tmp_path / "patches"
    patches_dir.mkdir()
    env_file = patches_dir / "fakepkg.env"
    env_file.write_text("FOO=1\n", encoding="utf-8")
    manifest_json = patches_dir / "manifest.json"
    manifest_json.write_text("{}", encoding="utf-8")  # contents irrelevant — load is mocked

    entry = _make_env_patch_entry(env_file)
    fake_set = PatchSet(version=1, patches=[entry])

    _patch_pip_runner(monkeypatch)
    monkeypatch.setattr(cli_module, "load_patch_set", lambda source: fake_set)
    monkeypatch.setattr(
        cli_module,
        "resolve_patches",
        lambda ps, *, packages, target: list(ps.patches),
    )

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-x86_64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--no-python",
            "--compression",
            "none",
            "--patch-set",
            str(manifest_json),
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert "patches resolved" in result.stdout


# ---------------------------------------------------------------------------
# Cross-target full pipeline (with python-build-standalone mock + zig env)
# ---------------------------------------------------------------------------
def test_build_cross_target_full_pipeline(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """End-to-end build with mocked stdpy fetch, zig env, pip, and tarball."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    pyproject = _make_pyproject(project)
    out = tmp_path / "dist"

    _patch_standalone_python_ok(monkeypatch, tmp_path)
    _patch_pip_runner(monkeypatch)

    fake_env = ZigBuildEnv(
        target=Target.linux_arm64,
        cc="zig cc",
        cxx="zig c++",
        ar="zig ar",
        cargo_build_target="aarch64-unknown-linux-gnu",
        extra_env={},
    )
    monkeypatch.setattr(cli_module, "build_env_for", lambda target: fake_env)

    result = runner.invoke(
        app,
        [
            "build",
            "--target",
            "linux-arm64",
            "--config",
            str(pyproject),
            "--output",
            str(out),
            "--compression",
            "xz",
        ],
    )
    assert result.exit_code == 0, result.stdout
    bundles = list(out.glob("myapp-linux-arm64-0.0.1.tar.xz"))
    assert len(bundles) == 1
    manifests = list(out.glob("myapp-linux-arm64-0.0.1.tar.xz.manifest.json"))
    assert len(manifests) == 1


# ---------------------------------------------------------------------------
# sign / verify error coverage (lines 487-488, 545-546)
# ---------------------------------------------------------------------------
def test_sign_runtime_signature_error_surface(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A ``RuntimeSignatureError`` from ``sign_manifest`` exits 1."""
    bundle_path, _ = synthetic_bundle
    keys_dir = tmp_path / "keys"
    priv, _ = keygen.generate_keypair(keys_dir)

    def _boom(manifest: object, key: Path) -> object:
        raise RuntimeSignatureError("private key invalid")

    monkeypatch.setattr(cli_module, "sign_manifest", _boom)

    result = runner.invoke(
        app, ["sign", "--bundle", str(bundle_path), "--key", str(priv)]
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "private key invalid" in combined


def test_verify_runtime_signature_error_surface(
    runner: CliRunner,
    tmp_path: Path,
    synthetic_bundle: tuple[Path, Path],
    monkeypatch: pytest.MonkeyPatch,
    clean_trusted_env: Path,
) -> None:
    """A ``RuntimeSignatureError`` from ``verify_manifest`` exits 1."""
    bundle_path, _ = synthetic_bundle
    keys_dir = tmp_path / "keys"
    _, pub = keygen.generate_keypair(keys_dir)

    def _boom(manifest: object, *, additional_keys: list[Path]) -> bool:
        raise RuntimeSignatureError("trust store unreadable")

    monkeypatch.setattr(cli_module, "verify_manifest", _boom)

    result = runner.invoke(
        app,
        ["verify", "--bundle", str(bundle_path), "--pubkey", str(pub)],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "trust store unreadable" in combined


# ---------------------------------------------------------------------------
# fetch error / cache coverage (lines 665-666, 669)
# ---------------------------------------------------------------------------
def test_fetch_runtime_signature_error_surface(
    runner: CliRunner, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A ``RuntimeSignatureError`` from ``fetch_bundle`` exits 1."""

    def _boom(opts: object) -> FetchResult:
        raise RuntimeSignatureError("bad signature on remote manifest")

    monkeypatch.setattr(cli_module, "fetch_bundle", _boom)

    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(tmp_path / "dl"),
            "--project-name",
            "myapp",
            "--runtime-version",
            "0.0.1",
        ],
    )
    assert result.exit_code == 1
    combined = (result.stdout or "") + (result.stderr or "")
    assert "bad signature" in combined


def test_fetch_from_cache_path(
    runner: CliRunner,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    synthetic_manifest_factory: Callable[..., object],
    clean_trusted_env: Path,
) -> None:
    """``from_cache=True`` triggers the ``already on disk`` success line."""
    bundle_name = "myapp-linux-x86_64-0.0.1.tar.xz"
    out = tmp_path / "dl"

    payload = b"cached bundle bytes"
    sha_input = tmp_path / "_sha"
    sha_input.write_bytes(payload)

    manifest = synthetic_manifest_factory(
        project_name="myapp",
        runtime_version="0.0.1",
        tarball_name=bundle_name,
        tarball_sha256=sha256_file(sha_input),
        compressed_size_bytes=len(payload),
    )

    def _fake_fetch(opts):  # type: ignore[no-untyped-def]
        bundle_path = opts.output_dir / opts.bundle_name
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        bundle_path.write_bytes(payload)
        return FetchResult(
            bundle_path=bundle_path,
            manifest=manifest,
            bytes_downloaded=0,
            from_cache=True,
        )

    monkeypatch.setattr(cli_module, "fetch_bundle", _fake_fetch)

    result = runner.invoke(
        app,
        [
            "fetch",
            "--from",
            "https://example.com/bundles",
            "--target",
            "linux-x86_64",
            "--out",
            str(out),
            "--project-name",
            "myapp",
            "--runtime-version",
            "0.0.1",
        ],
    )
    assert result.exit_code == 0, result.stdout
    assert "already on disk" in result.stdout


# ---------------------------------------------------------------------------
# main() entry-point coverage (line 681)
# ---------------------------------------------------------------------------
def test_main_invokes_app(monkeypatch: pytest.MonkeyPatch) -> None:
    """``main()`` simply calls the typer ``app``."""
    called: dict[str, bool] = {}

    def _fake_app() -> None:
        called["yes"] = True

    monkeypatch.setattr(cli_module, "app", _fake_app)
    cli_module.main()
    assert called == {"yes": True}


# Suppress unused-import warnings for symbols only referenced via monkeypatch.
_ = (sys, PipRunResult)

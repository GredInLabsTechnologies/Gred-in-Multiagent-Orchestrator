"""Tests for :mod:`rove.manifest`."""
from __future__ import annotations

from collections.abc import Callable

import pytest
from pydantic import ValidationError

from rove.manifest import WheelhouseManifest
from rove.targets import Compression, Target

_VALID_SHA = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
_VALID_SIG = "00" * 64


class TestRoundTrip:
    def test_json_roundtrip(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        original = synthetic_manifest_factory()
        round_tripped = WheelhouseManifest.model_validate_json(
            original.model_dump_json()
        )
        assert round_tripped == original

    def test_uppercase_hex_normalized(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        # "AB" * 32 lowercases to a valid 64-hex SHA-256.
        m = synthetic_manifest_factory(
            tarball_sha256="AB" * 32, signature="CD" * 64
        )
        assert m.tarball_sha256 == "ab" * 32
        assert m.signature == "cd" * 64


class TestSigningPayload:
    def test_exact_byte_format(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        m = synthetic_manifest_factory(
            project_name="rove-test",
            tarball_sha256=_VALID_SHA,
            target=Target.android_arm64,
            runtime_version="1.2.3",
        )
        expected = f"{_VALID_SHA}|android-arm64|1.2.3|rove-test".encode()
        assert m.signing_payload() == expected

    @pytest.mark.parametrize(
        "target,version",
        [
            (Target.linux_x86_64, "0.0.1"),
            (Target.windows_x86_64, "9.9.9-rc1"),
            (Target.darwin_arm64, "2.0.0+build.5"),
        ],
    )
    def test_payload_uses_target_value_string(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        target: Target,
        version: str,
    ) -> None:
        m = synthetic_manifest_factory(target=target, runtime_version=version)
        payload = m.signing_payload()
        assert payload.endswith(m.project_name.encode("utf-8"))
        assert version.encode("utf-8") in payload
        assert target.value.encode("utf-8") in payload

    def test_payload_binds_project_name(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        """Two manifests identical except for project_name must differ.

        Guards against cross-project signature reuse: a signer that
        produces bundles for several projects should not be able to
        have one bundle accepted in place of another purely because
        sha/target/version coincide.
        """
        a = synthetic_manifest_factory(project_name="alpha")
        b = synthetic_manifest_factory(project_name="beta")
        assert a.signing_payload() != b.signing_payload()


class TestProjectNameValidation:
    @pytest.mark.parametrize(
        "bad",
        ["MyApp", "-leading-hyphen", ".leading-dot", "with space", "UPPER", ""],
    )
    def test_rejects_bad_project_names(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        bad: str,
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(project_name=bad)

    @pytest.mark.parametrize(
        "good",
        ["a", "my-app", "my_app", "my.app", "app1", "0name", "snake_case_42"],
    )
    def test_accepts_good_project_names(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        good: str,
    ) -> None:
        m = synthetic_manifest_factory(project_name=good)
        assert m.project_name == good


class TestHexFieldValidation:
    @pytest.mark.parametrize(
        "bad",
        [
            "abc",  # too short
            "z" * 64,  # not hex
            "a" * 63,  # off by one
            "a" * 65,  # off by one
            "",
        ],
    )
    def test_rejects_bad_sha256(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        bad: str,
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(tarball_sha256=bad)

    @pytest.mark.parametrize(
        "bad",
        ["00" * 63, "00" * 65, "z" * 128, "abc", ""],
    )
    def test_rejects_bad_signature(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        bad: str,
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(signature=bad)

    def test_uppercase_sha_accepted(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        # Per the lowercase normalizer, "AB" * 32 should pass.
        m = synthetic_manifest_factory(tarball_sha256="AB" * 32)
        assert m.tarball_sha256 == "ab" * 32

    def test_non_string_sha_passes_through_normalizer(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        """Non-string input bypasses .lower() — covers the else-branch return."""
        # Passing an int means the normalizer returns it as-is; the pattern
        # validator then rejects it. Confirms the else-branch (line 168)
        # is reached before the pattern check.
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(tarball_sha256=12345)


class TestPathValidation:
    @pytest.mark.parametrize(
        "field",
        ["python_rel_path", "project_root_rel_path", "wheels_rel_path", "tarball_name"],
    )
    @pytest.mark.parametrize("bad", ["C:/abs", "D:/foo/bar"])
    def test_rejects_windows_absolute(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        field: str,
        bad: str,
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(**{field: bad})

    @pytest.mark.parametrize(
        "field",
        ["python_rel_path", "project_root_rel_path", "wheels_rel_path", "tarball_name"],
    )
    def test_strips_leading_slash(
        self,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
        field: str,
    ) -> None:
        # The validator lstrips leading "/" — POSIX absolute becomes
        # relative rather than raising.
        m = synthetic_manifest_factory(**{field: "/abs/path"})
        assert getattr(m, field) == "abs/path"


class TestNumericValidation:
    def test_rejects_negative_compressed_size(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(compressed_size_bytes=-1)

    def test_rejects_negative_uncompressed_size(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        with pytest.raises(ValidationError):
            synthetic_manifest_factory(uncompressed_size_bytes=-1)


class TestDefaults:
    def test_wheels_rel_path_default(self) -> None:
        m = WheelhouseManifest(
            project_name="test",
            runtime_version="0.1.0",
            target=Target.linux_x86_64,
            compression=Compression.zstd,
            tarball_name="test.tar.zst",
            tarball_sha256=_VALID_SHA,
            compressed_size_bytes=10,
            uncompressed_size_bytes=20,
            python_rel_path="python/bin/python",
            project_root_rel_path="project",
            signature=_VALID_SIG,
        )
        assert m.wheels_rel_path == "wheelhouse"

    def test_patches_applied_default_empty(
        self, synthetic_manifest_factory: Callable[..., WheelhouseManifest]
    ) -> None:
        m = synthetic_manifest_factory()
        assert m.patches_applied == []

    def test_compression_default_xz(self) -> None:
        m = WheelhouseManifest(
            project_name="test",
            runtime_version="0.1.0",
            target=Target.linux_x86_64,
            tarball_name="test.tar.xz",
            tarball_sha256=_VALID_SHA,
            compressed_size_bytes=10,
            uncompressed_size_bytes=20,
            python_rel_path="python/bin/python",
            project_root_rel_path="project",
            signature=_VALID_SIG,
        )
        assert m.compression is Compression.xz


class TestMissingFields:
    @pytest.mark.parametrize(
        "missing",
        [
            "project_name",
            "runtime_version",
            "target",
            "tarball_name",
            "tarball_sha256",
            "compressed_size_bytes",
            "uncompressed_size_bytes",
            "python_rel_path",
            "project_root_rel_path",
            "signature",
        ],
    )
    def test_required_field_missing(self, missing: str) -> None:
        kwargs: dict[str, object] = {
            "project_name": "test",
            "runtime_version": "0.1.0",
            "target": Target.linux_x86_64,
            "tarball_name": "test.tar.xz",
            "tarball_sha256": _VALID_SHA,
            "compressed_size_bytes": 10,
            "uncompressed_size_bytes": 20,
            "python_rel_path": "python/bin/python",
            "project_root_rel_path": "project",
            "signature": _VALID_SIG,
        }
        kwargs.pop(missing)
        with pytest.raises(ValidationError):
            WheelhouseManifest(**kwargs)

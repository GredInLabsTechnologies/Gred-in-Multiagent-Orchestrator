"""Tests for rove.patches.loader — patch index loader & resolver."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pytest

from rove.patches.loader import (
    PatchEntry,
    PatchKind,
    PatchLoadError,
    PatchSet,
    load_patch_set,
    resolve_patches,
)
from rove.signing.ed25519 import sha256_file
from rove.targets import Target


def _build_patch_set(
    tmp_path: Path,
    *,
    extra_entries: list[dict[str, Any]] | None = None,
    corrupt_after: bool = False,
    skip_file: bool = False,
) -> Path:
    """Create a patch set tree under tmp_path; return the root dir."""
    root = tmp_path / "pset"
    (root / "patches" / "foo").mkdir(parents=True)
    (root / "patches" / "baz").mkdir(parents=True)

    foo_patch = root / "patches" / "foo" / "bar.patch"
    foo_patch.write_text("--- a/x\n+++ b/x\n", encoding="utf-8")

    baz_env = root / "patches" / "baz" / "qux.env"
    baz_env.write_text("KEY=value\n", encoding="utf-8")

    entries: list[dict[str, Any]] = [
        {
            "id": "foo/bar",
            "package": "foo",
            "version_spec": ">=1.0.0",
            "targets": ["linux-x86_64", "android-arm64"],
            "kind": "patch",
            "path": "patches/foo/bar.patch",
            "sha256": sha256_file(foo_patch),
        },
        {
            "id": "baz/qux",
            "package": "baz",
            "version_spec": "",
            "targets": ["android-arm64"],
            "kind": "env",
            "path": "patches/baz/qux.env",
            "sha256": sha256_file(baz_env),
        },
    ]
    if extra_entries:
        entries.extend(extra_entries)

    manifest = {"version": 1, "patches": entries}
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    if corrupt_after:
        foo_patch.write_text("CORRUPTED CONTENT\n", encoding="utf-8")
    if skip_file:
        foo_patch.unlink()

    return root


def test_load_from_directory(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)
    assert isinstance(patch_set, PatchSet)
    assert patch_set.version == 1
    assert len(patch_set.patches) == 2
    assert patch_set.patches[0].id == "foo/bar"
    assert patch_set.patches[0].kind is PatchKind.patch
    assert patch_set.patches[1].kind is PatchKind.env


def test_load_from_explicit_manifest_path(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root / "manifest.json")
    assert len(patch_set.patches) == 2


def test_load_emits_unsigned_trust_warning(
    tmp_path: Path, caplog: pytest.LogCaptureFixture
) -> None:
    """The loader must log a WARNING that the index is not signature-verified.

    The V0.1.1 trust model pins per-file sha256 against the patch index,
    but the index itself has no Ed25519 envelope — an attacker rewriting
    both files and hashes would go undetected. The warning forces callers
    to audit the source path out-of-band.
    """
    root = _build_patch_set(tmp_path)
    with caplog.at_level("WARNING", logger="rove.patches.loader"):
        load_patch_set(root)
    messages = [r.getMessage() for r in caplog.records]
    assert any("Ed25519 signature" in m for m in messages)


def test_round_trip_serialization(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)
    dumped = patch_set.model_dump(mode="json")
    rebuilt = PatchSet.model_validate(dumped)
    assert rebuilt.version == patch_set.version
    assert len(rebuilt.patches) == len(patch_set.patches)
    assert rebuilt.patches[0].id == patch_set.patches[0].id


def test_resolve_patches_filter_by_package_and_target(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)

    # foo is targeted at linux-x86_64
    matched = resolve_patches(
        patch_set, packages=["foo"], target=Target.linux_x86_64
    )
    assert len(matched) == 1
    assert matched[0].id == "foo/bar"

    # baz is android-only
    matched_bz = resolve_patches(
        patch_set, packages=["baz"], target=Target.android_arm64
    )
    assert len(matched_bz) == 1
    assert matched_bz[0].id == "baz/qux"

    # both packages on android-arm64 → both match
    matched_both = resolve_patches(
        patch_set, packages=["foo", "baz"], target=Target.android_arm64
    )
    assert {e.id for e in matched_both} == {"foo/bar", "baz/qux"}


def test_resolve_patches_no_match_returns_empty(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)

    # unknown package
    assert resolve_patches(patch_set, packages=["nonexistent"], target=Target.linux_x86_64) == []
    # known package but wrong target (foo not on darwin)
    assert resolve_patches(patch_set, packages=["foo"], target=Target.darwin_arm64) == []


def test_resolve_patches_version_spec_passes(tmp_path: Path) -> None:
    """version_spec is best-effort; non-empty valid specs should pass."""
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)
    matched = resolve_patches(
        patch_set, packages=["foo"], target=Target.linux_x86_64
    )
    assert matched
    assert matched[0].version_spec == ">=1.0.0"


def test_load_missing_manifest_raises(tmp_path: Path) -> None:
    empty = tmp_path / "empty_pset"
    empty.mkdir()
    with pytest.raises(PatchLoadError, match="manifest"):
        load_patch_set(empty)


def test_load_missing_index_file_raises(tmp_path: Path) -> None:
    with pytest.raises(PatchLoadError):
        load_patch_set(tmp_path / "no_such.json")


def test_load_sha256_mismatch_raises(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path, corrupt_after=True)
    with pytest.raises(PatchLoadError, match="sha256"):
        load_patch_set(root)


def test_load_missing_patch_file_raises(tmp_path: Path) -> None:
    root = _build_patch_set(tmp_path, skip_file=True)
    with pytest.raises(PatchLoadError, match="missing"):
        load_patch_set(root)


def test_load_malformed_json_raises(tmp_path: Path) -> None:
    root = tmp_path / "broken"
    root.mkdir()
    (root / "manifest.json").write_text("{not valid json", encoding="utf-8")
    with pytest.raises(PatchLoadError, match="JSON"):
        load_patch_set(root)


def test_load_non_object_json_raises(tmp_path: Path) -> None:
    root = tmp_path / "broken2"
    root.mkdir()
    (root / "manifest.json").write_text("[1, 2, 3]", encoding="utf-8")
    with pytest.raises(PatchLoadError):
        load_patch_set(root)


def test_patch_entry_invalid_sha256_rejected() -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        PatchEntry(
            id="x",
            package="x",
            version_spec="",
            targets=[Target.linux_x86_64],
            kind=PatchKind.env,
            path="x.env",
            sha256="not_hex_at_all_too_short",
        )


# ---------------------------------------------------------------------------
# Coverage-completion tests for the remaining branches in loader.py
# ---------------------------------------------------------------------------


def test_patch_entry_sha256_right_length_but_not_hex() -> None:
    """64 chars but non-hex → covers ``int(.., 16)`` branch (lines 105-106)."""
    from pydantic import ValidationError

    with pytest.raises(ValidationError, match="not valid hex"):
        PatchEntry(
            id="x",
            package="x",
            version_spec="",
            targets=[Target.linux_x86_64],
            kind=PatchKind.env,
            path="x.env",
            sha256="z" * 64,
        )


def test_patch_entry_targets_not_a_list() -> None:
    """``targets`` scalar instead of list → covers line 114."""
    from pydantic import ValidationError

    with pytest.raises(ValidationError, match="targets must be a list"):
        PatchEntry(
            id="x",
            package="x",
            version_spec="",
            targets="linux-x86_64",  # type: ignore[arg-type]
            kind=PatchKind.env,
            path="x.env",
            sha256="0" * 64,
        )


def test_patch_entry_target_entry_wrong_type() -> None:
    """``targets=[123]`` → covers line 122."""
    from pydantic import ValidationError

    with pytest.raises(ValidationError, match="must be str or Target"):
        PatchEntry(
            id="x",
            package="x",
            version_spec="",
            targets=[123],  # type: ignore[list-item]
            kind=PatchKind.env,
            path="x.env",
            sha256="0" * 64,
        )


def test_load_index_unreadable_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """OSError reading manifest.json → covers lines 139-140."""
    root = _build_patch_set(tmp_path)
    index_path = root / "manifest.json"

    real_read_text = Path.read_text

    def raising_read_text(self: Path, *a: object, **kw: object) -> str:
        if self == index_path:
            raise OSError("permission denied")
        return real_read_text(self, *a, **kw)  # type: ignore[arg-type]

    monkeypatch.setattr(Path, "read_text", raising_read_text)
    with pytest.raises(PatchLoadError, match="cannot read patch index"):
        load_patch_set(root)


def test_load_schema_violation_wraps_validation_error(tmp_path: Path) -> None:
    """Manifest JSON with a missing required field → covers lines 184-185."""
    root = tmp_path / "schema_bad"
    root.mkdir()
    manifest = {
        "version": 1,
        "patches": [
            {
                # Missing ``id``, ``package``, etc.
                "kind": "env",
            }
        ],
    }
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(PatchLoadError, match="schema validation"):
        load_patch_set(root)


def test_spec_matches_skips_when_packaging_unavailable(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``_HAS_PACKAGING`` is False, any spec is accepted → covers line 220."""
    from rove.patches import loader as loader_mod

    monkeypatch.setattr(loader_mod, "_HAS_PACKAGING", False)
    root = _build_patch_set(tmp_path)
    patch_set = load_patch_set(root)
    matched = resolve_patches(
        patch_set, packages=["foo"], target=Target.linux_x86_64
    )
    # foo has version_spec=">=1.0.0"; packaging-disabled path returns True.
    assert len(matched) == 1


def test_spec_matches_invalid_specifier_filtered_out(tmp_path: Path) -> None:
    """A garbage version_spec is filtered → covers lines 223-224 + 260."""
    extra_root = tmp_path / "extra"
    extra_root.mkdir(parents=True)

    # Build a separate patch set so we control the version_spec value.
    spec_file = tmp_path / "spec_pset" / "patches" / "demo" / "p.env"
    spec_file.parent.mkdir(parents=True)
    spec_file.write_text("X=1\n", encoding="utf-8")
    manifest = {
        "version": 1,
        "patches": [
            {
                "id": "demo/p",
                "package": "demo",
                "version_spec": "this is not a valid PEP 440 specifier",
                "targets": ["linux-x86_64"],
                "kind": "env",
                "path": "patches/demo/p.env",
                "sha256": sha256_file(spec_file),
            }
        ],
    }
    root = tmp_path / "spec_pset"
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")

    patch_set = load_patch_set(root)
    matched = resolve_patches(
        patch_set, packages=["demo"], target=Target.linux_x86_64
    )
    # _spec_matches returned False → entry filtered out (covers 224 + 260 continue).
    assert matched == []


def test_load_patch_set_rejects_traversal(tmp_path: Path) -> None:
    """An index pointing at a file outside its directory is rejected.

    Defense-in-depth: the patch index is trust-on-first-use, but a
    tampered index must not be allowed to hash arbitrary host files
    (``/etc/passwd``, SSH keys, CI secrets) via a ``../`` path.
    """
    outside = tmp_path / "outside.patch"
    outside.write_text("--- a/x\n+++ b/x\n", encoding="utf-8")
    root = tmp_path / "pset"
    root.mkdir()
    manifest = {
        "version": 1,
        "patches": [
            {
                "id": "bad/escape",
                "package": "demo",
                "version_spec": "",
                "targets": ["linux-x86_64"],
                "kind": "patch",
                "path": "../outside.patch",
                "sha256": sha256_file(outside),
            }
        ],
    }
    (root / "manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(PatchLoadError, match="escapes"):
        load_patch_set(root)

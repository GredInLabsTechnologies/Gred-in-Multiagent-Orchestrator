"""Tests for :mod:`rove.signing.ed25519`."""
from __future__ import annotations

import base64
import hashlib
import os
from collections.abc import Callable
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import (
    Encoding,
    PublicFormat,
    load_pem_public_key,
)

from rove.manifest import WheelhouseManifest
from rove.signing import ed25519 as ed25519_module
from rove.signing import keygen
from rove.signing.ed25519 import (
    RuntimeSignatureError,
    _normalize_pubkey_input,
    sha256_file,
    sign,
    sign_manifest,
    verify,
    verify_manifest,
)


def _raw_pub_from_pem(pem: bytes) -> bytes:
    pub = load_pem_public_key(pem)
    assert isinstance(pub, Ed25519PublicKey)
    return pub.public_bytes(Encoding.Raw, PublicFormat.Raw)


@pytest.fixture
def signed_manifest_factory(
    ephemeral_keypair: tuple[bytes, bytes],
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
) -> Callable[..., tuple[WheelhouseManifest, bytes, bytes]]:
    """Build (signed_manifest, private_pem, public_pem) using ephemeral keys."""

    def _make(**overrides: object) -> tuple[WheelhouseManifest, bytes, bytes]:
        priv_pem, pub_pem = ephemeral_keypair
        m = synthetic_manifest_factory(**overrides)
        signed = sign_manifest(m, priv_pem)
        return signed, priv_pem, pub_pem

    return _make


class TestSignVerifyRoundtrip:
    def test_roundtrip_pem_bytes_private(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        payload = b"hello, world"
        sig = sign(payload, priv_pem)
        assert len(sig) == 128
        assert verify(payload, sig, additional_keys=[pub_pem]) is True

    def test_roundtrip_pem_string_private(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        payload = b"data"
        sig = sign(payload, priv_pem.decode("utf-8"))
        assert verify(payload, sig, additional_keys=[pub_pem]) is True

    def test_roundtrip_private_from_path(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair_files: tuple[Path, Path],
    ) -> None:
        priv_path, pub_path = ephemeral_keypair_files
        payload = b"file-based key"
        sig = sign(payload, priv_path)
        assert verify(payload, sig, additional_keys=[pub_path]) is True

    def test_sign_manifest_populates_signature(
        self,
        clean_trusted_env: Path,
        signed_manifest_factory: Callable[
            ..., tuple[WheelhouseManifest, bytes, bytes]
        ],
    ) -> None:
        signed, _, pub_pem = signed_manifest_factory()
        assert len(signed.signature) == 128
        assert all(c in "0123456789abcdef" for c in signed.signature)
        assert verify_manifest(signed, additional_keys=[pub_pem]) is True


class TestKeyRotation:
    """Critical gate: multiple trusted keys must all verify their own sigs."""

    def test_key_a_sig_validates_under_pool_a_b(
        self,
        clean_trusted_env: Path,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ) -> None:
        priv_a, pub_a = keygen.generate_inmemory()
        _, pub_b = keygen.generate_inmemory()
        m = synthetic_manifest_factory()
        signed_a = sign_manifest(m, priv_a)
        assert (
            verify_manifest(signed_a, additional_keys=[pub_a, pub_b]) is True
        )

    def test_key_b_sig_validates_under_pool_a_b(
        self,
        clean_trusted_env: Path,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ) -> None:
        _, pub_a = keygen.generate_inmemory()
        priv_b, pub_b = keygen.generate_inmemory()
        m = synthetic_manifest_factory()
        signed_b = sign_manifest(m, priv_b)
        assert (
            verify_manifest(signed_b, additional_keys=[pub_a, pub_b]) is True
        )

    def test_tampered_under_rotation_pool_returns_false(
        self,
        clean_trusted_env: Path,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ) -> None:
        priv_a, pub_a = keygen.generate_inmemory()
        _, pub_b = keygen.generate_inmemory()
        m = synthetic_manifest_factory()
        signed = sign_manifest(m, priv_a)
        # Flip one hex char.
        bad_char = "f" if signed.signature[0] != "f" else "e"
        tampered_sig = bad_char + signed.signature[1:]
        tampered = signed.model_copy(update={"signature": tampered_sig})
        assert (
            verify_manifest(tampered, additional_keys=[pub_a, pub_b]) is False
        )

    def test_unknown_key_signature_rejected(
        self,
        clean_trusted_env: Path,
        synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ) -> None:
        # Sign with a key that is NOT in the trusted pool.
        priv_unknown, _ = keygen.generate_inmemory()
        _, pub_a = keygen.generate_inmemory()
        _, pub_b = keygen.generate_inmemory()
        m = synthetic_manifest_factory()
        signed = sign_manifest(m, priv_unknown)
        assert (
            verify_manifest(signed, additional_keys=[pub_a, pub_b]) is False
        )


class TestTamperDetection:
    def test_changed_runtime_version_rejected(
        self,
        clean_trusted_env: Path,
        signed_manifest_factory: Callable[
            ..., tuple[WheelhouseManifest, bytes, bytes]
        ],
    ) -> None:
        signed, _, pub_pem = signed_manifest_factory(runtime_version="1.0.0")
        tampered = signed.model_copy(update={"runtime_version": "9.9.9"})
        assert verify_manifest(tampered, additional_keys=[pub_pem]) is False

    def test_changed_tarball_sha256_rejected(
        self,
        clean_trusted_env: Path,
        signed_manifest_factory: Callable[
            ..., tuple[WheelhouseManifest, bytes, bytes]
        ],
    ) -> None:
        signed, _, pub_pem = signed_manifest_factory()
        new_sha = "1" * 64
        tampered = signed.model_copy(update={"tarball_sha256": new_sha})
        assert verify_manifest(tampered, additional_keys=[pub_pem]) is False

    def test_flipped_signature_char_rejected(
        self,
        clean_trusted_env: Path,
        signed_manifest_factory: Callable[
            ..., tuple[WheelhouseManifest, bytes, bytes]
        ],
    ) -> None:
        signed, _, pub_pem = signed_manifest_factory()
        bad_char = "f" if signed.signature[0] != "f" else "e"
        tampered_sig = bad_char + signed.signature[1:]
        tampered = signed.model_copy(update={"signature": tampered_sig})
        assert verify_manifest(tampered, additional_keys=[pub_pem]) is False

    def test_malformed_signature_raises(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        _, pub_pem = ephemeral_keypair
        with pytest.raises(RuntimeSignatureError):
            verify(b"payload", "not-hex-zz!!", additional_keys=[pub_pem])


class TestNoTrustedKeys:
    def test_verify_raises_when_no_trust_configured(
        self, clean_trusted_env: Path
    ) -> None:
        # 128 hex chars, well-formed but no trusted keys at all.
        with pytest.raises(RuntimeSignatureError, match="no trusted Ed25519"):
            verify(b"x", "ab" * 64)

    def test_verify_manifest_raises_when_no_trust_configured(
        self,
        clean_trusted_env: Path,
        signed_manifest_factory: Callable[
            ..., tuple[WheelhouseManifest, bytes, bytes]
        ],
    ) -> None:
        signed, _, _ = signed_manifest_factory()
        with pytest.raises(RuntimeSignatureError, match="no trusted Ed25519"):
            verify_manifest(signed)


class TestTrustSources:
    def test_env_var_pem_with_escaped_newlines(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        escaped = pub_pem.decode("utf-8").replace("\n", "\\n")
        monkeypatch.setenv("ROVE_TRUSTED_PUBKEYS", escaped)
        sig = sign(b"env-trust", priv_pem)
        assert verify(b"env-trust", sig) is True

    def test_env_var_base64_raw_key(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        raw = _raw_pub_from_pem(pub_pem)
        b64 = base64.b64encode(raw).decode("ascii")
        monkeypatch.setenv("ROVE_TRUSTED_PUBKEYS", b64)
        sig = sign(b"raw-b64", priv_pem)
        assert verify(b"raw-b64", sig) is True

    def test_user_dir_pem_files(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        clean_trusted_env.mkdir(parents=True, exist_ok=True)
        (clean_trusted_env / "trusted.pem").write_bytes(pub_pem)
        sig = sign(b"user-dir-trust", priv_pem)
        assert verify(b"user-dir-trust", sig) is True

    def test_user_dir_skips_bad_pem(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        clean_trusted_env.mkdir(parents=True, exist_ok=True)
        (clean_trusted_env / "good.pem").write_bytes(pub_pem)
        (clean_trusted_env / "bad.pem").write_bytes(b"not a real PEM")
        sig = sign(b"x", priv_pem)
        # The bad PEM should be skipped (logged) and the good one used.
        assert verify(b"x", sig) is True

    def test_additional_keys_path(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair_files: tuple[Path, Path],
    ) -> None:
        priv_path, pub_path = ephemeral_keypair_files
        sig = sign(b"path-trust", priv_path)
        assert verify(b"path-trust", sig, additional_keys=[pub_path]) is True

    def test_additional_keys_bytes(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        sig = sign(b"bytes-trust", priv_pem)
        assert verify(b"bytes-trust", sig, additional_keys=[pub_pem]) is True

    def test_additional_keys_string(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        pub_str = pub_pem.decode("utf-8")
        sig = sign(b"str-trust", priv_pem)
        assert verify(b"str-trust", sig, additional_keys=[pub_str]) is True

    def test_additional_keys_mixed_types(
        self,
        clean_trusted_env: Path,
        ephemeral_keypair: tuple[bytes, bytes],
        ephemeral_keypair_files: tuple[Path, Path],
    ) -> None:
        priv_pem, pub_pem = ephemeral_keypair
        _, pub_path = ephemeral_keypair_files
        sig = sign(b"mixed", priv_pem)
        # Pub from bytes should validate; the Path one is just along for
        # the ride to confirm mixed iterables work.
        assert (
            verify(
                b"mixed",
                sig,
                additional_keys=[pub_path, pub_pem, pub_pem.decode("utf-8")],
            )
            is True
        )


class TestNormalizePubkeyInput:
    def test_raw_32_bytes(
        self, ephemeral_keypair: tuple[bytes, bytes]
    ) -> None:
        _, pub_pem = ephemeral_keypair
        raw = _raw_pub_from_pem(pub_pem)
        assert len(raw) == 32
        decoded = _normalize_pubkey_input(raw)
        assert isinstance(decoded, Ed25519PublicKey)
        assert decoded.public_bytes(Encoding.Raw, PublicFormat.Raw) == raw

    def test_raw_wrong_length_rejected(self) -> None:
        # Bytes that are neither 32, nor PEM, nor valid base64.
        with pytest.raises(RuntimeSignatureError):
            _normalize_pubkey_input(b"!!!" * 5)

    def test_pem_string(
        self, ephemeral_keypair: tuple[bytes, bytes]
    ) -> None:
        _, pub_pem = ephemeral_keypair
        decoded = _normalize_pubkey_input(pub_pem.decode("utf-8"))
        assert isinstance(decoded, Ed25519PublicKey)

    def test_base64_string_raw(
        self, ephemeral_keypair: tuple[bytes, bytes]
    ) -> None:
        _, pub_pem = ephemeral_keypair
        raw = _raw_pub_from_pem(pub_pem)
        b64 = base64.b64encode(raw).decode("ascii")
        decoded = _normalize_pubkey_input(b64)
        assert (
            decoded.public_bytes(Encoding.Raw, PublicFormat.Raw) == raw
        )

    def test_invalid_string_rejected(self) -> None:
        with pytest.raises(RuntimeSignatureError):
            _normalize_pubkey_input("not pem and not base64 !!!")

    def test_unreadable_path_rejected(self, tmp_path: Path) -> None:
        with pytest.raises(RuntimeSignatureError):
            _normalize_pubkey_input(tmp_path / "does-not-exist.pem")


class TestSha256File:
    def test_matches_hashlib_small_file(self, tmp_path: Path) -> None:
        data = b"the quick brown fox jumps over the lazy dog"
        p = tmp_path / "small.bin"
        p.write_bytes(data)
        assert sha256_file(p) == hashlib.sha256(data).hexdigest()

    def test_empty_file(self, tmp_path: Path) -> None:
        p = tmp_path / "empty.bin"
        p.write_bytes(b"")
        assert sha256_file(p) == hashlib.sha256(b"").hexdigest()

    def test_one_megabyte_random_file(self, tmp_path: Path) -> None:
        data = os.urandom(1024 * 1024)
        p = tmp_path / "big.bin"
        p.write_bytes(data)
        assert sha256_file(p) == hashlib.sha256(data).hexdigest()

    def test_chunk_size_irrelevant_to_result(self, tmp_path: Path) -> None:
        data = os.urandom(200_000)
        p = tmp_path / "med.bin"
        p.write_bytes(data)
        expected = hashlib.sha256(data).hexdigest()
        assert sha256_file(p, chunk_size=17) == expected
        assert sha256_file(p, chunk_size=64 * 1024) == expected


class TestKeyLoadingErrors:
    def test_sign_with_garbage_pem_raises(self) -> None:
        with pytest.raises(RuntimeSignatureError):
            sign(b"x", b"-----BEGIN PRIVATE KEY-----\nnope\n-----END PRIVATE KEY-----\n")

    def test_sign_with_missing_file_raises(self, tmp_path: Path) -> None:
        with pytest.raises(RuntimeSignatureError):
            sign(b"x", tmp_path / "no-such-file.pem")

    def test_sign_with_non_ed25519_pem_raises(self) -> None:
        """Valid PKCS#8 PEM but RSA, not Ed25519 — covers line 116."""
        rsa_priv = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        rsa_pem = rsa_priv.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        with pytest.raises(RuntimeSignatureError, match="Ed25519 private key"):
            sign(b"x", rsa_pem)


class TestPubkeyDecodeErrors:
    """Cover the various failure paths in ``_decode_pem_or_raw``."""

    def test_pem_marker_with_garbage_body_raises(self) -> None:
        """``BEGIN PUBLIC KEY`` marker but unparsable body — covers 175-176."""
        bad = (
            b"-----BEGIN PUBLIC KEY-----\nnot-real-base64-content\n"
            b"-----END PUBLIC KEY-----\n"
        )
        with pytest.raises(RuntimeSignatureError, match="invalid Ed25519 public key PEM"):
            _normalize_pubkey_input(bad)

    def test_non_ed25519_pem_public_raises(self) -> None:
        """Valid public-key PEM but RSA — covers line 180."""
        rsa_pub = rsa.generate_private_key(
            public_exponent=65537, key_size=2048
        ).public_key()
        rsa_pub_pem = rsa_pub.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        with pytest.raises(RuntimeSignatureError, match="does not encode an Ed25519"):
            _normalize_pubkey_input(rsa_pub_pem)

    def test_bytes_decoded_via_base64_path(
        self, ephemeral_keypair: tuple[bytes, bytes]
    ) -> None:
        """Bytes that aren't PEM nor 32 bytes but are valid base64 → covers line 196."""
        _, pub_pem = ephemeral_keypair
        raw = (
            load_pem_public_key(pub_pem)
            .public_bytes(Encoding.Raw, PublicFormat.Raw)  # type: ignore[attr-defined]
        )
        # base64-encoded raw key as bytes (length != 32, not PEM).
        b64_bytes = base64.b64encode(raw)
        assert len(b64_bytes) != 32
        assert b"BEGIN PUBLIC KEY" not in b64_bytes
        decoded = _normalize_pubkey_input(b64_bytes)
        assert isinstance(decoded, Ed25519PublicKey)

    def test_base64_decodes_to_wrong_length_raises(self) -> None:
        """Base64 of 16 bytes (wrong key length) → covers line 202 raise."""
        sixteen = b"\x00" * 16
        b64 = base64.b64encode(sixteen).decode("ascii")
        with pytest.raises(RuntimeSignatureError, match="must be 32 bytes"):
            _normalize_pubkey_input(b64)


class TestEnvVarTrustParsing:
    def test_env_var_skips_empty_entries(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        """Empty comma-separated entries are skipped → covers continue at 227."""
        priv_pem, pub_pem = ephemeral_keypair
        raw = (
            load_pem_public_key(pub_pem)
            .public_bytes(Encoding.Raw, PublicFormat.Raw)  # type: ignore[attr-defined]
        )
        b64 = base64.b64encode(raw).decode("ascii")
        # Surround with empty entries so the ``continue`` branch runs.
        monkeypatch.setenv("ROVE_TRUSTED_PUBKEYS", f",,{b64},,")
        sig = sign(b"empties", priv_pem)
        assert verify(b"empties", sig) is True

    def test_env_var_logs_and_skips_bad_entry(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        """Malformed env entry is logged + skipped → covers 230-231."""
        priv_pem, pub_pem = ephemeral_keypair
        raw = (
            load_pem_public_key(pub_pem)
            .public_bytes(Encoding.Raw, PublicFormat.Raw)  # type: ignore[attr-defined]
        )
        b64 = base64.b64encode(raw).decode("ascii")
        # First entry is invalid (not PEM, not valid base64); second is good.
        monkeypatch.setenv(
            "ROVE_TRUSTED_PUBKEYS", f"!!!!not-pem-not-b64!!!!,{b64}"
        )
        with caplog.at_level("WARNING"):
            sig = sign(b"bad-then-good", priv_pem)
            assert verify(b"bad-then-good", sig) is True
        assert any(
            "skipping bad" in record.message for record in caplog.records
        )


class TestVerifyUnexpectedKeyFailure:
    def test_unexpected_exception_in_trusted_key_logged_and_skipped(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        """A trusted key whose .verify raises non-InvalidSignature → covers 327-329."""
        priv_pem, pub_pem = ephemeral_keypair

        # Build a faux pubkey object whose ``verify`` raises a generic error.
        class ExplodingKey:
            def verify(self, sig: bytes, payload: bytes) -> None:
                raise RuntimeError("simulated key failure")

        real_pub = load_pem_public_key(pub_pem)
        # Patch the trusted-key collector to return [exploding, real] so the
        # loop hits the unexpected-exception branch and then the real key.
        def fake_collect(additional_keys: object) -> list[object]:
            return [ExplodingKey(), real_pub]

        monkeypatch.setattr(
            ed25519_module, "_collect_trusted_keys", fake_collect
        )
        sig = sign(b"explode-then-real", priv_pem)
        with caplog.at_level("WARNING"):
            assert verify(b"explode-then-real", sig) is True
        assert any(
            "unexpected error" in record.message for record in caplog.records
        )

    def test_only_exploding_key_returns_false(
        self,
        clean_trusted_env: Path,
        monkeypatch: pytest.MonkeyPatch,
        caplog: pytest.LogCaptureFixture,
        ephemeral_keypair: tuple[bytes, bytes],
    ) -> None:
        """Single exploding trusted key → loop ends with False (no match)."""
        priv_pem, _ = ephemeral_keypair

        class ExplodingKey:
            def verify(self, sig: bytes, payload: bytes) -> None:
                raise RuntimeError("boom")

        def fake_collect(additional_keys: object) -> list[object]:
            return [ExplodingKey()]

        monkeypatch.setattr(
            ed25519_module, "_collect_trusted_keys", fake_collect
        )
        sig = sign(b"only-explode", priv_pem)
        with caplog.at_level("WARNING"):
            assert verify(b"only-explode", sig) is False

"""Shared fixtures for the Rove test suite.

These fixtures isolate tests from the developer's real
``~/.config/rove/trusted_keys/`` directory and the
``ROVE_TRUSTED_PUBKEYS`` environment variable, and provide convenient
ephemeral keypairs and synthetic manifests.
"""
from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

from rove.manifest import WheelhouseManifest
from rove.signing import ed25519 as ed25519_module
from rove.signing import keygen
from rove.targets import Compression, Target

# A canonical valid 64-hex SHA-256 (sha256 of empty bytes).
_EMPTY_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
# A canonical 128-hex placeholder signature.
_PLACEHOLDER_SIG = "00" * 64


@pytest.fixture
def ephemeral_keypair() -> tuple[bytes, bytes]:
    """Yield a freshly generated ``(private_pem, public_pem)`` Ed25519 pair."""
    return keygen.generate_inmemory()


@pytest.fixture
def ephemeral_keypair_files(tmp_path: Path) -> tuple[Path, Path]:
    """Yield ``(private_path, public_path)`` written into ``tmp_path``."""
    return keygen.generate_keypair(tmp_path / "keys")


@pytest.fixture
def synthetic_manifest_factory() -> Callable[..., WheelhouseManifest]:
    """Return a factory that builds valid :class:`WheelhouseManifest` objects.

    Every required field has a sensible default; callers may override any
    field by passing keyword arguments.
    """

    def _factory(**overrides: Any) -> WheelhouseManifest:
        defaults: dict[str, Any] = {
            "project_name": "rove-test",
            "runtime_version": "0.1.0",
            "target": Target.linux_x86_64,
            "compression": Compression.zstd,
            "tarball_name": "rove-test-runtime.tar.zst",
            "tarball_sha256": _EMPTY_SHA256,
            "compressed_size_bytes": 1024,
            "uncompressed_size_bytes": 4096,
            "python_rel_path": "python/bin/python3.11",
            "project_root_rel_path": "project",
            "wheels_rel_path": "wheelhouse",
            "python_path_entries": ["project", "site-packages"],
            "files": ["python/bin/python3.11"],
            "extra_env": {"PYTHONDONTWRITEBYTECODE": "1"},
            "patches_applied": [],
            "signature": _PLACEHOLDER_SIG,
        }
        defaults.update(overrides)
        return WheelhouseManifest(**defaults)

    return _factory


@pytest.fixture
def clean_trusted_env(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> Path:
    """Strip global trust sources so tests use only what they configure.

    Removes ``ROVE_TRUSTED_PUBKEYS`` from the environment and redirects
    ``rove.signing.ed25519._USER_TRUSTED_DIR`` to a tmp_path subdirectory
    so tests never touch the developer's real
    ``~/.config/rove/trusted_keys/``.

    Returns the redirected user-trusted-dir path so tests that need to
    drop PEM files into it can do so without recomputing the path.
    """
    monkeypatch.delenv("ROVE_TRUSTED_PUBKEYS", raising=False)
    fake_user_dir = tmp_path / "fake_trusted_keys"
    monkeypatch.setattr(
        ed25519_module, "_USER_TRUSTED_DIR", fake_user_dir
    )
    return fake_user_dir

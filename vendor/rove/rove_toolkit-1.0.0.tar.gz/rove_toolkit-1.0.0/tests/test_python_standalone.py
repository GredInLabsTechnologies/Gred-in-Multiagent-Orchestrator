"""Tests for rove.builder.python_standalone — fetch + extract."""
from __future__ import annotations

import hashlib
import io
import tarfile
import urllib.error
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from rove.builder import python_standalone
from rove.builder.python_standalone import (
    StandaloneFetchError,
    fetch_standalone_python,
)
from rove.targets import Target


def _build_fake_tarball() -> bytes:
    """Build a minimal .tar.gz containing python/bin/python3 placeholder."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        payload = b"#!/usr/bin/env python3\n"
        info = tarfile.TarInfo(name="python/bin/python3")
        info.size = len(payload)
        info.mode = 0o755
        tf.addfile(info, io.BytesIO(payload))
    return buf.getvalue()


class _FakeResponse:
    """Mimics urllib HTTP response context manager."""

    def __init__(self, payload: bytes, status: int = 200) -> None:
        self._buf = io.BytesIO(payload)
        self.status = status

    def read(self, n: int = -1) -> bytes:
        return self._buf.read(n)

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, *exc: object) -> None:
        self._buf.close()


@pytest.mark.parametrize(
    "android_target", [Target.android_arm64, Target.android_armv7]
)
def test_android_targets_raise_notimplemented(android_target: Target) -> None:
    with pytest.raises(NotImplementedError, match="Termux"):
        fetch_standalone_python(android_target)


def test_default_cache_dir_uses_home(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.delenv("ROVE_STANDALONE_CACHE", raising=False)
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    cache = python_standalone._default_cache_dir()
    assert tmp_path in cache.parents or cache.is_relative_to(tmp_path)
    assert cache.name == "python-standalone"


def test_env_override_for_cache_dir(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    custom = tmp_path / "my_custom_cache"
    monkeypatch.setenv("ROVE_STANDALONE_CACHE", str(custom))
    cache = python_standalone._default_cache_dir()
    assert cache == custom


def test_fetch_success_extracts_tree(tmp_path: Path) -> None:
    cache = tmp_path / "cache"
    payload = _build_fake_tarball()
    sha = hashlib.sha256(payload).hexdigest()

    def fake_urlopen(url: str, timeout: int = 0):
        if url.endswith(".sha256"):
            return _FakeResponse(f"{sha}  asset.tar.gz".encode())
        return _FakeResponse(payload)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ):
        result = fetch_standalone_python(
            Target.linux_x86_64, cache_dir=cache
        )

    assert result.is_dir()
    assert result.name == "python"
    assert (result / "bin" / "python3").is_file()


def test_fetch_idempotent_second_call_no_network(tmp_path: Path) -> None:
    cache = tmp_path / "cache"
    payload = _build_fake_tarball()
    sha = hashlib.sha256(payload).hexdigest()

    def fake_urlopen(url: str, timeout: int = 0):
        if url.endswith(".sha256"):
            return _FakeResponse(f"{sha}  x".encode())
        return _FakeResponse(payload)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ):
        first = fetch_standalone_python(Target.linux_x86_64, cache_dir=cache)

    # Second invocation must hit the cache → urlopen never called.
    mock = MagicMock()
    with patch.object(python_standalone.urllib.request, "urlopen", mock):
        second = fetch_standalone_python(Target.linux_x86_64, cache_dir=cache)

    assert first == second
    assert mock.call_count == 0


def test_fetch_sha256_mismatch_raises(tmp_path: Path) -> None:
    cache = tmp_path / "cache"
    payload = _build_fake_tarball()
    bogus_sha = "0" * 64

    def fake_urlopen(url: str, timeout: int = 0):
        if url.endswith(".sha256"):
            return _FakeResponse(f"{bogus_sha}  x".encode())
        return _FakeResponse(payload)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ), pytest.raises(StandaloneFetchError, match="SHA-256"):
        fetch_standalone_python(Target.linux_x86_64, cache_dir=cache)


def test_fetch_sha256_mismatch_cleans_poisoned_cache(tmp_path: Path) -> None:
    """A tarball that fails verify must be deleted so the next run re-downloads.

    Before the cleanup branch landed, the poisoned tarball stayed on disk;
    ``_download_streaming``'s "cache hit" short-circuit then skipped the
    download forever and ``_verify_sha256`` kept raising on the stale bytes.
    """
    cache = tmp_path / "cache"
    payload = _build_fake_tarball()
    bogus_sha = "0" * 64

    def fake_urlopen(url: str, timeout: int = 0):
        if url.endswith(".sha256"):
            return _FakeResponse(f"{bogus_sha}  x".encode())
        return _FakeResponse(payload)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ), pytest.raises(StandaloneFetchError):
        fetch_standalone_python(Target.linux_x86_64, cache_dir=cache)

    # No stray tarball should remain in the cache after a verify failure.
    leftover = list(cache.glob("*.tar.gz"))
    assert leftover == [], f"poisoned tarball left in cache: {leftover}"


def test_fetch_network_error_raises(tmp_path: Path) -> None:
    cache = tmp_path / "cache"

    def boom(url: str, timeout: int = 0):
        raise python_standalone.urllib.error.URLError("network unreachable")

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=boom
    ), pytest.raises(StandaloneFetchError):
        fetch_standalone_python(Target.linux_x86_64, cache_dir=cache)


def test_host_target_rejected(tmp_path: Path) -> None:
    with pytest.raises(StandaloneFetchError, match="resolved"):
        fetch_standalone_python(Target.host, cache_dir=tmp_path)


# ---------------------------------------------------------------------------
# Internal helpers / edge cases
# ---------------------------------------------------------------------------
def test_resolve_release_passes_full_version_through() -> None:
    """A full ``X.Y.Z`` triple is returned unchanged (covers line 85)."""
    release, full = python_standalone._resolve_release("3.14.2")
    assert release == python_standalone._DEFAULT_RELEASE
    assert full == "3.14.2"


def test_asset_url_for_unmapped_target_raises() -> None:
    """``_asset_url`` raises for Android (no triple) — covers line 92."""
    with pytest.raises(StandaloneFetchError, match="no python-build-standalone"):
        python_standalone._asset_url(
            Target.android_arm64, release="x", full_pyver="3.13.13"
        )


def test_download_streaming_cache_hit_returns_immediately(tmp_path: Path) -> None:
    """Existing non-empty file short-circuits download (covers lines 103-104)."""
    dest = tmp_path / "asset.tar.gz"
    dest.write_bytes(b"already-cached")
    mock = MagicMock()
    with patch.object(python_standalone.urllib.request, "urlopen", mock):
        python_standalone._download_streaming("http://example/x", dest)
    assert mock.call_count == 0
    assert dest.read_bytes() == b"already-cached"


def test_download_streaming_http_non_200_raises(tmp_path: Path) -> None:
    """HTTP non-200 raises after exhausting retries (covers line 118 + 131)."""
    dest = tmp_path / "asset.tar.gz"

    def fake_urlopen(url: str, timeout: int = 0) -> _FakeResponse:
        # Touch the .part file so the cleanup branch (line 131) runs.
        tmp = dest.with_suffix(dest.suffix + ".part")
        tmp.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_bytes(b"partial")
        return _FakeResponse(b"", status=503)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ), pytest.raises(StandaloneFetchError, match="failed to download"):
        python_standalone._download_streaming("http://example/x", dest)
    assert not dest.with_suffix(dest.suffix + ".part").exists()


def test_verify_sha256_http_non_200_raises(tmp_path: Path) -> None:
    """Non-200 from .sha256 endpoint raises (covers line 156)."""
    tarball = tmp_path / "x.tar.gz"
    tarball.write_bytes(b"data")

    def fake_urlopen(url: str, timeout: int = 0) -> _FakeResponse:
        return _FakeResponse(b"", status=404)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ), pytest.raises(StandaloneFetchError, match="HTTP 404"):
        python_standalone._verify_sha256(tarball, "http://example/x.sha256")


def test_verify_sha256_network_error_raises(tmp_path: Path) -> None:
    """URLError fetching the checksum raises (covers lines 160-161)."""
    tarball = tmp_path / "x.tar.gz"
    tarball.write_bytes(b"data")

    def boom(url: str, timeout: int = 0) -> _FakeResponse:
        raise urllib.error.URLError("dns failure")

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=boom
    ), pytest.raises(StandaloneFetchError, match="cannot fetch checksum"):
        python_standalone._verify_sha256(tarball, "http://example/x.sha256")


def test_verify_sha256_invalid_payload_raises(tmp_path: Path) -> None:
    """Payload that isn't 64-hex raises (covers line 168)."""
    tarball = tmp_path / "x.tar.gz"
    tarball.write_bytes(b"data")

    def fake_urlopen(url: str, timeout: int = 0) -> _FakeResponse:
        return _FakeResponse(b"deadbeef")  # too short

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ), pytest.raises(StandaloneFetchError, match="not a SHA-256 hex"):
        python_standalone._verify_sha256(tarball, "http://example/x.sha256")


def test_extract_tarball_replaces_existing_dir(tmp_path: Path) -> None:
    """Pre-existing extract_root is wiped before extracting (covers line 186)."""
    tarball = tmp_path / "asset.tar.gz"
    tarball.write_bytes(_build_fake_tarball())
    extract_root = tmp_path / "out"
    extract_root.mkdir()
    (extract_root / "stale.txt").write_text("old", encoding="utf-8")

    python_root = python_standalone._extract_tarball(tarball, extract_root)

    assert python_root.is_dir()
    assert not (extract_root / "stale.txt").exists()


def test_extract_tarball_invalid_archive_raises(tmp_path: Path) -> None:
    """Garbage tarball triggers TarError path (covers lines 191-193)."""
    tarball = tmp_path / "asset.tar.gz"
    tarball.write_bytes(b"not a tarball")
    extract_root = tmp_path / "out"

    with pytest.raises(StandaloneFetchError, match="failed to extract"):
        python_standalone._extract_tarball(tarball, extract_root)
    assert not extract_root.exists()


def test_extract_tarball_missing_python_root_raises(tmp_path: Path) -> None:
    """Tarball without ``python/`` dir is rejected (covers lines 199-200)."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tf:
        info = tarfile.TarInfo(name="other/file.txt")
        payload = b"x"
        info.size = len(payload)
        tf.addfile(info, io.BytesIO(payload))
    tarball = tmp_path / "asset.tar.gz"
    tarball.write_bytes(buf.getvalue())
    extract_root = tmp_path / "out"

    with pytest.raises(StandaloneFetchError, match="unexpected python-build-standalone"):
        python_standalone._extract_tarball(tarball, extract_root)
    assert not extract_root.exists()


def test_fetch_with_full_python_version_uses_passthrough(tmp_path: Path) -> None:
    """Full ``X.Y.Z`` python_version is passed through and shows in URL."""
    cache = tmp_path / "cache"
    payload = _build_fake_tarball()
    sha = hashlib.sha256(payload).hexdigest()
    seen_urls: list[str] = []

    def fake_urlopen(url: str, timeout: int = 0) -> _FakeResponse:
        seen_urls.append(url)
        if url.endswith(".sha256"):
            return _FakeResponse(f"{sha}  asset".encode())
        return _FakeResponse(payload)

    with patch.object(
        python_standalone.urllib.request, "urlopen", side_effect=fake_urlopen
    ):
        fetch_standalone_python(
            Target.linux_x86_64, python_version="3.14.2", cache_dir=cache
        )
    # The asset URL must reflect the full version.
    assert any("cpython-3.14.2+" in u for u in seen_urls)

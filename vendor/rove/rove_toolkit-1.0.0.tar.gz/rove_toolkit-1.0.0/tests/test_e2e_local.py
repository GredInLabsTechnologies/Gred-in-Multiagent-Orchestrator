"""End-to-end integration tests — full pipeline against a local HTTP server.

These tests exercise the whole Rove distribution gate in one go:

* keygen → project tree → ``build_tarball`` → ``sign_manifest`` → write manifest
* spin up :class:`RoveHttpServer` on an ephemeral port
* :func:`fetch_bundle` against ``http://127.0.0.1:<port>``
* assert SHA-256 + signature round-trip

The second test exercises the key-rotation contract: a bundle signed by
key A continues to verify after being re-signed by key B as long as both
keys remain trusted; verification fails the moment key A alone is trusted
after the re-signing.
"""
from __future__ import annotations

import json
import socket
from collections.abc import Callable
from pathlib import Path

import pytest

from rove.builder.tarball import TarballBuildOptions, build_tarball
from rove.distribution.http_fetcher import FetchOptions, fetch_bundle
from rove.distribution.http_server import HttpServerOptions, RoveHttpServer
from rove.manifest import WheelhouseManifest
from rove.signing import keygen
from rove.signing.ed25519 import sha256_file, sign_manifest, verify_manifest
from rove.targets import Compression, Target, resolve


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        port: int = sock.getsockname()[1]
    return port


def _make_project(root: Path) -> Path:
    src = root / "src" / "myapp"
    src.mkdir(parents=True)
    (src / "__init__.py").write_text("", encoding="utf-8")
    (src / "main.py").write_text("def go() -> int:\n    return 1\n", encoding="utf-8")
    return root


def _make_wheelhouse(root: Path) -> Path:
    wheels = root / "wheels"
    wheels.mkdir(parents=True)
    # An "empty" wheel — we just need a .whl file to exist; the tarball
    # stage inspects extension + name only, never the wheel contents.
    (wheels / "fakepkg-1.0-py3-none-any.whl").write_bytes(b"PK\x03\x04 fake-wheel")
    return wheels


def _build_signed_bundle(
    tmp_path: Path,
    *,
    private_key: Path,
    target: Target | None = None,
) -> tuple[Path, Path, WheelhouseManifest]:
    """Build + sign a real bundle on disk; return (bundle, manifest_sidecar, manifest)."""
    project = _make_project(tmp_path / "proj")
    wheels = _make_wheelhouse(tmp_path / "wh")
    out = tmp_path / "dist"
    resolved = target if target is not None else resolve(Target.host)

    opts = TarballBuildOptions(
        project_name="e2e-app",
        runtime_version="0.1.0",
        target=resolved,
        compression=Compression.xz,
        output_dir=out,
        python_root=None,  # skip standalone python for E2E speed
        wheels_dir=wheels,
        project_root=project,
        include=["src"],
        exclude=["__pycache__/", "*.pyc"],
    )
    result = build_tarball(opts)
    signed = sign_manifest(result.manifest, private_key)

    sidecar = result.tarball_path.with_name(result.tarball_path.name + ".manifest.json")
    sidecar.write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return result.tarball_path, sidecar, signed


# ---------------------------------------------------------------------------
# Test 1 — happy path: build → serve → fetch → verify
# ---------------------------------------------------------------------------
@pytest.mark.timeout(30)
def test_e2e_build_serve_fetch_verify(
    tmp_path: Path,
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_path, sidecar, signed = _build_signed_bundle(
        tmp_path, private_key=priv
    )
    assert sidecar.exists()
    original_bytes = bundle_path.read_bytes()
    expected_sha = sha256_file(bundle_path)
    assert expected_sha == signed.tarball_sha256

    # Stage server dir holding exactly the bundle + sidecar.
    server_dir = tmp_path / "served"
    server_dir.mkdir()
    (server_dir / bundle_path.name).write_bytes(original_bytes)
    (server_dir / sidecar.name).write_text(sidecar.read_text(encoding="utf-8"))

    out_dir = tmp_path / "downloaded"

    opts = HttpServerOptions(
        bundle_dir=server_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )

    # 1. Bundle on disk + sha matches.
    assert result.bundle_path.exists()
    assert sha256_file(result.bundle_path) == expected_sha
    # 2. Bytes round-tripped intact.
    assert result.bundle_path.read_bytes() == original_bytes
    # 3. Manifest round-trips: model_dump equals.
    assert result.manifest.model_dump(mode="json") == signed.model_dump(mode="json")
    # 4. Signature verifies under the trusted key.
    assert verify_manifest(result.manifest, additional_keys=[pub]) is True
    # 5. from_cache=False on first call.
    assert result.from_cache is False
    # Silence unused-fixture warning.
    _ = synthetic_manifest_factory


# ---------------------------------------------------------------------------
# Test 2 — key rotation contract
# ---------------------------------------------------------------------------
@pytest.mark.timeout(30)
def test_e2e_key_rotation(
    tmp_path: Path,
    clean_trusted_env: Path,
) -> None:
    keys_a = tmp_path / "ka"
    keys_b = tmp_path / "kb"
    priv_a, pub_a = keygen.generate_keypair(keys_a)
    priv_b, pub_b = keygen.generate_keypair(keys_b)

    # Build + sign with key A.
    bundle_path, sidecar, signed_a = _build_signed_bundle(
        tmp_path, private_key=priv_a
    )

    # Verify with both keys trusted → passes.
    assert verify_manifest(signed_a, additional_keys=[pub_a, pub_b]) is True

    # Re-sign the SAME bundle with key B.
    signed_b = sign_manifest(signed_a, priv_b)
    assert signed_b.signature != signed_a.signature
    sidecar.write_text(
        json.dumps(signed_b.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    # Verify with both keys trusted → still passes (rotation overlap window).
    assert verify_manifest(signed_b, additional_keys=[pub_a, pub_b]) is True

    # Verify with ONLY key A trusted after re-signing with B → fails.
    assert verify_manifest(signed_b, additional_keys=[pub_a]) is False

    # And key B alone still works.
    assert verify_manifest(signed_b, additional_keys=[pub_b]) is True

    # Sanity: the bundle bytes themselves did not change.
    assert sha256_file(bundle_path) == signed_b.tarball_sha256

"""Tests for ``rove.distribution`` — plugin protocol, HTTP server, HTTP fetcher."""
from __future__ import annotations

import io
import json
import socket
import threading
import urllib.error
import urllib.request
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest

from rove.distribution import http_fetcher as http_fetcher_module
from rove.distribution.http_fetcher import (
    FetchOptions,
    FetchResult,
    HttpDistributionBackend,
    fetch_bundle,
)
from rove.distribution.http_server import (
    HttpServerOptions,
    RoveHttpServer,
    serve,
)
from rove.distribution.plugin import DistributionBackend, DistributionError
from rove.manifest import WheelhouseManifest
from rove.signing import keygen
from rove.signing.ed25519 import sha256_file, sign_manifest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _free_port() -> int:
    """Find a free TCP port on 127.0.0.1 by binding-and-releasing."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        port: int = sock.getsockname()[1]
    return port


def _stage_signed_bundle(
    bundle_dir: Path,
    *,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    private_key: Path,
    bundle_name: str = "myapp-linux-x86_64-0.1.0.tar.xz",
    payload: bytes = b"opaque tarball bytes\n" * 16,
    sha_override: str | None = None,
) -> tuple[Path, Path, WheelhouseManifest]:
    """Write a fake bundle + matching signed manifest into ``bundle_dir``.

    Returns ``(bundle_path, manifest_path, signed_manifest)``.

    If ``sha_override`` is given, the manifest's ``tarball_sha256`` is set
    to that value (used to fabricate sha-mismatch scenarios).
    """
    bundle_dir.mkdir(parents=True, exist_ok=True)
    bundle_path = bundle_dir / bundle_name
    bundle_path.write_bytes(payload)
    actual_sha = sha256_file(bundle_path)
    declared_sha = sha_override or actual_sha

    manifest = synthetic_manifest_factory(
        project_name="myapp",
        runtime_version="0.1.0",
        tarball_name=bundle_name,
        tarball_sha256=declared_sha,
        compressed_size_bytes=bundle_path.stat().st_size,
    )
    signed = sign_manifest(manifest, private_key)
    manifest_path = bundle_path.with_name(bundle_path.name + ".manifest.json")
    manifest_path.write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return bundle_path, manifest_path, signed


# ---------------------------------------------------------------------------
# plugin.py
# ---------------------------------------------------------------------------
class _CompliantBackend:
    """Minimal class with the right method signatures."""

    def publish(self, manifest: WheelhouseManifest, payload: Path) -> str:
        return "compliant://example"

    def fetch(
        self, target: object, version: str | None = None
    ) -> tuple[WheelhouseManifest, Path]:  # pragma: no cover - never called
        raise NotImplementedError


class _IncompleteBackend:
    """Missing fetch — should not satisfy the protocol."""

    def publish(self, manifest: WheelhouseManifest, payload: Path) -> str:
        return ""


def test_distribution_error_is_runtime_error_subclass() -> None:
    assert issubclass(DistributionError, RuntimeError)
    err = DistributionError("boom")
    assert isinstance(err, RuntimeError)
    assert str(err) == "boom"


def test_distribution_backend_is_runtime_checkable_protocol() -> None:
    assert isinstance(_CompliantBackend(), DistributionBackend)


def test_incomplete_backend_does_not_satisfy_protocol() -> None:
    assert not isinstance(_IncompleteBackend(), DistributionBackend)


def test_arbitrary_object_does_not_satisfy_protocol() -> None:
    assert not isinstance(object(), DistributionBackend)


# ---------------------------------------------------------------------------
# http_server.py — option validation + lifecycle
# ---------------------------------------------------------------------------
def test_http_server_options_accepts_valid_inputs(tmp_path: Path) -> None:
    opts = HttpServerOptions(bundle_dir=tmp_path, host="127.0.0.1", port=8081)
    assert opts.bundle_dir == tmp_path
    assert opts.host == "127.0.0.1"
    assert opts.port == 8081


def test_http_server_options_rejects_out_of_range_port(tmp_path: Path) -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        HttpServerOptions(bundle_dir=tmp_path, port=0)
    with pytest.raises(ValidationError):
        HttpServerOptions(bundle_dir=tmp_path, port=70000)


def test_http_server_start_rejects_missing_bundle_dir(tmp_path: Path) -> None:
    missing = tmp_path / "does_not_exist"
    opts = HttpServerOptions(bundle_dir=missing, host="127.0.0.1", port=_free_port())
    server = RoveHttpServer(opts)
    with pytest.raises(DistributionError, match="bundle_dir does not exist"):
        server.start()


def test_http_server_start_rejects_empty_bundle_dir(tmp_path: Path) -> None:
    empty = tmp_path / "empty"
    empty.mkdir()
    opts = HttpServerOptions(bundle_dir=empty, host="127.0.0.1", port=_free_port())
    server = RoveHttpServer(opts)
    with pytest.raises(DistributionError, match="contains no bundles"):
        server.start()


def test_http_server_url_before_start_returns_configured_address(tmp_path: Path) -> None:
    opts = HttpServerOptions(bundle_dir=tmp_path, host="127.0.0.1", port=8123)
    server = RoveHttpServer(opts)
    assert server.url() == "http://127.0.0.1:8123"


def test_http_server_stop_is_idempotent(tmp_path: Path) -> None:
    opts = HttpServerOptions(bundle_dir=tmp_path, host="127.0.0.1", port=_free_port())
    server = RoveHttpServer(opts)
    # Never started — stop() should be a no-op.
    server.stop()
    server.stop()


# ---------------------------------------------------------------------------
# http_server.py — live server (context manager + GET + Range)
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_http_server_serves_get_200_and_404(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    bundle_path, _manifest_path, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    payload = bundle_path.read_bytes()

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        url = server.url()
        assert url.startswith("http://127.0.0.1:")

        # GET existing file → 200 with exact bytes.
        with urllib.request.urlopen(f"{url}/{bundle_path.name}", timeout=5) as resp:
            assert resp.status == 200
            assert resp.read() == payload

        # GET missing file → 404.
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(f"{url}/nope.tar.xz", timeout=5)
        assert exc_info.value.code == 404


@pytest.mark.timeout(20)
def test_http_server_honors_range_request(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    payload = b"abcdefghijklmnopqrstuvwxyz" * 4  # 104 bytes
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        payload=payload,
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        req = urllib.request.Request(
            f"{server.url()}/{bundle_path.name}",
            headers={"Range": "bytes=10-"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            assert resp.status == 206
            body = resp.read()
            assert body == payload[10:]
            assert resp.headers.get("Content-Range", "").startswith("bytes 10-")


@pytest.mark.timeout(20)
def test_http_server_range_unsatisfiable_returns_416(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    payload = b"only fifty bytes long payload for range test 0123."
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        payload=payload,
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        req = urllib.request.Request(
            f"{server.url()}/{bundle_path.name}",
            headers={"Range": "bytes=9999-"},
        )
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req, timeout=5)
        assert exc_info.value.code == 416


@pytest.mark.timeout(20)
def test_serve_blocking_returns_when_server_thread_dies(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """``serve`` is blocking; we monkeypatch ``RoveHttpServer.start`` to spawn
    a thread that exits immediately so the join loop returns without SIGINT."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )

    real_start = RoveHttpServer.start

    def _short_lived_start(self: RoveHttpServer) -> None:
        real_start(self)
        # Immediately tell the server to shut down so the join loop returns.
        assert self._httpd is not None
        threading.Thread(target=self._httpd.shutdown, daemon=True).start()

    monkeypatch.setattr(RoveHttpServer, "start", _short_lived_start)

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    # Should return cleanly within the test timeout.
    serve(opts)


# ---------------------------------------------------------------------------
# http_fetcher.py — option validation
# ---------------------------------------------------------------------------
def test_fetch_options_rejects_empty_source(tmp_path: Path) -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        FetchOptions(source="", bundle_name="x.tar.xz", output_dir=tmp_path)


def test_fetch_options_rejects_empty_bundle_name(tmp_path: Path) -> None:
    from pydantic import ValidationError

    with pytest.raises(ValidationError):
        FetchOptions(source="http://x", bundle_name="", output_dir=tmp_path)


def test_fetch_options_defaults(tmp_path: Path) -> None:
    opts = FetchOptions(
        source="http://example.com",
        bundle_name="b.tar.xz",
        output_dir=tmp_path,
    )
    assert opts.expected_sha256 is None
    assert opts.additional_pubkeys == []
    assert opts.max_retries >= 0
    assert opts.chunk_size >= 1024


# ---------------------------------------------------------------------------
# http_fetcher.py — happy path & cache & resume & failures
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_fetch_bundle_happy_path(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, _, signed = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    compressed_size = bundle_path.stat().st_size
    out_dir = tmp_path / "dl"

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )

    assert isinstance(result, FetchResult)
    assert result.bundle_path.exists()
    assert result.from_cache is False
    assert result.bytes_downloaded == compressed_size
    assert result.manifest.tarball_sha256 == signed.tarball_sha256
    # Manifest sidecar landed too.
    sidecar = result.bundle_path.with_name(result.bundle_path.name + ".manifest.json")
    assert sidecar.exists()


@pytest.mark.timeout(20)
def test_fetch_bundle_cache_hit_skips_network(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    out_dir = tmp_path / "dl"

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        first = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )
        second = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )

    assert first.from_cache is False
    assert second.from_cache is True
    assert second.bytes_downloaded == 0


@pytest.mark.timeout(20)
def test_fetch_bundle_resumes_partial_download(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    payload = b"resume me please " * 256  # > one chunk
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        payload=payload,
    )

    out_dir = tmp_path / "dl"
    out_dir.mkdir()
    final_size = bundle_path.stat().st_size
    half = final_size // 2

    # Pre-create a .part with first half — the fetcher must resume from there.
    partial = (out_dir / bundle_path.name).with_name(
        bundle_path.name + ".part"
    )
    partial.write_bytes(payload[:half])

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )

    assert result.from_cache is False
    # Only the missing tail crossed the wire.
    assert result.bytes_downloaded == final_size - half
    assert result.bundle_path.read_bytes() == payload


@pytest.mark.timeout(20)
def test_fetch_bundle_sha_mismatch_raises(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bogus_sha = "f" * 64  # valid hex, will never match the real bundle
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        sha_override=bogus_sha,
    )

    out_dir = tmp_path / "dl"
    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        pytest.raises(DistributionError, match="SHA-256 mismatch"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
                max_retries=0,
            )
        )


@pytest.mark.timeout(20)
def test_fetch_bundle_signature_failure_raises(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    clean_trusted_env: Path,
) -> None:
    """Sign with key A, only trust key B → DistributionError."""
    keys_a = tmp_path / "ka"
    keys_b = tmp_path / "kb"
    priv_a, _ = keygen.generate_keypair(keys_a)
    _, pub_b = keygen.generate_keypair(keys_b)

    bundle_dir = tmp_path / "server"
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv_a,
    )
    out_dir = tmp_path / "dl"

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server, pytest.raises(DistributionError):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub_b],
            )
        )


@pytest.mark.timeout(20)
def test_fetch_bundle_manifest_404_raises(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, manifest_path, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    # Remove the sidecar so manifest GET 404s.
    manifest_path.unlink()

    out_dir = tmp_path / "dl"
    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server, pytest.raises(DistributionError):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )


@pytest.mark.timeout(20)
def test_fetch_bundle_expected_sha_mismatch_with_manifest(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    out_dir = tmp_path / "dl"

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        pytest.raises(DistributionError, match="expected_sha256"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
                expected_sha256="a" * 64,
            )
        )


# ---------------------------------------------------------------------------
# HttpDistributionBackend
# ---------------------------------------------------------------------------
def test_http_backend_implements_protocol() -> None:
    backend = HttpDistributionBackend(source="http://x")
    assert isinstance(backend, DistributionBackend)


def test_http_backend_publish_returns_source(
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    tmp_path: Path,
) -> None:
    backend = HttpDistributionBackend(source="http://peer:8080")
    manifest = synthetic_manifest_factory()
    fake_payload = tmp_path / "anything.tar.xz"
    fake_payload.write_bytes(b"x")
    assert backend.publish(manifest, fake_payload) == "http://peer:8080"


def test_http_backend_publish_without_source_raises(
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    tmp_path: Path,
) -> None:
    backend = HttpDistributionBackend()
    fake_payload = tmp_path / "x.tar.xz"
    fake_payload.write_bytes(b"x")
    with pytest.raises(DistributionError):
        backend.publish(synthetic_manifest_factory(), fake_payload)


def test_http_backend_fetch_requires_source(tmp_path: Path) -> None:
    backend = HttpDistributionBackend(output_dir=tmp_path)
    from rove.targets import Target

    with pytest.raises(DistributionError):
        backend.fetch(Target.linux_x86_64, version="0.1.0")


def test_http_backend_fetch_requires_output_dir() -> None:
    from rove.targets import Target

    backend = HttpDistributionBackend(source="http://x")
    with pytest.raises(DistributionError):
        backend.fetch(Target.linux_x86_64, version="0.1.0")


def test_http_backend_fetch_requires_version(tmp_path: Path) -> None:
    from rove.targets import Target

    backend = HttpDistributionBackend(source="http://x", output_dir=tmp_path)
    with pytest.raises(DistributionError, match="version required"):
        backend.fetch(Target.linux_x86_64)


@pytest.mark.timeout(20)
def test_http_backend_fetch_round_trip(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """End-to-end: backend.fetch() pulls a real bundle from a real local server."""
    from rove.targets import Target

    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    # Backend builds the canonical name ``rove-<target>-<version>.tar.xz``.
    bundle_name = "rove-linux-x86_64-0.1.0.tar.xz"
    bundle_path, _, signed = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        bundle_name=bundle_name,
    )

    out_dir = tmp_path / "dl"
    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        backend = HttpDistributionBackend(
            source=server.url(),
            output_dir=out_dir,
            additional_pubkeys=[pub],
        )
        manifest, local_path = backend.fetch(
            Target.linux_x86_64, version="0.1.0"
        )

    assert local_path.exists()
    assert local_path.read_bytes() == bundle_path.read_bytes()
    assert manifest.tarball_sha256 == signed.tarball_sha256


# ---------------------------------------------------------------------------
# http_server.py — coverage for guess_type fallback, malformed Range,
# directory + missing-file Range, log_message exception path, stop() with
# nulled thread, serve() KeyboardInterrupt path.
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_http_server_guess_type_falls_back_for_unknown_extension(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """Requesting a ``.txt`` exits the ``_EXTRA_MIME_TYPES`` branch."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    extra = bundle_dir / "notes.txt"
    extra.write_bytes(b"plain text payload")

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        urllib.request.urlopen(f"{server.url()}/notes.txt", timeout=5) as resp,
    ):
        assert resp.status == 200
        ctype = resp.headers.get_content_type()
        # stdlib's default mime DB maps .txt → text/plain; the precise
        # subtype doesn't matter — what we're asserting is that the
        # ``_EXTRA_MIME_TYPES`` branch was bypassed.
        assert ctype.startswith("text/")


@pytest.mark.timeout(20)
def test_http_server_multirange_falls_back_to_full_response(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """Multi-range / malformed Range headers must degrade to a 200 full body."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    payload = b"abcdefghij" * 8
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
        payload=payload,
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        # Multi-range — our regex only accepts single-range.
        req = urllib.request.Request(
            f"{server.url()}/{bundle_path.name}",
            headers={"Range": "bytes=0-10,20-30"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            assert resp.status == 200
            assert resp.read() == payload


@pytest.mark.timeout(20)
def test_http_server_range_request_to_missing_file_returns_404(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """Range header against a non-existent file → ``os.stat`` fails → 404."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        req = urllib.request.Request(
            f"{server.url()}/missing.tar.xz",
            headers={"Range": "bytes=0-10"},
        )
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req, timeout=5)
        assert exc_info.value.code == 404


@pytest.mark.timeout(20)
def test_http_server_range_request_to_directory_falls_back(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """Range against a directory: stat OK but isfile False → super().do_GET()."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    (bundle_dir / "subdir").mkdir()

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        # SimpleHTTPRequestHandler returns a 301 redirect to ``subdir/`` for
        # directory requests without trailing slash; we follow that and just
        # verify the response is non-error so the fall-back branch executed.
        req = urllib.request.Request(
            f"{server.url()}/subdir/",
            headers={"Range": "bytes=0-10"},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            assert resp.status == 200


def test_http_server_log_message_swallows_non_numeric_status() -> None:
    """``log_message`` must not raise when args[1] is missing/non-numeric.

    The handler's ``log_message`` parses ``args[1]`` as an HTTP status; bad
    inputs hit the ``except (IndexError, ValueError, TypeError)`` branch and
    must silently set status=0 (no console output).
    """
    from rove.distribution.http_server import _BundleRequestHandler

    # Build a bare instance without invoking __init__ (which needs a real
    # socket); inject the class attributes the method touches.
    handler = _BundleRequestHandler.__new__(_BundleRequestHandler)
    captured: list[str] = []

    class _StubConsole:
        def print(self, msg: str) -> None:
            captured.append(msg)

    handler.server_console = _StubConsole()  # type: ignore[assignment]
    handler.client_address = ("127.0.0.1", 0)

    # No args → IndexError on args[1].
    handler.log_message("noop")
    # Non-numeric status string → ValueError.
    handler.log_message("noop %s %s", "GET", "not-a-status")
    # None status → TypeError on int(None).
    handler.log_message("noop %s %s", "GET", None)

    assert captured == []  # no 4xx/5xx → no console output


def test_http_server_log_error_routes_to_console() -> None:
    """``log_error`` always prints — exercises the alternate logging path."""
    from rove.distribution.http_server import _BundleRequestHandler

    handler = _BundleRequestHandler.__new__(_BundleRequestHandler)
    captured: list[str] = []

    class _StubConsole:
        def print(self, msg: str) -> None:
            captured.append(msg)

    handler.server_console = _StubConsole()  # type: ignore[assignment]
    handler.client_address = ("127.0.0.1", 0)
    handler.log_error("boom %s", "kaboom")
    assert len(captured) == 1
    assert "boom kaboom" in captured[0]


def test_http_server_log_message_emits_for_4xx(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """A real 4xx response routes through ``log_message`` and prints."""
    from rove.distribution.http_server import _BundleRequestHandler

    handler = _BundleRequestHandler.__new__(_BundleRequestHandler)
    captured: list[str] = []

    class _StubConsole:
        def print(self, msg: str) -> None:
            captured.append(msg)

    handler.server_console = _StubConsole()  # type: ignore[assignment]
    handler.client_address = ("127.0.0.1", 0)
    # ``log_message`` parses ``args[1]`` as the HTTP status code (matching
    # SimpleHTTPRequestHandler's default ``"%s" %s %s`` format string).
    handler.log_message('"GET /x HTTP/1.1" %s %s', "-", "404")
    assert len(captured) == 1
    assert "404" in captured[0]


@pytest.mark.timeout(20)
def test_http_server_stop_with_nulled_thread_is_safe(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """Covers the ``if self._thread is not None`` False branch in ``stop``."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    server = RoveHttpServer(opts)
    server.start()
    # Manually drop the thread reference so stop() takes the False branch.
    real_thread = server._thread
    server._thread = None
    try:
        server.stop()
    finally:
        # Make sure the real serving thread also gets joined to avoid leaks.
        if real_thread is not None and real_thread.is_alive():
            real_thread.join(timeout=5.0)


@pytest.mark.timeout(20)
def test_serve_blocking_returns_on_keyboard_interrupt(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """``serve`` must catch ``KeyboardInterrupt`` and return cleanly."""
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )

    real_join = threading.Thread.join

    def _raise_kbi(self: threading.Thread, timeout: float | None = None) -> None:
        # Restore the real join immediately so the ``finally: server.stop()``
        # path can join the serving thread normally during shutdown.
        threading.Thread.join = real_join  # type: ignore[method-assign]
        raise KeyboardInterrupt

    monkeypatch.setattr(threading.Thread, "join", _raise_kbi, raising=True)

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    serve(opts)  # must return without re-raising


# ---------------------------------------------------------------------------
# http_fetcher.py — _http_get_bytes transport error branches
# ---------------------------------------------------------------------------
class _StubOpener:
    """Tiny stand-in for ``urllib.request.OpenerDirector``.

    ``http_fetcher`` uses a safe opener built with our strict redirect
    handler; tests need to stub the opener's ``open()`` rather than the
    stdlib ``urlopen`` (which the opener bypasses). This helper plugs
    into :func:`_get_safe_opener` via :func:`monkeypatch.setattr`.
    """

    def __init__(self, behaviour: Callable[..., Any]) -> None:
        self._behaviour = behaviour

    def open(self, req: Any, timeout: float) -> Any:
        return self._behaviour(req, timeout=timeout)


def _install_stub_opener(
    monkeypatch: pytest.MonkeyPatch, behaviour: Callable[..., Any]
) -> None:
    monkeypatch.setattr(
        http_fetcher_module, "_get_safe_opener", lambda: _StubOpener(behaviour)
    )


def test_http_get_bytes_wraps_url_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """``URLError`` from the safe opener → ``DistributionError``."""
    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise urllib.error.URLError("nope")

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="unreachable"):
        http_fetcher_module._http_get_bytes(
            "http://x/y", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_get_bytes_wraps_timeout_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """``TimeoutError`` from the safe opener → ``DistributionError``."""
    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise TimeoutError("slow")

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="timed out"):
        http_fetcher_module._http_get_bytes(
            "http://x/y", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_get_bytes_wraps_http_error(monkeypatch: pytest.MonkeyPatch) -> None:
    """``HTTPError`` from the safe opener → ``DistributionError`` with status text."""
    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise urllib.error.HTTPError(
            url="http://x/y",
            code=503,
            msg="Service Unavailable",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="503"):
        http_fetcher_module._http_get_bytes(
            "http://x/y", connect_timeout=1.0, read_timeout=1.0
        )


# ---------------------------------------------------------------------------
# http_fetcher.py — _http_download_streaming branches
# ---------------------------------------------------------------------------
class _FakeResponse:
    """Minimal stand-in for urllib's HTTPResponse usable as a context manager."""

    def __init__(self, *, status: int, body: bytes) -> None:
        self._status = status
        self._buf = io.BytesIO(body)

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, *_exc: object) -> None:
        return None

    def getcode(self) -> int:
        return self._status

    def read(self, amt: int = -1) -> bytes:
        return self._buf.read(amt) if amt >= 0 else self._buf.read()


def test_http_download_streaming_server_ignores_range_restarts(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """status 200 with resume_from > 0 → restart, ``mode='wb'`` overwrites."""
    dest = tmp_path / "out.bin"
    dest.write_bytes(b"STALE")  # pre-existing partial that must be overwritten
    fresh = b"FRESH-" * 4

    fake = _FakeResponse(status=200, body=fresh)
    _install_stub_opener(monkeypatch, lambda _req, timeout: fake)
    pulled = http_fetcher_module._http_download_streaming(
        "http://x/y",
        dest,
        chunk_size=4,
        connect_timeout=1.0,
        read_timeout=1.0,
        resume_from=5,
    )
    assert pulled == len(fresh)
    assert dest.read_bytes() == fresh  # STALE was overwritten, not appended


def test_http_download_streaming_unexpected_status_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Status not in {200, 206} → DistributionError."""
    dest = tmp_path / "out.bin"
    _install_stub_opener(
        monkeypatch, lambda _req, timeout: _FakeResponse(status=418, body=b"")
    )
    with pytest.raises(DistributionError, match="unexpected HTTP 418"):
        http_fetcher_module._http_download_streaming(
            "http://x/y",
            dest,
            chunk_size=4,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
        )


def test_http_download_streaming_wraps_http_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    dest = tmp_path / "out.bin"

    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise urllib.error.HTTPError(
            url="http://x/y",
            code=502,
            msg="Bad Gateway",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="502"):
        http_fetcher_module._http_download_streaming(
            "http://x/y",
            dest,
            chunk_size=4,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
        )


def test_http_download_streaming_wraps_url_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    dest = tmp_path / "out.bin"

    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise urllib.error.URLError("nope")

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="unreachable"):
        http_fetcher_module._http_download_streaming(
            "http://x/y",
            dest,
            chunk_size=4,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
        )


def test_http_download_streaming_wraps_timeout(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
) -> None:
    dest = tmp_path / "out.bin"

    def _raise(*_a: Any, **_kw: Any) -> Any:
        raise TimeoutError("slow")

    _install_stub_opener(monkeypatch, _raise)
    with pytest.raises(DistributionError, match="timed out"):
        http_fetcher_module._http_download_streaming(
            "http://x/y",
            dest,
            chunk_size=4,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
        )


# ---------------------------------------------------------------------------
# http_fetcher.py — _download_with_retry exhaustion + recovery
# ---------------------------------------------------------------------------
def test_download_with_retry_recovers_after_transient_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """First attempt raises, second succeeds → returns total pulled bytes."""
    staging = tmp_path / "x.tar.xz.part"
    calls: list[int] = []

    def _flaky(
        url: str,
        dest: Path,
        *,
        chunk_size: int,
        connect_timeout: float,
        read_timeout: float,
        resume_from: int,
        max_total_bytes: int | None = None,
    ) -> int:
        calls.append(resume_from)
        if len(calls) == 1:
            raise DistributionError("transient")
        dest.write_bytes(b"OK")
        return 2

    monkeypatch.setattr(
        http_fetcher_module, "_http_download_streaming", _flaky
    )
    # Skip the real backoff sleep so the test stays fast.
    monkeypatch.setattr(http_fetcher_module.time, "sleep", lambda _s: None)

    opts = FetchOptions(
        source="http://x",
        bundle_name="x.tar.xz",
        output_dir=tmp_path,
        max_retries=2,
    )
    pulled = http_fetcher_module._download_with_retry(
        "http://x/x.tar.xz", staging, opts=opts
    )
    assert pulled == 2
    assert calls == [0, 0]  # second attempt re-checks resume_from


def test_download_with_retry_raises_after_exhaustion(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Every attempt raises → final attempt's error is re-raised."""
    staging = tmp_path / "y.tar.xz.part"

    def _always_fail(*_a: Any, **_kw: Any) -> int:
        raise DistributionError("permanent")

    monkeypatch.setattr(
        http_fetcher_module, "_http_download_streaming", _always_fail
    )
    monkeypatch.setattr(http_fetcher_module.time, "sleep", lambda _s: None)

    opts = FetchOptions(
        source="http://x",
        bundle_name="y.tar.xz",
        output_dir=tmp_path,
        max_retries=2,
    )
    with pytest.raises(DistributionError, match="permanent"):
        http_fetcher_module._download_with_retry(
            "http://x/y.tar.xz", staging, opts=opts
        )


def test_download_with_retry_resume_from_uses_partial_size(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If a ``.part`` already exists, the retry loop reads its size."""
    staging = tmp_path / "z.tar.xz.part"
    staging.write_bytes(b"abc")  # 3 bytes already on disk
    seen: list[int] = []

    def _spy(
        url: str,
        dest: Path,
        *,
        chunk_size: int,
        connect_timeout: float,
        read_timeout: float,
        resume_from: int,
        max_total_bytes: int | None = None,
    ) -> int:
        seen.append(resume_from)
        return 0

    monkeypatch.setattr(
        http_fetcher_module, "_http_download_streaming", _spy
    )
    opts = FetchOptions(
        source="http://x",
        bundle_name="z.tar.xz",
        output_dir=tmp_path,
        max_retries=0,
    )
    http_fetcher_module._download_with_retry(
        "http://x/z.tar.xz", staging, opts=opts
    )
    assert seen == [3]


# ---------------------------------------------------------------------------
# http_fetcher.py — fetch_bundle invalid manifest + signature error +
# stale local cache + atomic-replace branch.
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_fetch_bundle_invalid_manifest_json_raises(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """Manifest sidecar that isn't a valid WheelhouseManifest → DistributionError."""
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, manifest_path, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    manifest_path.write_text("{ this is not valid json", encoding="utf-8")

    out_dir = tmp_path / "dl"
    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        pytest.raises(DistributionError, match="not a valid WheelhouseManifest"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )


@pytest.mark.timeout(20)
def test_fetch_bundle_runtime_signature_error_wrapped(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """``verify_manifest`` raising ``RuntimeSignatureError`` → DistributionError.

    Triggered by configuring no trusted keys at all (clean env, empty
    additional_pubkeys); ``verify_manifest`` then raises
    ``RuntimeSignatureError`` which the fetcher wraps.
    """
    priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )

    out_dir = tmp_path / "dl"
    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        pytest.raises(DistributionError, match="signature verification failed"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[],  # no trust at all
            )
        )


@pytest.mark.timeout(20)
def test_fetch_bundle_stale_local_cache_redownloads(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """A pre-existing local bundle with mismatched sha is replaced.

    Exercises both the ``logger.info`` re-download branch and the
    ``bundle_path.unlink()`` step in the atomic-move epilogue.
    """
    priv, pub = ephemeral_keypair_files
    bundle_dir = tmp_path / "server"
    bundle_path, _, _ = _stage_signed_bundle(
        bundle_dir,
        synthetic_manifest_factory=synthetic_manifest_factory,
        private_key=priv,
    )
    real_payload = bundle_path.read_bytes()

    out_dir = tmp_path / "dl"
    out_dir.mkdir()
    stale_local = out_dir / bundle_path.name
    stale_local.write_bytes(b"stale local content that wont match the sha")
    assert sha256_file(stale_local) != sha256_file(bundle_path)

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=bundle_path.name,
                output_dir=out_dir,
                additional_pubkeys=[pub],
            )
        )

    assert result.from_cache is False
    assert result.bundle_path.read_bytes() == real_payload



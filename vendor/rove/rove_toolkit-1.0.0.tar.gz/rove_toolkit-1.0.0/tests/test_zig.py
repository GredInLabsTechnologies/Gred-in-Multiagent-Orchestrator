"""Tests for rove.builder.zig — discovery + cross-compile env."""
from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from rove.builder import zig as zig_mod
from rove.builder.zig import (
    ZigBuildEnv,
    ZigNotFoundError,
    ZigToolchain,
    build_env_for,
    discover_toolchain,
)
from rove.targets import Target


def test_discover_toolchain_success(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: "/usr/local/bin/zig")
    monkeypatch.setattr(
        zig_mod.subprocess,
        "run",
        lambda argv, **kw: subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="0.14.0\n", stderr=""
        ),
    )
    result = discover_toolchain()
    assert isinstance(result, ZigToolchain)
    assert result.version == "0.14.0"
    assert str(result.zig_path).endswith("zig")


def test_discover_toolchain_not_on_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: None)
    with pytest.raises(ZigNotFoundError):
        discover_toolchain()


def test_discover_toolchain_run_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: "/usr/bin/zig")
    monkeypatch.setattr(
        zig_mod.subprocess,
        "run",
        lambda argv, **kw: subprocess.CompletedProcess(
            args=argv, returncode=1, stdout="", stderr="bad install"
        ),
    )
    with pytest.raises(ZigNotFoundError):
        discover_toolchain()


def test_discover_toolchain_unparsable_output(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: "/usr/bin/zig")
    monkeypatch.setattr(
        zig_mod.subprocess,
        "run",
        lambda argv, **kw: subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="no version here", stderr=""
        ),
    )
    with pytest.raises(ZigNotFoundError):
        discover_toolchain()


@pytest.fixture
def fake_toolchain(tmp_path: Path) -> ZigToolchain:
    return ZigToolchain(zig_path=tmp_path / "zig", version="0.14.0")


def test_build_env_linux_x86_64(fake_toolchain: ZigToolchain) -> None:
    env = build_env_for(Target.linux_x86_64, toolchain=fake_toolchain)
    assert isinstance(env, ZigBuildEnv)
    assert "x86_64-linux-gnu.2.17" in env.cc
    assert "x86_64-linux-gnu.2.17" in env.cxx
    assert env.cargo_build_target == "x86_64-unknown-linux-gnu"
    assert env.target is Target.linux_x86_64
    assert "ANDROID_API_LEVEL" not in env.extra_env


@pytest.mark.parametrize(
    "target",
    [
        Target.linux_x86_64,
        Target.linux_arm64,
        Target.darwin_arm64,
        Target.darwin_x86_64,
        Target.windows_x86_64,
        Target.android_arm64,
        Target.android_armv7,
    ],
)
def test_build_env_for_all_concrete_targets(
    target: Target, fake_toolchain: ZigToolchain
) -> None:
    env = build_env_for(target, toolchain=fake_toolchain)
    assert env.cc, f"cc empty for {target}"
    assert env.cxx, f"cxx empty for {target}"
    assert env.ar, f"ar empty for {target}"
    assert env.cargo_build_target, f"cargo_build_target empty for {target}"
    assert env.target is target


def test_build_env_android_arm64_default_api(fake_toolchain: ZigToolchain) -> None:
    env = build_env_for(Target.android_arm64, toolchain=fake_toolchain)
    assert env.extra_env.get("ANDROID_API_LEVEL") == "24"
    assert "aarch64-linux-android.24" in env.cc


def test_build_env_android_arm64_custom_api(fake_toolchain: ZigToolchain) -> None:
    env = build_env_for(
        Target.android_arm64, toolchain=fake_toolchain, android_api_level=29
    )
    assert env.extra_env["ANDROID_API_LEVEL"] == "29"
    assert "aarch64-linux-android.29" in env.cc


def test_build_env_android_armv7_custom_api(fake_toolchain: ZigToolchain) -> None:
    env = build_env_for(
        Target.android_armv7, toolchain=fake_toolchain, android_api_level=21
    )
    assert env.extra_env["ANDROID_API_LEVEL"] == "21"
    assert "arm-linux-androideabi.21" in env.cc


def test_build_env_host_rejected(fake_toolchain: ZigToolchain) -> None:
    with pytest.raises(ValueError, match="resolve"):
        build_env_for(Target.host, toolchain=fake_toolchain)


def test_build_env_calls_discover_when_no_toolchain(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: str(tmp_path / "zig"))
    monkeypatch.setattr(
        zig_mod.subprocess,
        "run",
        lambda argv, **kw: subprocess.CompletedProcess(
            args=argv, returncode=0, stdout="0.14.0", stderr=""
        ),
    )
    env = build_env_for(Target.linux_x86_64)
    assert env.cargo_build_target == "x86_64-unknown-linux-gnu"


def test_discover_toolchain_oserror_invoking_zig(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``subprocess.run`` raises OSError → covers lines 112-113."""
    monkeypatch.setattr(zig_mod.shutil, "which", lambda name: "/usr/bin/zig")

    def raising_run(*a: object, **kw: object) -> object:
        raise OSError("exec format error")

    monkeypatch.setattr(zig_mod.subprocess, "run", raising_run)
    with pytest.raises(ZigNotFoundError, match="failed to invoke"):
        zig_mod.discover_toolchain()


def test_zig_target_triple_unmapped_target_raises() -> None:
    """``_zig_target_triple`` with an unmapped target → covers line 154."""
    # The only Target value the dispatch chain doesn't handle is ``host``
    # (build_env_for guards it, but the helper itself raises).
    with pytest.raises(ValueError, match="no zig triple"):
        zig_mod._zig_target_triple(Target.host, 24)

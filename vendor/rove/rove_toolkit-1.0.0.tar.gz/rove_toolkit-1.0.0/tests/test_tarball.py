"""Tests for :mod:`rove.builder.tarball`."""
from __future__ import annotations

import hashlib
import os
import sys
import tarfile
from pathlib import Path
from unittest.mock import patch

import pytest

from rove.builder import tarball as tarball_mod
from rove.builder.tarball import (
    TarballBuildError,
    TarballBuildOptions,
    build_tarball,
)
from rove.manifest import WheelhouseManifest
from rove.targets import Compression, Target

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
_FIXED_MTIME = 1_700_000_000


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _make_project_tree(root: Path) -> None:
    """Create a tiny deterministic project tree under ``root``."""
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "foo.py").write_text("print('hi')\n", encoding="utf-8")
    (src / "bar.py").write_text("X = 1\n", encoding="utf-8")

    data = root / "data"
    data.mkdir(exist_ok=True)
    (data / "x.txt").write_text("payload\n", encoding="utf-8")

    # excluded files
    tests = root / "tests"
    tests.mkdir(exist_ok=True)
    (tests / "skip_me.py").write_text("# excluded\n", encoding="utf-8")

    pyc_dir = root / "src" / "__pycache__"
    pyc_dir.mkdir(exist_ok=True)
    (pyc_dir / "foo.cpython-313.pyc").write_bytes(b"\x00\x01")
    (src / "stale.pyc").write_bytes(b"\x00\x01")

    # Touch every file to a fixed mtime so determinism doesn't depend on FS time.
    for p in root.rglob("*"):
        if p.is_file() or p.is_dir():
            os.utime(p, (_FIXED_MTIME, _FIXED_MTIME))


def _make_wheels_dir(root: Path) -> Path:
    wheels = root / "wheels"
    wheels.mkdir(parents=True, exist_ok=True)
    (wheels / "fakepkg-1.0-py3-none-any.whl").write_bytes(b"fake-wheel-content")
    (wheels / "another-2.0-py3-none-any.whl").write_bytes(b"another")
    for p in wheels.iterdir():
        os.utime(p, (_FIXED_MTIME, _FIXED_MTIME))
    return wheels


def _base_opts(
    *,
    output_dir: Path,
    project_root: Path,
    wheels_dir: Path,
    target: Target = Target.linux_x86_64,
    compression: Compression = Compression.xz,
    include: list[str] | None = None,
    python_root: Path | None = None,
) -> TarballBuildOptions:
    return TarballBuildOptions(
        project_name="myproj",
        runtime_version="0.1.0",
        target=target,
        compression=compression,
        output_dir=output_dir,
        python_root=python_root,
        wheels_dir=wheels_dir,
        project_root=project_root,
        include=include if include is not None else ["src", "data"],
        exclude=["tests/", "*.pyc", "__pycache__/"],
    )


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------
def test_build_tarball_xz_happy_path(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )

    assert isinstance(result.manifest, WheelhouseManifest)
    assert result.tarball_path.exists()
    assert result.tarball_path.suffix == ".xz"
    assert result.tarball_path.stat().st_size > 0
    assert result.compressed_size_bytes == result.tarball_path.stat().st_size

    assert result.manifest.tarball_name == "myproj-linux-x86_64-0.1.0.tar.xz"
    assert result.manifest.tarball_sha256 == _sha256(result.tarball_path)
    assert result.manifest.signature == "0" * 128
    assert result.manifest.project_root_rel_path == "project"
    assert result.manifest.wheels_rel_path == "wheelhouse"
    # No python bundled → defaults to placeholder.
    assert result.manifest.python_rel_path == "python/bin/python3"
    assert result.manifest.python_version is None


def test_build_tarball_contents_inspection(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )

    with tarfile.open(result.tarball_path, "r:xz") as tar:
        names = tar.getnames()

    base = "myproj-linux-x86_64-0.1.0"
    assert f"{base}/project/src/foo.py" in names
    assert f"{base}/project/src/bar.py" in names
    assert f"{base}/project/data/x.txt" in names
    assert f"{base}/wheelhouse/fakepkg-1.0-py3-none-any.whl" in names
    assert f"{base}/wheelhouse/another-2.0-py3-none-any.whl" in names

    # Excluded files MUST NOT appear.
    excluded = [n for n in names if "skip_me" in n or n.endswith(".pyc") or "__pycache__" in n]
    assert excluded == [], f"unexpected excluded entries in tar: {excluded}"

    # bundle_files in manifest mirror the tar layout (without staging prefix).
    assert "project/src/foo.py" in result.manifest.files
    assert "wheelhouse/fakepkg-1.0-py3-none-any.whl" in result.manifest.files


# ---------------------------------------------------------------------------
# Determinism
# ---------------------------------------------------------------------------
def test_build_tarball_is_deterministic(tmp_path: Path) -> None:
    """Two builds of identical sources must produce byte-identical tarballs."""
    project_a = tmp_path / "a" / "proj"
    project_b = tmp_path / "b" / "proj"
    _make_project_tree(project_a)
    _make_project_tree(project_b)

    wheels_a = _make_wheels_dir(tmp_path / "a")
    wheels_b = _make_wheels_dir(tmp_path / "b")

    out_a = tmp_path / "out_a"
    out_b = tmp_path / "out_b"

    r1 = build_tarball(
        _base_opts(output_dir=out_a, project_root=project_a, wheels_dir=wheels_a)
    )
    r2 = build_tarball(
        _base_opts(output_dir=out_b, project_root=project_b, wheels_dir=wheels_b)
    )

    assert r1.manifest.tarball_sha256 == r2.manifest.tarball_sha256
    assert _sha256(r1.tarball_path) == _sha256(r2.tarball_path)
    assert r1.tarball_path.stat().st_size == r2.tarball_path.stat().st_size


def test_build_tarball_zstd_is_deterministic(tmp_path: Path) -> None:
    """Determinism must hold for every compression mode we ship.

    Regression guard for the multi-threaded zstd config: with
    ``threads=-1`` the stream_writer was picking flush points based on
    thread scheduling and could produce byte-different (still-valid)
    output between runs. ``threads=0`` keeps the single-thread
    guarantee.
    """
    pytest.importorskip("zstandard")

    project_a = tmp_path / "a" / "proj"
    project_b = tmp_path / "b" / "proj"
    _make_project_tree(project_a)
    _make_project_tree(project_b)

    wheels_a = _make_wheels_dir(tmp_path / "a")
    wheels_b = _make_wheels_dir(tmp_path / "b")

    out_a = tmp_path / "out_a"
    out_b = tmp_path / "out_b"

    r1 = build_tarball(
        _base_opts(
            output_dir=out_a,
            project_root=project_a,
            wheels_dir=wheels_a,
            compression=Compression.zstd,
        )
    )
    r2 = build_tarball(
        _base_opts(
            output_dir=out_b,
            project_root=project_b,
            wheels_dir=wheels_b,
            compression=Compression.zstd,
        )
    )

    assert r1.manifest.tarball_sha256 == r2.manifest.tarball_sha256
    assert _sha256(r1.tarball_path) == _sha256(r2.tarball_path)
    assert r1.tarball_path.stat().st_size == r2.tarball_path.stat().st_size


# ---------------------------------------------------------------------------
# Compression options
# ---------------------------------------------------------------------------
def test_build_tarball_no_compression(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(
            output_dir=out,
            project_root=project,
            wheels_dir=wheels,
            compression=Compression.none,
        )
    )

    assert result.tarball_path.name == "myproj-linux-x86_64-0.1.0.tar"
    assert result.tarball_path.exists()
    # Plain tar opens in r: mode.
    with tarfile.open(result.tarball_path, "r") as tar:
        names = tar.getnames()
    assert any(n.endswith("/project/src/foo.py") for n in names)


def test_build_tarball_zstd_compression_optional(tmp_path: Path) -> None:
    """zstd works if `zstandard` is available; otherwise raises with helpful message."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    opts = _base_opts(
        output_dir=out,
        project_root=project,
        wheels_dir=wheels,
        compression=Compression.zstd,
    )

    try:
        import zstandard  # noqa: F401
    except ImportError:
        with pytest.raises(TarballBuildError, match="zstandard"):
            build_tarball(opts)
        return

    result = build_tarball(opts)
    assert result.tarball_path.name == "myproj-linux-x86_64-0.1.0.tar.zst"
    assert result.tarball_path.stat().st_size > 0


# ---------------------------------------------------------------------------
# Python tree bundling
# ---------------------------------------------------------------------------
def test_build_tarball_with_python_root(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    py_root = tmp_path / "pyroot"
    bin_dir = py_root / "bin"
    bin_dir.mkdir(parents=True)
    py_bin = bin_dir / "python3"
    py_bin.write_bytes(b"#!/bin/sh\necho fake\n")
    if os.name == "posix":
        py_bin.chmod(0o755)
    # Some adjacent non-bin file
    (py_root / "lib").mkdir()
    (py_root / "lib" / "libpython.so").write_bytes(b"\x7fELF")

    opts = _base_opts(
        output_dir=out,
        project_root=project,
        wheels_dir=wheels,
        python_root=py_root,
    )
    # Set python_version too so the manifest reflects it.
    opts = opts.model_copy(update={"python_version": "3.13.1"})

    result = build_tarball(opts)

    assert result.manifest.python_rel_path == "python/bin/python3"
    assert result.manifest.python_version == "3.13.1"

    with tarfile.open(result.tarball_path, "r:xz") as tar:
        names = tar.getnames()
        # Find the python3 binary entry to inspect mode.
        py_member = next(
            (
                m
                for m in tar.getmembers()
                if m.name.endswith("/python/bin/python3")
            ),
            None,
        )

    base = "myproj-linux-x86_64-0.1.0"
    assert f"{base}/python/bin/python3" in names
    assert f"{base}/python/lib/libpython.so" in names

    assert py_member is not None
    if os.name == "posix":
        # Exec bit preserved → mode normalized to 0o755 with +x bits.
        assert py_member.mode & 0o111, (
            f"python/bin/python3 should keep exec bit, got mode={oct(py_member.mode)}"
        )


def test_build_tarball_python_root_not_a_dir(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    bogus = tmp_path / "not_a_dir.txt"
    bogus.write_text("nope", encoding="utf-8")

    with pytest.raises(TarballBuildError, match="python_root is not a directory"):
        build_tarball(
            _base_opts(
                output_dir=out,
                project_root=project,
                wheels_dir=wheels,
                python_root=bogus,
            )
        )


# ---------------------------------------------------------------------------
# Include / exclude semantics
# ---------------------------------------------------------------------------
def test_build_tarball_include_only_one_root(tmp_path: Path) -> None:
    """Only ``src`` included → ``data/`` files absent from the bundle."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(
            output_dir=out,
            project_root=project,
            wheels_dir=wheels,
            include=["src"],
        )
    )

    with tarfile.open(result.tarball_path, "r:xz") as tar:
        names = tar.getnames()

    assert any(n.endswith("/project/src/foo.py") for n in names)
    assert not any("/project/data/" in n for n in names), (
        f"unexpected data/ entries: {[n for n in names if 'data' in n]}"
    )


def test_build_tarball_missing_include_silently_skipped(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    # Include a literal that doesn't exist alongside one that does.
    result = build_tarball(
        _base_opts(
            output_dir=out,
            project_root=project,
            wheels_dir=wheels,
            include=["src", "nonexistent_dir"],
        )
    )

    with tarfile.open(result.tarball_path, "r:xz") as tar:
        names = tar.getnames()
    assert any(n.endswith("/project/src/foo.py") for n in names)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------
def test_build_tarball_rejects_target_host(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    with pytest.raises(TarballBuildError, match=r"Target\.host"):
        build_tarball(
            _base_opts(
                output_dir=out,
                project_root=project,
                wheels_dir=wheels,
                target=Target.host,
            )
        )


def test_build_tarball_wheels_dir_missing(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    out = tmp_path / "out"

    with pytest.raises(TarballBuildError, match="wheels_dir"):
        build_tarball(
            _base_opts(
                output_dir=out,
                project_root=project,
                wheels_dir=tmp_path / "no_such_wheels",
            )
        )


def test_build_tarball_project_root_missing(tmp_path: Path) -> None:
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    with pytest.raises(TarballBuildError, match="project_root"):
        build_tarball(
            _base_opts(
                output_dir=out,
                project_root=tmp_path / "no_proj",
                wheels_dir=wheels,
            )
        )


def test_build_tarball_overwrites_existing_output(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"
    out.mkdir()

    # Pre-create a stale tarball at the expected path.
    stale = out / "myproj-linux-x86_64-0.1.0.tar.xz"
    stale.write_bytes(b"stale garbage")
    stale_size = stale.stat().st_size

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )
    # The new tarball replaced the stale bytes — the file is now a valid xz.
    assert result.tarball_path == stale.resolve()
    assert result.tarball_path.stat().st_size != stale_size
    with tarfile.open(result.tarball_path, "r:xz"):
        pass  # opens cleanly → it's a valid xz tarball


# ---------------------------------------------------------------------------
# Manifest schema round-trip
# ---------------------------------------------------------------------------
def test_manifest_round_trip(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )

    payload = result.manifest.model_dump_json()
    reparsed = WheelhouseManifest.model_validate_json(payload)
    assert reparsed == result.manifest


# ---------------------------------------------------------------------------
# Tarinfo normalization (uid/gid/mtime/uname/gname)
# ---------------------------------------------------------------------------
def test_tarinfo_metadata_normalized(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )

    with tarfile.open(result.tarball_path, "r:xz") as tar:
        members = tar.getmembers()

    assert members, "expected at least one tar member"
    for m in members:
        assert m.mtime == 0, f"{m.name} has mtime {m.mtime}"
        assert m.uid == 0
        assert m.gid == 0
        assert m.uname == ""
        assert m.gname == ""
        if m.isdir():
            assert m.mode == 0o755
        elif m.isreg() and not m.name.endswith("/python/bin/python3"):
            assert m.mode == 0o644, f"{m.name} has mode {oct(m.mode)}"


# ---------------------------------------------------------------------------
# Different concrete targets / compression filename mapping
# ---------------------------------------------------------------------------
@pytest.mark.parametrize(
    "target,expected_segment",
    [
        (Target.linux_arm64, "linux-arm64"),
        (Target.darwin_arm64, "darwin-arm64"),
        (Target.windows_x86_64, "windows-x86_64"),
        (Target.android_arm64, "android-arm64"),
    ],
)
def test_tarball_name_uses_target_string(
    tmp_path: Path,
    target: Target,
    expected_segment: str,
) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(
            output_dir=out, project_root=project, wheels_dir=wheels, target=target
        )
    )
    assert expected_segment in result.tarball_path.name
    assert result.tarball_path.name.endswith(".tar.xz")


def test_uncompressed_size_accounting(tmp_path: Path) -> None:
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
    )

    # Expected uncompressed = project file bytes + wheel file bytes.
    expected = 0
    for sub in ("src", "data"):
        for f in (project / sub).rglob("*"):
            if f.is_file() and not f.name.endswith(".pyc"):
                expected += f.stat().st_size
    for w in wheels.iterdir():
        expected += w.stat().st_size

    assert result.uncompressed_size_bytes == expected
    assert result.manifest.uncompressed_size_bytes == expected


# Suppress an unused-import warning on platforms where sys isn't otherwise used.
_ = sys


# ---------------------------------------------------------------------------
# _is_excluded — pattern branch coverage
# ---------------------------------------------------------------------------
class TestIsExcluded:
    """Direct unit tests for ``_is_excluded`` covering every branch."""

    def test_empty_pattern_skipped(self) -> None:
        # Slash-only normalizes to "" — must be skipped, not match everything.
        assert tarball_mod._is_excluded("anything.txt", ["/"]) is False

    def test_full_posix_path_match(self) -> None:
        # ``src/foo.py`` matches ``src/*.py`` via the full-posix branch.
        assert tarball_mod._is_excluded("src/foo.py", ["src/*.py"]) is True

    def test_segment_match(self) -> None:
        # ``__pycache__`` as a *segment* (not the basename) excludes the file.
        assert tarball_mod._is_excluded(
            "src/__pycache__/cache.txt", ["__pycache__"]
        ) is True

    def test_path_prefix_match(self) -> None:
        # Pattern ``vendor/junk`` excludes ``vendor/junk/file.txt``.
        assert tarball_mod._is_excluded(
            "vendor/junk/file.txt", ["vendor/junk"]
        ) is True

    def test_no_match_returns_false(self) -> None:
        assert tarball_mod._is_excluded("src/foo.py", ["docs/", "*.md"]) is False


# ---------------------------------------------------------------------------
# _collect_include_roots — duplicate literal + glob expansion branches
# ---------------------------------------------------------------------------
class TestCollectIncludeRoots:
    def test_empty_entry_skipped(self, tmp_path: Path) -> None:
        (tmp_path / "src").mkdir()
        roots = tarball_mod._collect_include_roots(tmp_path, ["", "src"])
        assert len(roots) == 1
        assert roots[0].name == "src"

    def test_duplicate_literal_dedup(self, tmp_path: Path) -> None:
        # Covers the ``literal in seen`` branch (line 173 False side).
        (tmp_path / "src").mkdir()
        roots = tarball_mod._collect_include_roots(tmp_path, ["src", "src"])
        assert len(roots) == 1

    def test_glob_match_collected(self, tmp_path: Path) -> None:
        # Covers lines 178-182 (glob branch + dedup of glob matches).
        pkgs = tmp_path / "packages"
        pkgs.mkdir()
        (pkgs / "alpha").mkdir()
        (pkgs / "beta").mkdir()
        roots = tarball_mod._collect_include_roots(tmp_path, ["packages/*"])
        names = sorted(r.name for r in roots)
        assert names == ["alpha", "beta"]

    def test_glob_dedup_with_literal(self, tmp_path: Path) -> None:
        # Same path matched by both literal and glob — must appear once.
        pkgs = tmp_path / "packages"
        pkgs.mkdir()
        (pkgs / "alpha").mkdir()
        roots = tarball_mod._collect_include_roots(
            tmp_path, ["packages/alpha", "packages/*"]
        )
        # alpha appears via both literal and glob; dedup keeps it once.
        alpha_count = sum(1 for r in roots if r.name == "alpha")
        assert alpha_count == 1


# ---------------------------------------------------------------------------
# _walk_files — file vs directory roots
# ---------------------------------------------------------------------------
def test_walk_files_single_file(tmp_path: Path) -> None:
    """When ``root`` is a regular file, ``_walk_files`` returns ``[root]``."""
    f = tmp_path / "lonely.txt"
    f.write_text("hi", encoding="utf-8")
    assert tarball_mod._walk_files(f) == [f]


# ---------------------------------------------------------------------------
# _normalize_tarinfo — every branch
# ---------------------------------------------------------------------------
class TestNormalizeTarinfo:
    def _info(self, name: str = "x") -> tarfile.TarInfo:
        info = tarfile.TarInfo(name=name)
        info.uid = 1234
        info.gid = 5678
        info.mtime = 99999
        info.uname = "alice"
        info.gname = "wheel"
        return info

    def test_directory_mode(self) -> None:
        info = self._info("d")
        info.type = tarfile.DIRTYPE
        info.mode = 0o700
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=False)
        assert out.mode == 0o755
        assert out.mtime == 0
        assert out.uid == 0 and out.gid == 0
        assert out.uname == "" and out.gname == ""

    def test_regular_preserve_exec_bit(self) -> None:
        info = self._info("f")
        info.type = tarfile.REGTYPE
        info.mode = 0o755  # has +x
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=True)
        assert out.mode == 0o755

    def test_regular_no_preserve_strips_exec(self) -> None:
        info = self._info("f")
        info.type = tarfile.REGTYPE
        info.mode = 0o755
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=False)
        assert out.mode == 0o644

    def test_regular_preserve_but_no_exec_bit(self) -> None:
        info = self._info("f")
        info.type = tarfile.REGTYPE
        info.mode = 0o644  # no +x
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=True)
        assert out.mode == 0o644

    def test_symlink_mode(self) -> None:
        info = self._info("l")
        info.type = tarfile.SYMTYPE
        info.linkname = "target"
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=False)
        assert out.mode == 0o777

    def test_hardlink_mode(self) -> None:
        info = self._info("l")
        info.type = tarfile.LNKTYPE
        info.linkname = "target"
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=False)
        assert out.mode == 0o777

    def test_other_type_falls_back_to_644(self) -> None:
        # Character device — neither dir, reg, sym, nor lnk.
        info = self._info("c")
        info.type = tarfile.CHRTYPE
        info.mode = 0o600
        out = tarball_mod._normalize_tarinfo(info, preserve_exec=False)
        assert out.mode == 0o644


# ---------------------------------------------------------------------------
# _add_file — gettarinfo None + non-regular file branches
# ---------------------------------------------------------------------------
def test_add_file_gettarinfo_none_raises(tmp_path: Path) -> None:
    """When ``tar.gettarinfo`` returns None, ``_add_file`` raises."""
    out_path = tmp_path / "x.tar"
    src = tmp_path / "src.txt"
    src.write_text("hi", encoding="utf-8")
    with tarfile.open(out_path, "w") as tar, patch.object(
        tar, "gettarinfo", return_value=None
    ), pytest.raises(TarballBuildError, match="could not stat"):
        tarball_mod._add_file(tar, src, "x", preserve_exec=False)


def test_add_file_directory_returns_zero(tmp_path: Path) -> None:
    """Adding a directory yields size 0 and exercises the non-reg branch."""
    out_path = tmp_path / "x.tar"
    d = tmp_path / "subdir"
    d.mkdir()
    with tarfile.open(out_path, "w") as tar:
        size = tarball_mod._add_file(tar, d, "subdir", preserve_exec=False)
    assert size == 0
    with tarfile.open(out_path, "r") as tar:
        members = tar.getmembers()
    assert len(members) == 1
    assert members[0].isdir()


# ---------------------------------------------------------------------------
# _stage_project — file-include + escape-detection + dedup branches
# ---------------------------------------------------------------------------
def test_stage_project_with_file_include(tmp_path: Path) -> None:
    """Include entry that resolves to a file (not a dir) is staged once."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "single.txt").write_text("hello", encoding="utf-8")
    (project / "src").mkdir()
    (project / "src" / "a.py").write_text("a", encoding="utf-8")

    entries, total = tarball_mod._stage_project(
        project,
        include=["single.txt", "src"],
        exclude=[],
        staging_root=Path("bundle"),
    )
    arcnames = {arc for _, arc in entries}
    assert "bundle/project/single.txt" in arcnames
    assert "bundle/project/src/a.py" in arcnames
    assert total > 0


def test_stage_project_file_include_excluded(tmp_path: Path) -> None:
    """File-include filtered by exclude pattern is omitted (line 328)."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "skip.pyc").write_bytes(b"\x00")

    entries, _ = tarball_mod._stage_project(
        project,
        include=["skip.pyc"],
        exclude=["*.pyc"],
        staging_root=Path("bundle"),
    )
    assert entries == []


def test_stage_project_file_include_dedup(tmp_path: Path) -> None:
    """File-include arcname already seen via prior dir walk is skipped (line 332).

    Order matters: the directory walk runs first and registers the file's
    arcname; the subsequent file-include hits the file-branch dedup check.
    """
    project = tmp_path / "proj"
    project.mkdir()
    src = project / "src"
    src.mkdir()
    (src / "a.py").write_text("a", encoding="utf-8")

    entries, _ = tarball_mod._stage_project(
        project,
        include=["src", "src/a.py"],
        exclude=[],
        staging_root=Path("bundle"),
    )
    arcs = [arc for _, arc in entries]
    assert arcs.count("bundle/project/src/a.py") == 1


def test_stage_project_dir_include_dedup(tmp_path: Path) -> None:
    """Same file collected twice via overlapping includes is deduped (line 347)."""
    project = tmp_path / "proj"
    project.mkdir()
    src = project / "src"
    src.mkdir()
    (src / "a.py").write_text("a", encoding="utf-8")

    # File-include comes first → its arcname is registered. The subsequent
    # directory walk encounters the same file and hits the dir-iter dedup
    # branch (line 347).
    entries, _ = tarball_mod._stage_project(
        project,
        include=["src/a.py", "src"],
        exclude=[],
        staging_root=Path("bundle"),
    )
    arcs = [arc for _, arc in entries]
    assert arcs.count("bundle/project/src/a.py") == 1


def test_stage_project_include_outside_root_raises(tmp_path: Path) -> None:
    """Include path that escapes ``project_root`` is rejected (lines 319-321)."""
    project = tmp_path / "proj"
    project.mkdir()
    (project / "src").mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "evil.py").write_text("x", encoding="utf-8")

    with pytest.raises(TarballBuildError, match="outside project_root"):
        tarball_mod._stage_project(
            project,
            include=["../outside"],
            exclude=[],
            staging_root=Path("bundle"),
        )


def test_stage_project_walked_file_outside_root_skipped(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """If ``_walk_files`` returns a path outside ``project_root``, it is silently
    skipped via the ``except ValueError`` branch (lines 341-342)."""
    project = tmp_path / "proj"
    project.mkdir()
    src = project / "src"
    src.mkdir()
    (src / "real.py").write_text("ok", encoding="utf-8")

    rogue = tmp_path / "rogue.py"
    rogue.write_text("x", encoding="utf-8")

    real_walk = tarball_mod._walk_files

    def patched_walk(root: Path) -> list[Path]:
        if root == src.resolve() or root == src:
            # Inject a rogue path that lives outside ``project_root``.
            return [*real_walk(root), rogue]
        return real_walk(root)

    monkeypatch.setattr(tarball_mod, "_walk_files", patched_walk)

    entries, _ = tarball_mod._stage_project(
        project,
        include=["src"],
        exclude=[],
        staging_root=Path("bundle"),
    )
    arcs = [arc for _, arc in entries]
    assert "bundle/project/src/real.py" in arcs
    # Rogue path was skipped — no arcname mentions it.
    assert not any("rogue" in a for a in arcs)


# ---------------------------------------------------------------------------
# _resolve_python_rel — branch + windows + fallback
# ---------------------------------------------------------------------------
class TestResolvePythonRel:
    def test_picks_secondary_posix_candidate(self, tmp_path: Path) -> None:
        """First candidate missing → loops to next (covers branch 578->577)."""
        py_root = tmp_path / "pyroot"
        bin_dir = py_root / "bin"
        bin_dir.mkdir(parents=True)
        # Skip ``python3``; provide ``python3.13`` instead.
        (bin_dir / "python3.13").write_bytes(b"\x7fELF")
        rel = tarball_mod._resolve_python_rel(py_root)
        assert rel == "python/bin/python3.13"

    def test_windows_layout(self, tmp_path: Path) -> None:
        """Windows tree (no ``bin/``) returns ``python.exe`` (lines 580-582)."""
        py_root = tmp_path / "pyroot"
        py_root.mkdir()
        (py_root / "python.exe").write_bytes(b"MZ")
        rel = tarball_mod._resolve_python_rel(py_root)
        assert rel == "python/python.exe"

    def test_fallback_when_nothing_present(self, tmp_path: Path) -> None:
        """Empty tree returns the conventional placeholder (line 585)."""
        py_root = tmp_path / "pyroot"
        py_root.mkdir()
        rel = tarball_mod._resolve_python_rel(py_root)
        assert rel == "python/bin/python3"


# ---------------------------------------------------------------------------
# build_tarball — error paths in the write phase
# ---------------------------------------------------------------------------
def test_build_tarball_unlink_existing_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """OSError unlinking a stale tarball surfaces as TarballBuildError (489-490)."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"
    out.mkdir()
    stale = out / "myproj-linux-x86_64-0.1.0.tar.xz"
    stale.write_bytes(b"stale")

    real_unlink = Path.unlink

    def boom(self: Path, *args: object, **kwargs: object) -> None:
        if self == stale.resolve():
            raise OSError("permission denied")
        real_unlink(self, *args, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(Path, "unlink", boom)

    with pytest.raises(TarballBuildError, match="cannot remove existing"):
        build_tarball(
            _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
        )


def test_build_tarball_write_phase_oserror(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """OSError during the tar-write loop is wrapped (lines 515-519)."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    def boom(*_a: object, **_kw: object) -> int:
        raise OSError("disk full")

    monkeypatch.setattr(tarball_mod, "_add_file", boom)

    with pytest.raises(TarballBuildError, match="failed to write tarball"):
        build_tarball(
            _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
        )


def test_build_tarball_stat_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """OSError on the post-write ``stat`` is wrapped (lines 524-525).

    Strategy: patch the module-level ``_sha256_file`` to delete the tarball
    out from under ``build_tarball`` between the write and the size stat,
    then... no — the size stat is *before* sha. Use a different angle:
    patch ``Path.stat`` to fail only when the file is non-empty (meaning
    it was just produced) and only on the canonical tarball name.
    """
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    real_stat = Path.stat
    target_name = "myproj-linux-x86_64-0.1.0.tar.xz"

    def fake_stat(self: Path, *args: object, **kwargs: object):  # type: ignore[no-untyped-def]
        # Always run the real stat first to learn the truth.
        try:
            result = real_stat(self, *args, **kwargs)
        except OSError:
            raise
        # If this is the produced tarball and it's already on disk with
        # non-zero size, the call must be the post-write size stat.
        if self.name == target_name and result.st_size > 0:
            raise OSError("vanished")
        return result

    monkeypatch.setattr(Path, "stat", fake_stat)

    with pytest.raises(TarballBuildError, match="cannot stat produced"):
        build_tarball(
            _base_opts(output_dir=out, project_root=project, wheels_dir=wheels)
        )


# ---------------------------------------------------------------------------
# zstd compression — exercises _open_tarfile + _ZstdSink end-to-end
# ---------------------------------------------------------------------------
def test_build_tarball_zstd_roundtrip(tmp_path: Path) -> None:
    """Build with zstd, then verify the archive opens + contains expected files.

    Requires ``zstandard`` to be installed (declared in dev extras).
    """
    pytest.importorskip("zstandard")
    import zstandard

    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    result = build_tarball(
        _base_opts(
            output_dir=out,
            project_root=project,
            wheels_dir=wheels,
            compression=Compression.zstd,
        )
    )
    assert result.tarball_path.name.endswith(".tar.zst")
    assert result.tarball_path.stat().st_size > 0

    # Decompress and inspect the archive.
    dctx = zstandard.ZstdDecompressor()
    with (
        result.tarball_path.open("rb") as fh,
        dctx.stream_reader(fh) as reader,
        tarfile.open(fileobj=reader, mode="r|") as tar,
    ):
        names = [m.name for m in tar]
    assert any(n.endswith("/project/src/foo.py") for n in names)


def test_build_tarball_zstd_missing_zstandard(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When ``zstandard`` is absent, zstd build raises a helpful error (368-371)."""
    project = tmp_path / "proj"
    _make_project_tree(project)
    wheels = _make_wheels_dir(tmp_path)
    out = tmp_path / "out"

    import builtins

    real_import = builtins.__import__

    def fake_import(name: str, *a: object, **kw: object):  # type: ignore[no-untyped-def]
        if name == "zstandard":
            raise ImportError("no zstandard")
        return real_import(name, *a, **kw)

    monkeypatch.setattr(builtins, "__import__", fake_import)

    with pytest.raises(TarballBuildError, match="zstandard not installed"):
        build_tarball(
            _base_opts(
                output_dir=out,
                project_root=project,
                wheels_dir=wheels,
                compression=Compression.zstd,
            )
        )


# ---------------------------------------------------------------------------
# _ZstdSink — direct unit tests
# ---------------------------------------------------------------------------
class TestZstdSink:
    def test_writable(self) -> None:
        pytest.importorskip("zstandard")

        class FakeCompressor:
            def write(self, data: bytes) -> int:
                return len(data)

            def close(self) -> None:
                pass

        class FakeUnderlying:
            closed = False

            def close(self) -> None:
                self.closed = True

        sink = tarball_mod._ZstdSink(FakeCompressor(), FakeUnderlying())
        assert sink.writable() is True
        sink.close()

    def test_write_returns_compressor_value(self) -> None:
        pytest.importorskip("zstandard")
        written: list[bytes] = []

        class FakeCompressor:
            def write(self, data: bytes) -> int:
                written.append(data)
                return 7  # arbitrary non-None value

            def close(self) -> None:
                pass

        class FakeUnderlying:
            def close(self) -> None:
                pass

        sink = tarball_mod._ZstdSink(FakeCompressor(), FakeUnderlying())
        assert sink.write(b"hello") == 7
        assert written == [b"hello"]

    def test_write_falls_back_to_len_when_none(self) -> None:
        pytest.importorskip("zstandard")

        class FakeCompressor:
            def write(self, data: bytes) -> None:  # returns None
                return None

            def close(self) -> None:
                pass

        class FakeUnderlying:
            def close(self) -> None:
                pass

        sink = tarball_mod._ZstdSink(FakeCompressor(), FakeUnderlying())
        assert sink.write(b"abcd") == 4

    def test_close_idempotent(self) -> None:
        pytest.importorskip("zstandard")
        compressor_closed = []
        underlying_closed = []

        class FakeCompressor:
            def write(self, data: bytes) -> int:
                return len(data)

            def close(self) -> None:
                compressor_closed.append(True)

        class FakeUnderlying:
            def close(self) -> None:
                underlying_closed.append(True)

        sink = tarball_mod._ZstdSink(FakeCompressor(), FakeUnderlying())
        sink.close()
        sink.close()  # second call is a no-op
        assert len(compressor_closed) == 1
        assert len(underlying_closed) == 1

"""Security hardening tests — scheme allowlist + redirect handler + TOCTOU.

These tests pin the V0.1.1 security parches:

* #8  ``file://`` / ``ftp://`` / relative URLs are rejected up-front.
* #12 Cross-host and cross-scheme redirects are refused.
* #6  The bundle SHA-256 is verified AFTER the atomic rename into the
      final directory, not on the staging ``.part`` file.
* DoS Size caps on manifest GETs (_MAX_MANIFEST_BYTES) and streaming
      downloads (manifest.compressed_size_bytes x tolerance).
* Manifest path validation rejects ``../`` traversal + UNC prefixes.
* HTTP server realpaths the served path and refuses symlink escapes.
"""
from __future__ import annotations

import hashlib
import json
import os
import socket
import urllib.error
import urllib.request
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
from pydantic import ValidationError

from rove import targets as targets_module
from rove.distribution import http_fetcher as http_fetcher_module
from rove.distribution.http_fetcher import (
    FetchOptions,
    fetch_bundle,
)
from rove.distribution.http_server import HttpServerOptions, RoveHttpServer
from rove.distribution.plugin import DistributionError
from rove.manifest import WheelhouseManifest
from rove.signing.ed25519 import sign_manifest
from rove.targets import Target


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        port: int = sock.getsockname()[1]
    return port


# ---------------------------------------------------------------------------
# #8 Scheme allowlist
# ---------------------------------------------------------------------------
def test_http_get_bytes_rejects_file_scheme() -> None:
    with pytest.raises(DistributionError, match="only http"):
        http_fetcher_module._http_get_bytes(
            "file:///etc/passwd", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_get_bytes_rejects_ftp_scheme() -> None:
    with pytest.raises(DistributionError, match="only http"):
        http_fetcher_module._http_get_bytes(
            "ftp://example/p", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_get_bytes_rejects_relative_url() -> None:
    with pytest.raises(DistributionError, match="only http"):
        http_fetcher_module._http_get_bytes(
            "/local/path", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_get_bytes_rejects_missing_host() -> None:
    with pytest.raises(DistributionError, match="no host component"):
        http_fetcher_module._http_get_bytes(
            "http:///no-host", connect_timeout=1.0, read_timeout=1.0
        )


def test_http_download_streaming_rejects_file_scheme(tmp_path: Path) -> None:
    with pytest.raises(DistributionError, match="only http"):
        http_fetcher_module._http_download_streaming(
            "file:///etc/hosts",
            tmp_path / "out",
            chunk_size=64,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
        )


# ---------------------------------------------------------------------------
# #12 StrictRedirectHandler
# ---------------------------------------------------------------------------
def test_redirect_handler_rejects_cross_host() -> None:
    handler = http_fetcher_module._StrictRedirectHandler()
    req = urllib.request.Request("http://good.example/bundle")
    with pytest.raises(urllib.error.HTTPError, match="changes host"):
        handler.redirect_request(
            req, None, 302, "Found", {}, "http://attacker.example/bundle"
        )


def test_redirect_handler_rejects_scheme_downgrade() -> None:
    handler = http_fetcher_module._StrictRedirectHandler()
    req = urllib.request.Request("https://good.example/bundle")
    with pytest.raises(urllib.error.HTTPError, match="changes scheme"):
        handler.redirect_request(
            req, None, 302, "Found", {}, "http://good.example/bundle"
        )


def test_redirect_handler_rejects_unsupported_scheme() -> None:
    handler = http_fetcher_module._StrictRedirectHandler()
    req = urllib.request.Request("http://good.example/bundle")
    with pytest.raises(urllib.error.HTTPError, match="unsupported scheme"):
        handler.redirect_request(
            req, None, 302, "Found", {}, "file:///etc/passwd"
        )


def test_redirect_handler_allows_same_host_canonicalisation() -> None:
    """Same-host + same-scheme → scheme/host check is NOT the blocking reason."""
    handler = http_fetcher_module._StrictRedirectHandler()
    req = urllib.request.Request("http://good.example/bundle")
    # The stdlib super().redirect_request may enforce method rules, but
    # scheme+host must not be the gating factor here.
    try:
        handler.redirect_request(
            req, None, 301, "Moved", {}, "http://good.example/bundle/"
        )
    except urllib.error.HTTPError as exc:
        assert "changes host" not in str(exc)
        assert "changes scheme" not in str(exc)


def test_get_safe_opener_memoised() -> None:
    """Subsequent ``_get_safe_opener()`` calls return the same instance."""
    http_fetcher_module._SAFE_OPENER = None
    a = http_fetcher_module._get_safe_opener()
    b = http_fetcher_module._get_safe_opener()
    assert a is b


# ---------------------------------------------------------------------------
# #6 TOCTOU: sha is hashed AFTER atomic rename
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_fetch_bundle_no_leftover_holding_file_on_success(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """Clean success leaves no ``.incoming`` or ``.part`` files behind."""
    priv, pub = ephemeral_keypair_files
    served = tmp_path / "served"
    served.mkdir()
    payload = b"deterministic bundle payload" * 4
    name = "toctou-linux-x86_64-0.1.0.tar.xz"
    (served / name).write_bytes(payload)
    sha = hashlib.sha256(payload).hexdigest()

    manifest = synthetic_manifest_factory(
        project_name="toctou",
        runtime_version="0.1.0",
        target=Target.linux_x86_64,
        tarball_name=name,
        tarball_sha256=sha,
        compressed_size_bytes=len(payload),
        uncompressed_size_bytes=len(payload),
    )
    signed = sign_manifest(manifest, priv)
    (served / (name + ".manifest.json")).write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    out = tmp_path / "dl"
    with RoveHttpServer(
        HttpServerOptions(bundle_dir=served, host="127.0.0.1", port=_free_port())
    ) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=name,
                output_dir=out,
                additional_pubkeys=[pub],
            )
        )

    assert result.bundle_path.read_bytes() == payload
    assert list(out.glob("*.incoming")) == []
    assert list(out.glob("*.part")) == []


@pytest.mark.timeout(20)
def test_fetch_bundle_cleans_stale_holding_file_before_rename(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """A stale ``.incoming`` from a prior aborted download is overwritten."""
    priv, pub = ephemeral_keypair_files
    served = tmp_path / "served"
    served.mkdir()
    payload = b"real payload" * 8
    name = "stale-linux-x86_64-0.1.0.tar.xz"
    (served / name).write_bytes(payload)
    sha = hashlib.sha256(payload).hexdigest()

    manifest = synthetic_manifest_factory(
        project_name="stale",
        runtime_version="0.1.0",
        target=Target.linux_x86_64,
        tarball_name=name,
        tarball_sha256=sha,
        compressed_size_bytes=len(payload),
        uncompressed_size_bytes=len(payload),
    )
    signed = sign_manifest(manifest, priv)
    (served / (name + ".manifest.json")).write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    out = tmp_path / "dl"
    out.mkdir()
    stale_holding = out / (name + http_fetcher_module._HOLDING_SUFFIX)
    stale_holding.write_bytes(b"stale bytes from prior aborted fetch")

    with RoveHttpServer(
        HttpServerOptions(bundle_dir=served, host="127.0.0.1", port=_free_port())
    ) as server:
        result = fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=name,
                output_dir=out,
                additional_pubkeys=[pub],
            )
        )

    assert result.bundle_path.read_bytes() == payload
    assert not stale_holding.exists()


@pytest.mark.timeout(20)
def test_fetch_bundle_sha_mismatch_cleans_up_holding(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
) -> None:
    """A lying manifest triggers SHA mismatch; the holding file is removed."""
    priv, pub = ephemeral_keypair_files
    served = tmp_path / "served"
    served.mkdir()
    payload = b"real payload"
    name = "mismatch-linux-x86_64-0.1.0.tar.xz"
    (served / name).write_bytes(payload)

    manifest = synthetic_manifest_factory(
        project_name="mismatch",
        runtime_version="0.1.0",
        target=Target.linux_x86_64,
        tarball_name=name,
        tarball_sha256="f" * 64,  # wrong
        compressed_size_bytes=len(payload),
        uncompressed_size_bytes=len(payload),
    )
    signed = sign_manifest(manifest, priv)
    (served / (name + ".manifest.json")).write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    out = tmp_path / "dl"
    with (
        RoveHttpServer(
            HttpServerOptions(bundle_dir=served, host="127.0.0.1", port=_free_port())
        ) as server,
        pytest.raises(DistributionError, match="SHA-256 mismatch"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=name,
                output_dir=out,
                additional_pubkeys=[pub],
                max_retries=0,
            )
        )

    assert not (out / name).exists()
    assert not (out / (name + http_fetcher_module._HOLDING_SUFFIX)).exists()


# ---------------------------------------------------------------------------
# DoS: size caps on manifest GET + streaming download
# ---------------------------------------------------------------------------
class _StubOpener:
    """OpenerDirector stand-in used to inject oversized responses."""

    def __init__(self, behaviour: Callable[..., Any]) -> None:
        self._behaviour = behaviour

    def open(self, req: Any, timeout: float) -> Any:
        return self._behaviour(req, timeout=timeout)


class _FakeResp:
    def __init__(
        self, *, status: int, body: bytes, content_length: int | None = None
    ) -> None:
        self._status = status
        self._body = memoryview(body)
        self._pos = 0
        self.headers = {"Content-Length": str(content_length)} if content_length is not None else {}

    def __enter__(self) -> _FakeResp:
        return self

    def __exit__(self, *exc: object) -> None:
        return None

    def getcode(self) -> int:
        return self._status

    def read(self, n: int = -1) -> bytes:
        if n < 0 or n > len(self._body) - self._pos:
            out = bytes(self._body[self._pos :])
            self._pos = len(self._body)
            return out
        out = bytes(self._body[self._pos : self._pos + n])
        self._pos += n
        return out


def test_http_get_bytes_refuses_oversized_content_length(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A manifest advertising 100 MB Content-Length is rejected without reading."""
    big = 100 * 1024 * 1024

    def _open(_req: Any, timeout: float) -> Any:
        return _FakeResp(status=200, body=b"", content_length=big)

    monkeypatch.setattr(
        http_fetcher_module, "_get_safe_opener", lambda: _StubOpener(_open)
    )
    with pytest.raises(DistributionError, match="exceeds cap"):
        http_fetcher_module._http_get_bytes(
            "http://evil/manifest.json",
            connect_timeout=1.0,
            read_timeout=1.0,
            max_bytes=1024,
        )


def test_http_get_bytes_refuses_body_past_cap_without_content_length(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Peer lies / omits Content-Length; we still stop reading past the cap."""
    body = b"A" * (8 * 1024)

    def _open(_req: Any, timeout: float) -> Any:
        return _FakeResp(status=200, body=body)  # no Content-Length

    monkeypatch.setattr(
        http_fetcher_module, "_get_safe_opener", lambda: _StubOpener(_open)
    )
    with pytest.raises(DistributionError, match="exceeded"):
        http_fetcher_module._http_get_bytes(
            "http://evil/manifest.json",
            connect_timeout=1.0,
            read_timeout=1.0,
            max_bytes=1024,
        )


def test_http_get_bytes_ignores_garbage_content_length(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-integer Content-Length is ignored; fall through to body cap."""
    body = b"{}"

    class _WeirdResp(_FakeResp):
        def __init__(self) -> None:
            super().__init__(status=200, body=body)
            self.headers = {"Content-Length": "not-a-number"}

    def _open(_req: Any, timeout: float) -> Any:
        return _WeirdResp()

    monkeypatch.setattr(
        http_fetcher_module, "_get_safe_opener", lambda: _StubOpener(_open)
    )
    data = http_fetcher_module._http_get_bytes(
        "http://peer/manifest.json",
        connect_timeout=1.0,
        read_timeout=1.0,
        max_bytes=1024,
    )
    assert data == body


def test_http_download_streaming_refuses_oversized_payload(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Peer streams more bytes than manifest.compressed_size_bytes allows."""
    # advertised = 16, actual = 256 → cap trips after the first chunk
    actual = b"Z" * 256

    def _open(_req: Any, timeout: float) -> Any:
        return _FakeResp(status=200, body=actual)

    monkeypatch.setattr(
        http_fetcher_module, "_get_safe_opener", lambda: _StubOpener(_open)
    )
    dest = tmp_path / "b.tar.xz.part"
    with pytest.raises(DistributionError, match="disk-fill"):
        http_fetcher_module._http_download_streaming(
            "http://peer/b.tar.xz",
            dest,
            chunk_size=64,
            connect_timeout=1.0,
            read_timeout=1.0,
            resume_from=0,
            max_total_bytes=16,
        )


# ---------------------------------------------------------------------------
# Manifest path validation: reject ../ traversal + UNC + drive + absolute
# ---------------------------------------------------------------------------
def _base_manifest_kwargs() -> dict[str, Any]:
    return dict(
        project_name="myapp",
        runtime_version="0.1.0",
        target=Target.linux_x86_64,
        tarball_name="myapp-linux-x86_64-0.1.0.tar.xz",
        tarball_sha256="a" * 64,
        compressed_size_bytes=1,
        uncompressed_size_bytes=1,
        python_rel_path="python/bin/python3",
        project_root_rel_path="project",
        signature="b" * 128,
    )


def test_manifest_rejects_parent_traversal_in_python_rel_path() -> None:
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "../../etc/passwd"
    with pytest.raises(ValidationError, match=r"must not contain"):
        WheelhouseManifest(**kw)


def test_manifest_rejects_parent_traversal_with_backslash_sep() -> None:
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "bin\\..\\..\\etc\\passwd"
    with pytest.raises(ValidationError, match=r"must not contain"):
        WheelhouseManifest(**kw)


def test_manifest_rejects_unc_prefix() -> None:
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "\\\\server\\share\\python3"
    with pytest.raises(ValidationError, match="UNC"):
        WheelhouseManifest(**kw)


def test_manifest_rejects_posix_absolute_unc_alias() -> None:
    """``//server/share/...`` on POSIX behaves like a UNC alias on some runtimes."""
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "//server/share/python3"
    with pytest.raises(ValidationError, match="UNC"):
        WheelhouseManifest(**kw)


def test_manifest_rejects_windows_drive_absolute() -> None:
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "C:/evil/python3"
    with pytest.raises(ValidationError, match="absolute Windows"):
        WheelhouseManifest(**kw)


def test_manifest_strips_leading_posix_slash() -> None:
    """POSIX absolute ``/x/y`` becomes relative ``x/y`` (existing behaviour)."""
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "/foo/bar"
    m = WheelhouseManifest(**kw)
    assert m.python_rel_path == "foo/bar"


def test_manifest_accepts_legitimate_relative_paths() -> None:
    kw = _base_manifest_kwargs()
    kw["python_rel_path"] = "python/bin/python3.13"
    kw["project_root_rel_path"] = "project/src"
    m = WheelhouseManifest(**kw)
    assert m.python_rel_path == "python/bin/python3.13"


# ---------------------------------------------------------------------------
# targets.detect_host: Windows ARM64 handling
# ---------------------------------------------------------------------------
def test_detect_host_raises_on_windows_arm64(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(targets_module.platform, "system", lambda: "Windows")
    monkeypatch.setattr(targets_module.platform, "machine", lambda: "ARM64")
    with pytest.raises(RuntimeError, match="Windows ARM64"):
        targets_module.detect_host()


# ---------------------------------------------------------------------------
# HTTP server symlink escape rejection
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# signing_payload: runtime_version must not contain the '|' separator
# ---------------------------------------------------------------------------
def test_manifest_runtime_version_rejects_pipe_separator() -> None:
    kw = _base_manifest_kwargs()
    kw["runtime_version"] = "1.0|android-arm64|99"
    with pytest.raises(ValidationError):
        WheelhouseManifest(**kw)


def test_manifest_runtime_version_accepts_semver_forms() -> None:
    for version in ("1.2.3", "1.0.0-rc.1", "1.0.0+build.42", "2026.04.17"):
        kw = _base_manifest_kwargs()
        kw["runtime_version"] = version
        m = WheelhouseManifest(**kw)
        assert m.runtime_version == version


# ---------------------------------------------------------------------------
# sha256_file OSError wrapping in fetch_bundle
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_fetch_bundle_cache_hash_os_error_wrapped(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
    clean_trusted_env: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """An OSError from ``sha256_file`` on the local cache surfaces as DistributionError."""
    priv, pub = ephemeral_keypair_files
    served = tmp_path / "served"
    served.mkdir()
    payload = b"abc"
    name = "osfail-linux-x86_64-0.1.0.tar.xz"
    (served / name).write_bytes(payload)
    sha = hashlib.sha256(payload).hexdigest()

    manifest = synthetic_manifest_factory(
        project_name="osfail",
        runtime_version="0.1.0",
        target=Target.linux_x86_64,
        tarball_name=name,
        tarball_sha256=sha,
        compressed_size_bytes=len(payload),
        uncompressed_size_bytes=len(payload),
    )
    signed = sign_manifest(manifest, priv)
    (served / (name + ".manifest.json")).write_text(
        json.dumps(signed.model_dump(mode="json"), indent=2, sort_keys=True),
        encoding="utf-8",
    )

    out = tmp_path / "dl"
    out.mkdir()
    # Pre-populate a local cache file so the hash branch runs.
    (out / name).write_bytes(payload)

    def _boom(_path: Path) -> str:
        raise OSError("simulated filesystem error")

    monkeypatch.setattr(http_fetcher_module, "sha256_file", _boom)

    opts = HttpServerOptions(
        bundle_dir=served, host="127.0.0.1", port=_free_port()
    )
    with (
        RoveHttpServer(opts) as server,
        pytest.raises(DistributionError, match="cannot hash local cache"),
    ):
        fetch_bundle(
            FetchOptions(
                source=server.url(),
                bundle_name=name,
                output_dir=out,
                additional_pubkeys=[pub],
            )
        )


# ---------------------------------------------------------------------------
# _get_safe_opener thread-safety under concurrent first-calls
# ---------------------------------------------------------------------------
def test_get_safe_opener_is_thread_safe() -> None:
    """Two threads racing the first call must produce exactly one opener."""
    import threading

    http_fetcher_module._SAFE_OPENER = None
    results: list[Any] = []
    barrier = threading.Barrier(16)

    def _worker() -> None:
        barrier.wait(timeout=5)
        results.append(http_fetcher_module._get_safe_opener())

    threads = [threading.Thread(target=_worker) for _ in range(16)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert len(results) == 16
    # Every thread must see the SAME opener — no "leaked extra" instance.
    assert all(o is results[0] for o in results)


# ---------------------------------------------------------------------------
# StrictRedirectHandler end-to-end via a real HTTP server sending 302
# ---------------------------------------------------------------------------
@pytest.mark.timeout(20)
def test_fetch_bundle_rejects_cross_host_redirect_live() -> None:
    """Integration: live HTTP server returns 302 off-host → DistributionError.

    This closes the audit gap that the handler was unit-tested in
    isolation but not wired end-to-end through ``_http_get_bytes``.
    """
    import http.server
    import threading

    from rove.distribution.http_server import NoFQDNThreadingHTTPServer

    class _RedirHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            self.send_response(302)
            self.send_header("Location", "http://attacker.example.invalid/stolen.json")
            self.end_headers()

        def log_message(self, *a: Any, **k: Any) -> None:
            return  # silence

    port = _free_port()
    # Use the no-FQDN subclass: macOS GHA runners hang on
    # ``socket.getfqdn('127.0.0.1')`` during ``server_bind``.
    httpd = NoFQDNThreadingHTTPServer(("127.0.0.1", port), _RedirHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    # Reset memoised opener so a prior test's opener doesn't mask the wiring.
    http_fetcher_module._SAFE_OPENER = None
    try:
        with pytest.raises(DistributionError, match=r"changes host|unreachable"):
            http_fetcher_module._http_get_bytes(
                f"http://127.0.0.1:{port}/manifest.json",
                connect_timeout=2.0,
                read_timeout=2.0,
            )
    finally:
        httpd.shutdown()
        httpd.server_close()
        t.join(timeout=2)


# ---------------------------------------------------------------------------
# keygen: Windows ACL best-effort
# ---------------------------------------------------------------------------
@pytest.mark.skipif(os.name != "nt", reason="Windows-specific ACL test")
def test_generate_keypair_windows_tightens_acl(tmp_path: Path) -> None:
    """On Windows, ``generate_keypair`` invokes icacls on private.pem.

    We don't assert the final ACL state (that depends on SIDs, domain
    membership, etc.) — only that the call path runs to completion and
    produces the expected files.
    """
    from rove.signing.keygen import generate_keypair

    priv, pub = generate_keypair(tmp_path / "keys")
    assert priv.exists()
    assert pub.exists()


@pytest.mark.skipif(os.name != "nt", reason="Windows-specific ACL test")
def test_generate_keypair_windows_icacls_missing_logs_warning(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    """If icacls is not on PATH, keygen still succeeds but warns."""
    from rove.signing import keygen as keygen_mod

    monkeypatch.setattr(keygen_mod, "_resolve_icacls", lambda: None)
    with caplog.at_level("WARNING", logger="rove.signing.keygen"):
        priv, _ = keygen_mod.generate_keypair(tmp_path / "keys")
    assert priv.exists()
    assert any("icacls not found" in r.getMessage() for r in caplog.records)


@pytest.mark.skipif(os.name != "nt", reason="Windows-specific ACL test")
def test_generate_keypair_windows_icacls_failure_logs_warning(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    """If icacls exits non-zero, keygen still succeeds but warns."""
    import subprocess as _sp

    from rove.signing import keygen as keygen_mod

    def _fake_run(argv: list[str], **kwargs: Any) -> _sp.CompletedProcess[str]:
        return _sp.CompletedProcess(argv, returncode=1, stdout="", stderr="access denied")

    monkeypatch.setattr(keygen_mod.subprocess, "run", _fake_run)
    with caplog.at_level("WARNING", logger="rove.signing.keygen"):
        priv, _ = keygen_mod.generate_keypair(tmp_path / "keys")
    assert priv.exists()
    assert any("icacls" in r.getMessage() for r in caplog.records)


@pytest.mark.skipif(os.name != "nt", reason="Windows-specific ACL test")
def test_generate_keypair_windows_missing_username_logs_warning(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    """If USERNAME/USER env are both unset, keygen warns + proceeds."""
    from rove.signing import keygen as keygen_mod

    monkeypatch.delenv("USERNAME", raising=False)
    monkeypatch.delenv("USER", raising=False)
    with caplog.at_level("WARNING", logger="rove.signing.keygen"):
        priv, _ = keygen_mod.generate_keypair(tmp_path / "keys")
    assert priv.exists()
    assert any("username" in r.getMessage() for r in caplog.records)


@pytest.mark.timeout(20)
def test_http_server_refuses_realpath_escape_mocked(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Cross-platform: monkeypatch ``os.path.realpath`` to force an escape.

    Simulates a symlink by having ``realpath(local_path)`` return a path
    outside ``server_directory``. The server must reply 404 regardless of
    the underlying filesystem — the check is a prefix comparison, not an
    OS feature.
    """
    bundle_dir = tmp_path / "served"
    bundle_dir.mkdir()
    # Legitimate bundle so start() succeeds.
    (bundle_dir / "legit-linux-x86_64-0.1.0.tar.xz").write_bytes(b"ok")
    (bundle_dir / "legit-linux-x86_64-0.1.0.tar.xz.manifest.json").write_text("{}")

    outside = tmp_path / "outside-the-tree"
    outside.write_text("secret")

    import os as _os
    real_realpath = _os.path.realpath

    def _escaping_realpath(p: Any, *args: Any, **kwargs: Any) -> str:
        """Return a path outside the server dir whenever the request targets evil.tar.xz."""
        s = str(p)
        if s.endswith("evil.tar.xz"):
            return str(outside)
        return real_realpath(p, *args, **kwargs)

    monkeypatch.setattr(
        "rove.distribution.http_server.os.path.realpath", _escaping_realpath
    )

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        req = urllib.request.Request(
            f"{server.url()}/evil.tar.xz", headers={"Range": "bytes=0-"}
        )
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req, timeout=5)
        assert exc_info.value.code == 404


@pytest.mark.skipif(os.name == "nt", reason="symlinks require admin on Windows")
@pytest.mark.timeout(20)
def test_http_server_refuses_symlink_escape(
    tmp_path: Path,
    synthetic_manifest_factory: Callable[..., WheelhouseManifest],
    ephemeral_keypair_files: tuple[Path, Path],
) -> None:
    """A symlink inside bundle_dir pointing outside MUST not be served."""
    _priv, _ = ephemeral_keypair_files
    bundle_dir = tmp_path / "bundles"
    bundle_dir.mkdir()
    secret = tmp_path / "secret.txt"
    secret.write_text("sensitive content outside the served tree")
    link = bundle_dir / "evil.tar.xz"
    link.symlink_to(secret)
    # We still need at least one legitimate tarball so the server starts.
    real_bundle = bundle_dir / "legit-linux-x86_64-0.1.0.tar.xz"
    real_bundle.write_bytes(b"real bundle")

    opts = HttpServerOptions(
        bundle_dir=bundle_dir, host="127.0.0.1", port=_free_port()
    )
    with RoveHttpServer(opts) as server:
        # Range request against the symlink's path — should 404, not leak.
        req = urllib.request.Request(
            f"{server.url()}/evil.tar.xz", headers={"Range": "bytes=0-"}
        )
        with pytest.raises(urllib.error.HTTPError) as exc_info:
            urllib.request.urlopen(req, timeout=5)
        assert exc_info.value.code == 404

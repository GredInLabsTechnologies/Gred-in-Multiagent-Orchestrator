"""Tests for rove.config — pyproject + rove.toml loader."""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from rove.config import ConfigError, RoveConfig, load
from rove.targets import Target


def _write(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def test_load_pyproject_with_tool_rove(tmp_path: Path) -> None:
    cfg = _write(
        tmp_path / "pyproject.toml",
        """
[project]
name = "demo-app"
version = "1.2.3"

[tool.rove]
project_name = "demo-app"
targets = ["linux-x86_64"]
""",
    )
    result = load(cfg)
    assert isinstance(result, RoveConfig)
    assert result.project_name == "demo-app"
    assert result.version == "1.2.3"
    assert result.targets == [Target.linux_x86_64]


def test_load_standalone_rove_toml(tmp_path: Path) -> None:
    cfg = _write(
        tmp_path / "rove.toml",
        """
project_name = "standalone-app"
version = "0.1.0"
include = ["app", "extra"]
""",
    )
    result = load(cfg)
    assert result.project_name == "standalone-app"
    assert result.include == ["app", "extra"]


def test_tool_rove_overrides_project_name(tmp_path: Path) -> None:
    cfg = _write(
        tmp_path / "pyproject.toml",
        """
[project]
name = "pyproject-name"

[tool.rove]
project_name = "rove-name"
""",
    )
    result = load(cfg)
    assert result.project_name == "rove-name"


def test_project_dependencies_become_requirements(tmp_path: Path) -> None:
    cfg = _write(
        tmp_path / "pyproject.toml",
        """
[project]
name = "deps-app"
dependencies = ["psutil>=6.0", "httpx==0.27.0"]

[tool.rove]
project_name = "deps-app"
""",
    )
    result = load(cfg)
    assert result.requirements == ["psutil>=6.0", "httpx==0.27.0"]


def test_tool_rove_requirements_override_project_dependencies(tmp_path: Path) -> None:
    cfg = _write(
        tmp_path / "pyproject.toml",
        """
[project]
name = "ovr-app"
dependencies = ["old==1.0"]

[tool.rove]
project_name = "ovr-app"
requirements = ["new==2.0", "extra==3.0"]
""",
    )
    result = load(cfg)
    assert result.requirements == ["new==2.0", "extra==3.0"]


def test_search_upward_finds_parent_pyproject(tmp_path: Path) -> None:
    _write(
        tmp_path / "pyproject.toml",
        """
[tool.rove]
project_name = "parent-app"
""",
    )
    nested = tmp_path / "deep" / "nested" / "dir"
    nested.mkdir(parents=True)
    result = load(project_root=nested)
    assert result.project_name == "parent-app"


def test_search_upward_prefers_rove_toml_over_pyproject(tmp_path: Path) -> None:
    _write(
        tmp_path / "pyproject.toml",
        """
[tool.rove]
project_name = "from-pyproject"
""",
    )
    _write(
        tmp_path / "rove.toml",
        """
project_name = "from-rove-toml"
""",
    )
    result = load(project_root=tmp_path)
    assert result.project_name == "from-rove-toml"


def test_env_var_expansion_in_sign_key(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("ROVE_TEST_KEY", "/secret/key.pem")
    cfg = _write(
        tmp_path / "rove.toml",
        """
project_name = "env-app"
sign_key = "${ROVE_TEST_KEY}"
""",
    )
    result = load(cfg)
    assert result.sign_key == "/secret/key.pem"


def test_env_var_expansion_unset_raises(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.delenv("ROVE_TEST_MISSING", raising=False)
    cfg = _write(
        tmp_path / "rove.toml",
        """
project_name = "env-app"
sign_key = "${ROVE_TEST_MISSING}"
""",
    )
    with pytest.raises(ConfigError, match="ROVE_TEST_MISSING"):
        load(cfg)


def test_env_var_expansion_with_path_suffix(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("HOME", "/home/test")
    cfg = _write(
        tmp_path / "rove.toml",
        """
project_name = "home-app"
sign_key = "${HOME}/keys/private.pem"
""",
    )
    result = load(cfg)
    assert result.sign_key == "/home/test/keys/private.pem"


def test_missing_config_file_raises_filenotfound(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load(tmp_path / "nonexistent.toml")


def test_search_upward_no_match_raises_filenotfound(tmp_path: Path) -> None:
    isolated = tmp_path / "no_config_anywhere_unique_xyz_12345"
    isolated.mkdir()
    with pytest.raises(FileNotFoundError):
        load(project_root=isolated)


@pytest.mark.parametrize(
    "bad_name",
    ["UPPERCASE", "-leadinghyphen", "has spaces", "weird!chars"],
)
def test_invalid_project_name_raises(tmp_path: Path, bad_name: str) -> None:
    cfg = _write(
        tmp_path / "rove.toml",
        f'project_name = "{bad_name}"\n',
    )
    with pytest.raises((ValidationError, ConfigError)):
        load(cfg)


def test_default_targets_is_host(tmp_path: Path) -> None:
    cfg = _write(tmp_path / "rove.toml", 'project_name = "minimal"\n')
    result = load(cfg)
    assert result.targets == [Target.host]


def test_default_exclude_non_empty(tmp_path: Path) -> None:
    cfg = _write(tmp_path / "rove.toml", 'project_name = "minimal"\n')
    result = load(cfg)
    assert len(result.exclude) > 0
    assert all(isinstance(s, str) for s in result.exclude)


def test_round_trip_json_serialization() -> None:
    cfg = RoveConfig(
        project_name="roundtrip",
        version="9.9.9",
        include=["src", "lib"],
        targets=[Target.linux_x86_64, Target.darwin_arm64],
    )
    serialized = cfg.model_dump_json()
    parsed = json.loads(serialized)
    rebuilt = RoveConfig.model_validate(parsed)
    assert rebuilt.project_name == cfg.project_name
    assert rebuilt.version == cfg.version
    assert rebuilt.targets == cfg.targets


# ---------------------------------------------------------------------------
# Coverage-completion tests for `_coerce_targets`, error paths, and merge logic
# ---------------------------------------------------------------------------


class TestCoerceTargetsValidator:
    """Direct exercise of the ``_coerce_targets`` field validator."""

    def test_none_passes_through_validator(self) -> None:
        """None input returns None from the validator (covers `return v`)."""
        # The validator returns None unchanged; Pydantic then rejects it
        # because ``targets`` is typed as list[Target]. The line we care
        # about is the validator's early `return v` for None.
        with pytest.raises(ValidationError):
            RoveConfig.model_validate(
                {"project_name": "nonecase", "targets": None}
            )

    def test_non_list_targets_raises(self) -> None:
        with pytest.raises(ValidationError, match="targets must be a list"):
            RoveConfig.model_validate(
                {"project_name": "scalar", "targets": "linux-x86_64"}
            )

    def test_non_str_non_target_entry_raises(self) -> None:
        with pytest.raises(ValidationError, match="must be str or Target"):
            RoveConfig.model_validate(
                {"project_name": "weird", "targets": [123]}
            )

    def test_target_enum_member_passes_through(self) -> None:
        cfg = RoveConfig(project_name="enum", targets=[Target.linux_arm64])
        assert cfg.targets == [Target.linux_arm64]


class TestReadTomlErrors:
    def test_unreadable_toml_raises_configerror(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Open failure on the toml file → covers OSError branch (lines 123-124)."""
        cfg = _write(
            tmp_path / "rove.toml", 'project_name = "x"\n'
        )

        # Patch Path.open so reading the toml raises OSError.
        original_open = Path.open

        def raising_open(self: Path, *a: object, **kw: object) -> object:
            if self == cfg:
                raise OSError("simulated read failure")
            return original_open(self, *a, **kw)  # type: ignore[arg-type]

        monkeypatch.setattr(Path, "open", raising_open)
        with pytest.raises(ConfigError, match="cannot read"):
            load(cfg)

    def test_invalid_toml_raises_configerror(self, tmp_path: Path) -> None:
        """Invalid TOML body → covers TOMLDecodeError branch (lines 125-126)."""
        cfg = _write(
            tmp_path / "rove.toml", "project_name = \"unterminated\nfoo = bar\n"
        )
        with pytest.raises(ConfigError, match="invalid TOML"):
            load(cfg)


class TestToolTableValidation:
    def test_tool_not_a_table_raises(self, tmp_path: Path) -> None:
        """``[tool]`` is a scalar → covers line 209."""
        cfg = _write(
            tmp_path / "pyproject.toml",
            'tool = "this-should-be-a-table"\n',
        )
        with pytest.raises(ConfigError, match=r"\[tool\]"):
            load(cfg)

    def test_tool_rove_not_a_table_raises(self, tmp_path: Path) -> None:
        """``[tool].rove`` is a scalar → covers line 212."""
        cfg = _write(
            tmp_path / "pyproject.toml",
            "[tool]\nrove = 42\n",
        )
        with pytest.raises(ConfigError, match=r"\[tool\.rove\]"):
            load(cfg)


class TestPyprojectMergeBranches:
    def test_pyproject_with_dependencies_only_no_name_or_version(
        self, tmp_path: Path
    ) -> None:
        """[project] without name/version → covers branch 221->223 (no-name)."""
        cfg = _write(
            tmp_path / "pyproject.toml",
            """
[project]
dependencies = ["foo>=1.0"]

[tool.rove]
project_name = "explicit-name"
""",
        )
        result = load(cfg)
        assert result.project_name == "explicit-name"
        # dependencies still propagated to requirements
        assert result.requirements == ["foo>=1.0"]


class TestRoveConfigConstructorErrors:
    def test_invalid_project_name_via_constructor_wraps_to_configerror(
        self, tmp_path: Path
    ) -> None:
        """A non-ConfigError exception during ``RoveConfig(**merged)`` is wrapped → covers line 239 (else branch)."""
        cfg = _write(
            tmp_path / "rove.toml",
            'project_name = "BadName"\n',
        )
        # ValidationError isn't a ConfigError → goes through generic wrapper.
        with pytest.raises(ConfigError, match="invalid Rove config"):
            load(cfg)

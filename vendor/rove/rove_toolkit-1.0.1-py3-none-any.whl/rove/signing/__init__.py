"""Signing subsystem — Ed25519 keygen, sign, verify."""

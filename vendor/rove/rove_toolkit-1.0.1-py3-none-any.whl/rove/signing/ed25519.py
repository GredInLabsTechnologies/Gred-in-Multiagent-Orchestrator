"""
Rove Wheelhouse Signing — Ed25519
==================================

Sign and verify :class:`rove.manifest.WheelhouseManifest` bundles using
Ed25519. Signatures cover the canonical bytes returned by
:meth:`WheelhouseManifest.signing_payload`
(``<sha256>|<target>|<version>|<project_name>`` encoded UTF-8), so
non-Python consumers can re-derive and verify them without depending on
a specific JSON serializer.

Trusted public key resolution (multi-key for rotation)
------------------------------------------------------
Trusted public keys are loaded, in priority order, from:

1. Env var ``ROVE_TRUSTED_PUBKEYS`` — comma-separated entries. Each entry
   may be either a full PEM block (newlines may be escaped as ``\\n``)
   or a base64 string of a 32-byte raw Ed25519 public key.
2. Files matching ``~/.config/rove/trusted_keys/*.pem`` — every PEM in
   that directory is loaded.
3. The optional ``additional_keys`` argument passed to :func:`verify`
   or :func:`verify_manifest`.

If neither (1), (2), nor (3) yield any key, :func:`verify_manifest`
raises :class:`RuntimeSignatureError`. Verification succeeds the moment
*any* trusted key validates the signature.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import logging
import os
from collections.abc import Iterable
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives.serialization import (
    load_pem_private_key,
    load_pem_public_key,
)

from rove.manifest import WheelhouseManifest

__all__ = [
    "RuntimeSignatureError",
    "sha256_file",
    "sign",
    "sign_manifest",
    "verify",
    "verify_manifest",
]

logger = logging.getLogger("rove.signing.ed25519")

#: Type alias for accepted private/public key inputs.
KeyInput = bytes | str | Path

_ENV_TRUSTED_KEYS = "ROVE_TRUSTED_PUBKEYS"
_USER_TRUSTED_DIR = Path.home() / ".config" / "rove" / "trusted_keys"


class RuntimeSignatureError(RuntimeError):
    """Raised on key load failures, malformed signatures, or missing trust.

    Verification *failure* (signature does not match) is **not** an
    exception — :func:`verify` returns ``False`` in that case. Only
    structural problems (bad PEM, non-hex signature, no trusted keys
    configured) raise.

    Inherits from :class:`RuntimeError` so that callers using a broad
    ``except RuntimeError`` to catch every Rove domain error (per
    ``docs/LIBRARY.md`` error taxonomy) do not miss signing failures.
    """


# ---------------------------------------------------------------------------
# Private key loading
# ---------------------------------------------------------------------------
def _load_private_key_pem(source: KeyInput) -> Ed25519PrivateKey:
    """Load an Ed25519 private key from PEM bytes, str, or a file path.

    Args:
        source: PEM bytes, PEM string, or :class:`pathlib.Path` to a PEM file.

    Returns:
        The decoded :class:`Ed25519PrivateKey`.

    Raises:
        RuntimeSignatureError: PEM is malformed or not an Ed25519 key.
    """
    if isinstance(source, Path):
        try:
            pem_bytes = source.read_bytes()
        except OSError as exc:
            raise RuntimeSignatureError(
                f"cannot read private key file {source}: {exc}"
            ) from exc
    elif isinstance(source, str):
        pem_bytes = source.encode("utf-8")
    elif isinstance(source, (bytes, bytearray)):
        pem_bytes = bytes(source)
    else:  # pragma: no cover - defensive type guard
        raise RuntimeSignatureError(
            f"unsupported private key input type: {type(source).__name__}"
        )

    try:
        key = load_pem_private_key(pem_bytes, password=None)
    except Exception as exc:
        raise RuntimeSignatureError(
            f"invalid Ed25519 private key PEM: {exc}"
        ) from exc

    if not isinstance(key, Ed25519PrivateKey):
        raise RuntimeSignatureError(
            "PEM does not encode an Ed25519 private key"
        )
    return key


# ---------------------------------------------------------------------------
# Public key loading & normalisation
# ---------------------------------------------------------------------------
def _normalize_pubkey_input(source: KeyInput) -> Ed25519PublicKey:
    """Decode any supported public-key representation.

    Accepts:

    * 32-byte raw Ed25519 public key (``bytes``).
    * PEM bytes / string (``-----BEGIN PUBLIC KEY-----`` block).
    * Base64 string of a 32-byte raw key.
    * :class:`pathlib.Path` pointing at a PEM file.

    Raises:
        RuntimeSignatureError: input cannot be decoded into an Ed25519 key.
    """
    if isinstance(source, Path):
        try:
            data = source.read_bytes()
        except OSError as exc:
            raise RuntimeSignatureError(
                f"cannot read public key file {source}: {exc}"
            ) from exc
        return _decode_pem_or_raw(data, origin=str(source))

    if isinstance(source, (bytes, bytearray)):
        return _decode_pem_or_raw(bytes(source), origin="<bytes>")

    if isinstance(source, str):
        text = source.strip()
        if "BEGIN PUBLIC KEY" in text:
            pem = text.replace("\\n", "\n").encode("utf-8")
            return _decode_pem_or_raw(pem, origin="<str pem>")
        # Treat as base64 of a raw 32-byte key.
        try:
            raw = base64.b64decode(text, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise RuntimeSignatureError(
                f"public key string is neither PEM nor valid base64: {exc}"
            ) from exc
        return _raw_to_pubkey(raw, origin="<base64>")

    raise RuntimeSignatureError(  # pragma: no cover - defensive type guard
        f"unsupported public key input type: {type(source).__name__}"
    )


def _decode_pem_or_raw(data: bytes, *, origin: str) -> Ed25519PublicKey:
    """Decode bytes as PEM, then base64, then raw 32-byte key."""
    if b"BEGIN PUBLIC KEY" in data:
        try:
            key = load_pem_public_key(data)
        except Exception as exc:
            raise RuntimeSignatureError(
                f"invalid Ed25519 public key PEM ({origin}): {exc}"
            ) from exc
        if not isinstance(key, Ed25519PublicKey):
            raise RuntimeSignatureError(
                f"PEM at {origin} does not encode an Ed25519 public key"
            )
        return key

    if len(data) == 32:
        return _raw_to_pubkey(data, origin=origin)

    # Last resort: try base64 decoding the bytes (e.g. file containing a
    # base64 line without PEM armour).
    try:
        raw = base64.b64decode(data, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise RuntimeSignatureError(
            f"public key bytes at {origin} are not PEM, raw32, or base64: {exc}"
        ) from exc
    return _raw_to_pubkey(raw, origin=origin)


def _raw_to_pubkey(raw: bytes, *, origin: str) -> Ed25519PublicKey:
    """Wrap a 32-byte raw Ed25519 public key."""
    if len(raw) != 32:
        raise RuntimeSignatureError(
            f"raw Ed25519 public key at {origin} must be 32 bytes, got {len(raw)}"
        )
    try:
        return Ed25519PublicKey.from_public_bytes(raw)
    except Exception as exc:  # pragma: no cover - cryptography accepts any 32 bytes; defensive guard against future ABI breaks
        raise RuntimeSignatureError(
            f"raw Ed25519 public key at {origin} is invalid: {exc}"
        ) from exc


def _load_public_keys_from_env() -> list[Ed25519PublicKey]:
    """Load trusted public keys from the ``ROVE_TRUSTED_PUBKEYS`` env var."""
    raw = os.environ.get(_ENV_TRUSTED_KEYS, "").strip()
    if not raw:
        return []

    keys: list[Ed25519PublicKey] = []
    # PEM blocks contain commas only inside base64? No — PEM base64
    # never contains commas, so ``,`` is a safe separator. We still split
    # carefully: a single PEM block may span multiple ``\n``-escaped
    # lines but no commas.
    for chunk in raw.split(","):
        entry = chunk.strip()
        if not entry:
            continue
        try:
            keys.append(_normalize_pubkey_input(entry))
        except RuntimeSignatureError as exc:
            logger.warning("skipping bad %s entry: %s", _ENV_TRUSTED_KEYS, exc)
    return keys


def _load_public_keys_from_user_dir() -> list[Ed25519PublicKey]:
    """Load trusted public keys from ``~/.config/rove/trusted_keys/*.pem``."""
    if not _USER_TRUSTED_DIR.is_dir():
        return []

    keys: list[Ed25519PublicKey] = []
    for pem_path in sorted(_USER_TRUSTED_DIR.glob("*.pem")):
        try:
            keys.append(_normalize_pubkey_input(pem_path))
        except RuntimeSignatureError as exc:
            logger.warning("skipping bad trusted key %s: %s", pem_path, exc)
    return keys


def _collect_trusted_keys(
    additional_keys: Iterable[KeyInput],
) -> list[Ed25519PublicKey]:
    """Aggregate trusted keys from env + user dir + caller-supplied set."""
    keys: list[Ed25519PublicKey] = []
    keys.extend(_load_public_keys_from_env())
    keys.extend(_load_public_keys_from_user_dir())
    for extra in additional_keys:
        keys.append(_normalize_pubkey_input(extra))
    return keys


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def sign(payload: bytes, private_key_pem: KeyInput) -> str:
    """Sign ``payload`` with an Ed25519 private key.

    Args:
        payload: The exact bytes to sign (typically
            :meth:`WheelhouseManifest.signing_payload`).
        private_key_pem: PEM bytes, PEM string, or :class:`pathlib.Path`
            pointing at a PEM file holding the Ed25519 private key.

    Returns:
        Lowercase hex-encoded 64-byte Ed25519 signature (128 chars).

    Raises:
        RuntimeSignatureError: Key cannot be loaded or is not Ed25519.
    """
    priv = _load_private_key_pem(private_key_pem)
    return priv.sign(payload).hex()


def verify(
    payload: bytes,
    signature_hex: str,
    *,
    additional_keys: Iterable[KeyInput] = (),
) -> bool:
    """Verify an Ed25519 signature against the configured trusted key set.

    Args:
        payload: Bytes that were signed.
        signature_hex: Lowercase or uppercase hex signature (128 chars).
        additional_keys: Extra trusted public keys to consider beyond the
            env- and user-dir-loaded set.

    Returns:
        ``True`` as soon as any trusted key validates the signature,
        ``False`` if no key matches.

    Raises:
        RuntimeSignatureError: Signature is not valid hex, or no trusted
            keys are configured at all (env + user dir + ``additional_keys``
            all empty).
    """
    try:
        signature_bytes = bytes.fromhex(signature_hex)
    except ValueError as exc:
        raise RuntimeSignatureError(
            f"signature is not valid hex: {exc}"
        ) from exc

    trusted = _collect_trusted_keys(additional_keys)
    if not trusted:
        raise RuntimeSignatureError(
            "no trusted Ed25519 public keys configured "
            f"(set {_ENV_TRUSTED_KEYS}, drop PEMs in {_USER_TRUSTED_DIR}, "
            "or pass additional_keys=...)"
        )

    for pub in trusted:
        try:
            pub.verify(signature_bytes, payload)
            return True
        except InvalidSignature:
            continue
        except Exception as exc:
            logger.warning("trusted key raised unexpected error: %s", exc)
            continue
    return False


def sign_manifest(
    manifest: WheelhouseManifest,
    private_key_pem: KeyInput,
) -> WheelhouseManifest:
    """Return a copy of ``manifest`` with ``signature`` populated.

    The signature covers :meth:`WheelhouseManifest.signing_payload`. The
    input manifest is not mutated; a new validated instance is returned.

    Args:
        manifest: Manifest to sign. Its existing ``signature`` field is
            ignored and replaced.
        private_key_pem: PEM bytes/string/path of the Ed25519 private key.

    Returns:
        A new :class:`WheelhouseManifest` with the freshly computed
        signature.

    Raises:
        RuntimeSignatureError: Key cannot be loaded or is not Ed25519.
    """
    signature_hex = sign(manifest.signing_payload(), private_key_pem)
    return manifest.model_copy(update={"signature": signature_hex})


def verify_manifest(
    manifest: WheelhouseManifest,
    *,
    additional_keys: Iterable[KeyInput] = (),
) -> bool:
    """Verify the signature on ``manifest`` against the trusted key set.

    Args:
        manifest: Manifest carrying the signature to verify. Its
            :meth:`signing_payload` provides the exact bytes that were
            signed.
        additional_keys: Extra trusted public keys to consider beyond the
            env- and user-dir-loaded set.

    Returns:
        ``True`` if the signature matches any trusted key, ``False`` if
        none match.

    Raises:
        RuntimeSignatureError: Signature is malformed or no trusted keys
            are configured.
    """
    return verify(
        manifest.signing_payload(),
        manifest.signature,
        additional_keys=additional_keys,
    )


def sha256_file(path: Path, chunk_size: int = 64 * 1024) -> str:
    """Compute the SHA-256 of a file streamed in 64 KiB chunks.

    Args:
        path: Filesystem path to the file.
        chunk_size: Read buffer size in bytes (default 64 KiB).

    Returns:
        Lowercase hex SHA-256 digest (64 chars).

    Raises:
        OSError: The file cannot be opened or read.
    """
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()

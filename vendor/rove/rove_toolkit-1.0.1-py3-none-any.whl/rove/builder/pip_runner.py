"""Controlled ``pip download`` runner used by Rove's wheelhouse builder.

Wraps a subprocess invocation of ``<python> -m pip download`` so that
the rest of Rove never has to construct argv lists or handle the
subprocess plumbing directly.

Public API:

* :class:`PipRunOptions` — typed options bag (Pydantic).
* :class:`PipRunResult`  — typed result (Pydantic).
* :func:`run_pip_download` — invoke pip and collect resulting wheels.
* :class:`PipError`      — raised when pip exits non-zero.
"""
from __future__ import annotations

import logging
import os
import subprocess
from pathlib import Path

from pydantic import BaseModel, Field, field_validator

from rove.targets import Target

__all__ = [
    "PipError",
    "PipRunOptions",
    "PipRunResult",
    "run_pip_download",
]

logger = logging.getLogger("rove.builder.pip_runner")

_STDERR_TAIL_LINES = 40

_ENV_ALLOWLIST: frozenset[str] = frozenset(
    {
        "PATH",
        "HOME",
        "USER",
        "USERNAME",
        "USERPROFILE",
        "TMPDIR",
        "TEMP",
        "TMP",
        "APPDATA",
        "LOCALAPPDATA",
        "PROGRAMDATA",
        "SYSTEMROOT",
        "SYSTEMDRIVE",
        "WINDIR",
        "COMSPEC",
        "PATHEXT",
        "LANG",
        "LC_ALL",
        "SSL_CERT_FILE",
        "SSL_CERT_DIR",
        "REQUESTS_CA_BUNDLE",
        "CURL_CA_BUNDLE",
        "VIRTUAL_ENV",
    }
)
_ENV_ALLOWED_PREFIXES: tuple[str, ...] = (
    "LC_",
    "PIP_",
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "NO_PROXY",
    "http_proxy",
    "https_proxy",
    "no_proxy",
)


class PipError(RuntimeError):
    """Raised when the wrapped ``pip download`` invocation fails."""


class PipRunOptions(BaseModel):
    """Options for a single ``pip download`` invocation."""

    requirements: list[str] = Field(
        ...,
        description=(
            "Requirement specs (``pkg==1.2.3``, ``pkg>=1.0``) or absolute "
            "lines extracted from a requirements file. Must be non-empty."
        ),
    )
    target: Target = Field(
        ...,
        description="Concrete target the wheels are being collected for.",
    )
    python_executable: Path = Field(
        ...,
        description=(
            "Path to the Python interpreter that runs ``-m pip``. Typically "
            "the standalone CPython shipped by python-build-standalone."
        ),
    )
    output_dir: Path = Field(
        ...,
        description="Directory pip downloads wheels into.",
    )
    prefer_binary: bool = Field(
        default=True,
        description="Pass ``--prefer-binary`` to pip.",
    )
    extra_env: dict[str, str] = Field(
        default_factory=dict,
        description="Env vars merged into the subprocess environment.",
    )
    extra_args: list[str] = Field(
        default_factory=list,
        description=(
            "Additional argv tokens appended verbatim — e.g. "
            "``['--platform', 'manylinux2014_aarch64', '--only-binary', ':all:']``."
        ),
    )
    timeout_seconds: int = Field(
        default=1800,
        gt=0,
        description="Subprocess timeout (seconds). Defaults to 30 min.",
    )

    @field_validator("requirements")
    @classmethod
    def _non_empty(cls, v: list[str]) -> list[str]:
        cleaned = [s.strip() for s in v if s and s.strip()]
        if not cleaned:
            raise ValueError("requirements must contain at least one non-empty entry")
        return cleaned

    @field_validator("python_executable")
    @classmethod
    def _executable_exists(cls, v: Path) -> Path:
        if not v.exists():
            raise ValueError(f"python_executable does not exist: {v}")
        return v


class PipRunResult(BaseModel):
    """Result of a ``pip download`` invocation."""

    returncode: int = Field(..., description="Subprocess exit code.")
    stdout: str = Field(default="", description="Captured stdout.")
    stderr: str = Field(default="", description="Captured stderr.")
    wheels_collected: list[Path] = Field(
        default_factory=list,
        description="Wheels (``*.whl``) found in ``output_dir`` after the run.",
    )


def _build_argv(opts: PipRunOptions) -> list[str]:
    argv: list[str] = [
        str(opts.python_executable),
        "-m",
        "pip",
        "download",
        "--dest",
        str(opts.output_dir),
    ]
    if opts.prefer_binary:
        argv.append("--prefer-binary")
    argv.extend(opts.requirements)
    argv.extend(opts.extra_args)
    return argv


def _merged_env(extra_env: dict[str, str]) -> dict[str, str]:
    # Allowlist the parent environment instead of ``os.environ.copy()``:
    # a full copy leaks host secrets (CI tokens, signing-key paths, cloud
    # credentials) into ``pip download`` and any build hooks it triggers.
    # Callers who need extra vars must pass them explicitly via ``extra_env``.
    merged: dict[str, str] = {}
    for name, value in os.environ.items():
        if name in _ENV_ALLOWLIST or name.startswith(_ENV_ALLOWED_PREFIXES):
            merged[name] = value
    merged.update(extra_env)
    return merged


def _stderr_tail(stderr: str, *, lines: int = _STDERR_TAIL_LINES) -> str:
    if not stderr:
        return ""
    tail = stderr.strip().splitlines()[-lines:]
    return "\n".join(tail)


def run_pip_download(opts: PipRunOptions) -> PipRunResult:
    """Run ``pip download`` according to ``opts`` and collect resulting wheels.

    The subprocess is invoked with an argv list (no shell), captures
    both streams, and is bounded by ``opts.timeout_seconds``.

    Args:
        opts: Validated :class:`PipRunOptions`.

    Returns:
        A :class:`PipRunResult` reflecting the subprocess outcome and the
        wheels found in ``opts.output_dir`` after completion.

    Raises:
        PipError: pip exited non-zero, or the subprocess timed out.
            ``stderr`` tail is included in the message.
    """
    opts.output_dir.mkdir(parents=True, exist_ok=True)
    argv = _build_argv(opts)
    env = _merged_env(opts.extra_env)

    logger.info(
        "pip download target=%s reqs=%d output=%s",
        opts.target.value,
        len(opts.requirements),
        opts.output_dir,
    )
    logger.debug("argv: %s", argv)

    try:
        completed = subprocess.run(
            argv,
            env=env,
            capture_output=True,
            text=True,
            timeout=opts.timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise PipError(
            f"pip download timed out after {opts.timeout_seconds}s "
            f"(target={opts.target.value})"
        ) from exc
    except FileNotFoundError as exc:
        raise PipError(
            f"python executable not found: {opts.python_executable}"
        ) from exc

    wheels = sorted(opts.output_dir.glob("*.whl"))
    result = PipRunResult(
        returncode=completed.returncode,
        stdout=completed.stdout or "",
        stderr=completed.stderr or "",
        wheels_collected=wheels,
    )

    if completed.returncode != 0:
        tail = _stderr_tail(result.stderr)
        raise PipError(
            f"pip download failed (rc={completed.returncode}, "
            f"target={opts.target.value}). stderr tail:\n{tail}"
        )

    logger.info(
        "pip download succeeded: %d wheel(s) in %s",
        len(wheels),
        opts.output_dir,
    )
    return result

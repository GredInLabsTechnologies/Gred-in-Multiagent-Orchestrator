"""
Apply resolved Rove patches during a wheelhouse build.

This module is the *consumer* side of :mod:`rove.patches.loader`: given
a list of :class:`~rove.patches.loader.PatchEntry` instances already
resolved against the current build target, it applies each entry
according to its :class:`~rove.patches.loader.PatchKind`:

* ``env`` — parse ``KEY=VALUE`` lines and merge into a dict that the
  caller injects into a build subprocess environment.
* ``patch`` — invoke GNU ``patch -p1`` against an unpacked sdist
  directory.
* ``toml`` — return the parsed TOML document so the downstream
  build-system consumer can interpret it.

The module deliberately performs no resolution itself — callers should
have already filtered the patch set with
:func:`~rove.patches.loader.resolve_patches`.
"""
from __future__ import annotations

import shutil
import subprocess
import tomllib
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from rove.patches.loader import PatchEntry, PatchKind

__all__ = [
    "AppliedPatches",
    "PatchApplyError",
    "apply_all",
    "apply_env_patches",
    "apply_unified_diff",
    "read_toml_overrides",
]


class PatchApplyError(RuntimeError):
    """Raised on malformed env files, patch failures, or missing tools."""


class AppliedPatches(BaseModel):
    """Structured result of :func:`apply_all`."""

    env_overrides: dict[str, str] = Field(default_factory=dict)
    applied_diffs: list[str] = Field(default_factory=list)
    toml_overrides: list[dict[str, Any]] = Field(default_factory=list)


def _resolve_path(entry: PatchEntry, patch_set_root: Path) -> Path:
    """Resolve ``entry.path`` against the patch set's root directory.

    The resolved path must live *inside* ``patch_set_root``. Rejecting
    ``../`` escapes here defends against a tampered patch index pointing
    at arbitrary host files (``/etc/passwd``, SSH keys, CI secrets).
    The patch index is trust-on-first-use per the module docstring, but
    traversal protection is cheap and independent of the trust model.
    """
    root_resolved = patch_set_root.resolve()
    candidate = (patch_set_root / entry.path).resolve()
    if not candidate.is_relative_to(root_resolved):
        raise PatchApplyError(
            f"patch entry {entry.id!r} path {entry.path!r} escapes "
            f"patch set root {patch_set_root}"
        )
    if not candidate.is_file():
        raise PatchApplyError(
            f"patch entry {entry.id!r} file missing: {candidate}"
        )
    return candidate


def _parse_env_file(path: Path) -> dict[str, str]:
    """Parse a ``KEY=VALUE`` env file (skip blanks and ``#`` comments)."""
    out: dict[str, str] = {}
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise PatchApplyError(f"cannot read env file {path}: {exc}") from exc

    for lineno, raw in enumerate(text.splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            raise PatchApplyError(
                f"malformed env line {path}:{lineno}: missing '=' in {raw!r}"
            )
        key, _, value = line.partition("=")
        key = key.strip()
        if not key:
            raise PatchApplyError(
                f"malformed env line {path}:{lineno}: empty key in {raw!r}"
            )
        # Strip optional surrounding quotes on the value, but keep inner
        # whitespace intact.
        stripped_value = value.strip()
        if (
            len(stripped_value) >= 2
            and stripped_value[0] == stripped_value[-1]
            and stripped_value[0] in ("'", '"')
        ):
            stripped_value = stripped_value[1:-1]
        out[key] = stripped_value
    return out


def apply_env_patches(
    entries: list[PatchEntry], patch_set_root: Path
) -> dict[str, str]:
    """Merge all ``env`` patch entries into a single dict (later wins).

    Args:
        entries: The full list of resolved patch entries; non-``env``
            kinds are silently ignored.
        patch_set_root: Directory the patch set was loaded from
            (entry ``path`` fields are relative to this).

    Returns:
        A flat ``KEY -> VALUE`` mapping suitable for merging into a
        subprocess environment.

    Raises:
        PatchApplyError: A referenced file is missing or contains a
            malformed line.
    """
    merged: dict[str, str] = {}
    for entry in entries:
        if entry.kind is not PatchKind.env:
            continue
        path = _resolve_path(entry, patch_set_root)
        merged.update(_parse_env_file(path))
    return merged


def apply_unified_diff(
    entry: PatchEntry, patch_set_root: Path, sdist_dir: Path
) -> None:
    """Apply ``entry`` (a unified diff) to ``sdist_dir`` via GNU patch.

    Args:
        entry: A patch entry whose :attr:`PatchEntry.kind` is
            :attr:`PatchKind.patch`.
        patch_set_root: Directory the patch set was loaded from.
        sdist_dir: An unpacked sdist directory the diff is applied
            against (used as the ``patch`` cwd).

    Raises:
        PatchApplyError: ``entry`` is not a unified diff, GNU ``patch``
            is missing from ``PATH``, the sdist dir does not exist, or
            ``patch`` exits non-zero.
    """
    if entry.kind is not PatchKind.patch:
        raise PatchApplyError(
            f"apply_unified_diff called on non-patch entry {entry.id!r} "
            f"(kind={entry.kind.value})"
        )
    if not sdist_dir.is_dir():
        raise PatchApplyError(f"sdist dir does not exist: {sdist_dir}")

    patch_exe = shutil.which("patch")
    if patch_exe is None:
        raise PatchApplyError(
            "GNU 'patch' is not on PATH. Install it (e.g. via Git for Windows, "
            "MSYS2, Chocolatey 'patch', or your distro's package manager) and "
            "re-run the build."
        )

    patch_path = _resolve_path(entry, patch_set_root)
    try:
        completed = subprocess.run(
            [patch_exe, "-p1", "-i", str(patch_path)],
            cwd=str(sdist_dir),
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError as exc:
        raise PatchApplyError(
            f"failed to invoke 'patch' for {entry.id!r}: {exc}"
        ) from exc

    if completed.returncode != 0:
        raise PatchApplyError(
            f"patch entry {entry.id!r} failed (exit={completed.returncode}):\n"
            f"stdout: {completed.stdout.strip()}\n"
            f"stderr: {completed.stderr.strip()}"
        )


def read_toml_overrides(
    entries: list[PatchEntry], patch_set_root: Path
) -> list[dict[str, Any]]:
    """Read all ``toml`` patch entries as parsed dicts in entry order.

    Args:
        entries: The full list of resolved patch entries; non-``toml``
            kinds are silently ignored.
        patch_set_root: Directory the patch set was loaded from.

    Returns:
        The parsed TOML documents, in the order their entries appear.

    Raises:
        PatchApplyError: A file is missing or fails TOML parsing.
    """
    out: list[dict[str, Any]] = []
    for entry in entries:
        if entry.kind is not PatchKind.toml:
            continue
        path = _resolve_path(entry, patch_set_root)
        try:
            with path.open("rb") as fh:
                out.append(tomllib.load(fh))
        except OSError as exc:
            raise PatchApplyError(
                f"cannot read toml override {path}: {exc}"
            ) from exc
        except tomllib.TOMLDecodeError as exc:
            raise PatchApplyError(
                f"toml override {path} is malformed: {exc}"
            ) from exc
    return out


def apply_all(
    entries: list[PatchEntry],
    patch_set_root: Path,
    *,
    sdist_dir: Path | None = None,
) -> AppliedPatches:
    """Dispatch every entry to the correct applier and aggregate results.

    Args:
        entries: Resolved patch entries.
        patch_set_root: Directory the patch set was loaded from.
        sdist_dir: Required when ``entries`` contains any
            :attr:`PatchKind.patch` entry; the unpacked sdist the diff
            applies against.

    Returns:
        An :class:`AppliedPatches` summary describing what was applied.

    Raises:
        PatchApplyError: Any individual application step fails, or a
            ``patch`` entry was supplied with no ``sdist_dir``.
    """
    env_overrides = apply_env_patches(entries, patch_set_root)
    toml_overrides = read_toml_overrides(entries, patch_set_root)

    applied_diffs: list[str] = []
    for entry in entries:
        if entry.kind is not PatchKind.patch:
            continue
        if sdist_dir is None:
            raise PatchApplyError(
                f"patch entry {entry.id!r} requires sdist_dir but none was given"
            )
        apply_unified_diff(entry, patch_set_root, sdist_dir)
        applied_diffs.append(entry.id)

    return AppliedPatches(
        env_overrides=env_overrides,
        applied_diffs=applied_diffs,
        toml_overrides=toml_overrides,
    )

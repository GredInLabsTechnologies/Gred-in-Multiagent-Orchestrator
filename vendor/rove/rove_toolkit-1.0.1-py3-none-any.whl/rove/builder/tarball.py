"""
Rove deterministic tarball builder.

Assembles a wheelhouse bundle layout::

    <project_name>-<target>-<runtime_version>/
    ├── python/        (extracted python-build-standalone tree, optional)
    ├── wheelhouse/    (pre-built wheels)
    └── project/       (source tree filtered by include/exclude globs)

into a deterministic ``.tar.xz`` / ``.tar`` / ``.tar.zst`` archive and
emits the matching :class:`~rove.manifest.WheelhouseManifest` (unsigned;
the caller signs separately via :func:`rove.signing.ed25519.sign_manifest`).

Determinism guarantees:

* Files walked in lexicographic order.
* TarInfo ``mtime``/``uid``/``gid`` zeroed; ``uname``/``gname`` blanked.
* Permissions normalized to ``0o755`` for directories and ``0o644`` for
  regular files. Files under ``python/bin/`` keep their executable bit
  when a python tree is bundled (the standalone CPython needs it).

The output tarball is hashed via SHA-256 (streamed) and reported in the
returned :class:`TarballBuildResult` and embedded in the manifest's
``tarball_sha256`` field.
"""
from __future__ import annotations

import contextlib
import fnmatch
import hashlib
import io
import os
import tarfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from rove.manifest import WheelhouseManifest
from rove.targets import Compression, Target

__all__ = [
    "TarballBuildError",
    "TarballBuildOptions",
    "TarballBuildResult",
    "build_tarball",
]


_PLACEHOLDER_SIGNATURE = "0" * 128
_DEFAULT_PYTHON_REL = "python/bin/python3"
_PROJECT_REL = "project"
_WHEELS_REL = "wheelhouse"
_PYTHON_REL = "python"
_CHUNK_SIZE = 64 * 1024


class TarballBuildError(RuntimeError):
    """Raised on layout, IO, or compression failures during tarball build."""


class TarballBuildOptions(BaseModel):
    """Inputs to :func:`build_tarball`.

    The ``target`` field must be a concrete :class:`Target`
    (call :func:`rove.targets.resolve` before constructing).
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    project_name: str
    runtime_version: str
    target: Target
    compression: Compression = Compression.xz
    output_dir: Path
    python_root: Path | None = None
    wheels_dir: Path
    project_root: Path
    include: list[str] = Field(default_factory=lambda: ["src"])
    exclude: list[str] = Field(
        default_factory=lambda: ["tests/", "*.pyc", "__pycache__/"]
    )
    python_path_entries: list[str] = Field(default_factory=list)
    extra_env: dict[str, str] = Field(default_factory=dict)
    patches_applied: list[str] = Field(default_factory=list)
    python_version: str | None = None
    builder_id: str | None = None


class TarballBuildResult(BaseModel):
    """Outcome of :func:`build_tarball`."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    tarball_path: Path
    manifest: WheelhouseManifest
    compressed_size_bytes: int
    uncompressed_size_bytes: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _compression_ext(compression: Compression) -> str:
    """Return the trailing extension fragment for a compression mode."""
    if compression is Compression.xz:
        return "xz"
    if compression is Compression.zstd:
        return "zst"
    if compression is Compression.none:
        return ""
    raise TarballBuildError(f"unsupported compression: {compression!r}")  # pragma: no cover - defensive: Compression StrEnum has only the 3 members above


def _tarball_filename(
    project_name: str, target: Target, runtime_version: str, compression: Compression
) -> str:
    """Build the canonical tarball filename for a bundle."""
    ext = _compression_ext(compression)
    base = f"{project_name}-{target.value}-{runtime_version}.tar"
    return base if not ext else f"{base}.{ext}"


def _normalize_glob(pattern: str) -> str:
    """Strip trailing slash from glob patterns (``tests/`` → ``tests``)."""
    return pattern.rstrip("/").rstrip("\\")


def _is_excluded(rel_path: str, exclude_patterns: list[str]) -> bool:
    """Test ``rel_path`` (POSIX form) against a list of fnmatch patterns.

    A pattern ending in ``/`` matches the directory and everything below.
    Bare patterns match either a basename or a path segment.
    """
    posix = rel_path.replace(os.sep, "/")
    parts = posix.split("/")
    basename = parts[-1] if parts else posix

    for raw in exclude_patterns:
        pat = _normalize_glob(raw)
        if not pat:
            continue
        if fnmatch.fnmatch(basename, pat):
            return True
        if fnmatch.fnmatch(posix, pat):
            return True
        # Directory-style match: any segment equals the pattern.
        if pat in parts:
            return True
        # Path-prefix match for `dir/sub` style patterns.
        if "/" in pat and posix.startswith(pat + "/"):
            return True
    return False


def _collect_include_roots(project_root: Path, include: list[str]) -> list[Path]:
    """Resolve include globs/paths relative to ``project_root``.

    Each include entry may be a literal subpath (``src``) or a glob
    (``packages/*``). Missing literal entries are silently skipped — a
    project may declare optional dirs.
    """
    roots: list[Path] = []
    seen: set[Path] = set()
    for entry in include:
        if not entry:
            continue
        # Literal path first.
        literal = (project_root / entry).resolve()
        if literal.exists():
            if literal not in seen:
                roots.append(literal)
                seen.add(literal)
            continue
        # Otherwise treat as a glob relative to project_root.
        for match in sorted(project_root.glob(entry)):
            resolved = match.resolve()
            if resolved not in seen:
                roots.append(resolved)
                seen.add(resolved)
    return roots


def _walk_files(root: Path) -> list[Path]:
    """Return every regular file under ``root`` in sorted POSIX order."""
    if root.is_file():
        return [root]
    out: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames.sort()
        for name in sorted(filenames):
            out.append(Path(dirpath) / name)
    return out


def _is_executable_python_bin(arcname: str) -> bool:
    """Files under ``python/bin/`` need to keep their +x bit on POSIX."""
    posix = arcname.replace(os.sep, "/")
    return posix.startswith("python/bin/")


def _normalize_tarinfo(info: tarfile.TarInfo, *, preserve_exec: bool) -> tarfile.TarInfo:
    """Strip user/time metadata and normalize permissions for determinism."""
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    if info.isdir():
        info.mode = 0o755
    elif info.isreg():
        if preserve_exec and (info.mode & 0o111):
            info.mode = 0o755
        else:
            info.mode = 0o644
    elif info.issym() or info.islnk():
        info.mode = 0o777
    else:
        info.mode = 0o644
    return info


def _add_file(
    tar: tarfile.TarFile, source: Path, arcname: str, *, preserve_exec: bool
) -> int:
    """Add a single file to ``tar`` with normalized metadata.

    Returns the on-disk size of the file (used for the uncompressed
    size accounting).
    """
    info = tar.gettarinfo(name=str(source), arcname=arcname)
    if info is None:
        raise TarballBuildError(f"could not stat {source}")
    _normalize_tarinfo(info, preserve_exec=preserve_exec)
    if info.isreg():
        with source.open("rb") as fh:
            tar.addfile(info, fh)
        return int(info.size)
    tar.addfile(info)
    return 0


def _add_directory_entry(tar: tarfile.TarFile, arcname: str) -> None:
    """Add an explicit directory entry (so empty dirs appear in the tar)."""
    info = tarfile.TarInfo(name=arcname.rstrip("/") + "/")
    info.type = tarfile.DIRTYPE
    info.mode = 0o755
    info.mtime = 0
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    tar.addfile(info)


def _stage_python(
    python_root: Path, staging_root: Path
) -> tuple[list[tuple[Path, str]], int]:
    """Stage the python-build-standalone tree under ``python/`` in the bundle.

    Returns a ``(entries, total_bytes)`` pair where each entry is a
    ``(source_path, arcname)`` pair. The tree is not copied — we just
    enumerate it.
    """
    if not python_root.is_dir():
        raise TarballBuildError(f"python_root is not a directory: {python_root}")
    files = _walk_files(python_root)
    entries: list[tuple[Path, str]] = []
    total = 0
    for src in files:
        rel = src.relative_to(python_root).as_posix()
        arcname = f"{staging_root.name}/{_PYTHON_REL}/{rel}"
        with contextlib.suppress(OSError):
            total += src.stat().st_size
        entries.append((src, arcname))
    return entries, total


def _stage_wheels(
    wheels_dir: Path, staging_root: Path
) -> tuple[list[tuple[Path, str]], int]:
    """Stage every ``*.whl`` under ``wheelhouse/`` in the bundle."""
    if not wheels_dir.is_dir():
        raise TarballBuildError(f"wheels_dir is not a directory: {wheels_dir}")
    wheels = sorted(wheels_dir.glob("*.whl"))
    entries: list[tuple[Path, str]] = []
    total = 0
    for src in wheels:
        arcname = f"{staging_root.name}/{_WHEELS_REL}/{src.name}"
        with contextlib.suppress(OSError):
            total += src.stat().st_size
        entries.append((src, arcname))
    return entries, total


def _stage_project(
    project_root: Path,
    include: list[str],
    exclude: list[str],
    staging_root: Path,
) -> tuple[list[tuple[Path, str]], int]:
    """Stage filtered project files under ``project/`` in the bundle."""
    if not project_root.is_dir():
        raise TarballBuildError(f"project_root is not a directory: {project_root}")

    roots = _collect_include_roots(project_root, include)
    entries: list[tuple[Path, str]] = []
    total = 0
    seen_arcnames: set[str] = set()

    for root in roots:
        files = _walk_files(root)
        # The arcname is the path *relative to project_root* so we keep
        # the original layout under project/.
        try:
            root_rel = root.relative_to(project_root)
        except ValueError:
            # Include path escaped project_root — refuse.
            raise TarballBuildError(
                f"include entry {root} is outside project_root {project_root}"
            ) from None

        if root.is_file():
            rel_posix = root_rel.as_posix()
            if _is_excluded(rel_posix, exclude):
                continue
            arcname = f"{staging_root.name}/{_PROJECT_REL}/{rel_posix}"
            if arcname in seen_arcnames:
                continue
            seen_arcnames.add(arcname)
            with contextlib.suppress(OSError):
                total += root.stat().st_size
            entries.append((root, arcname))
            continue

        for src in files:
            try:
                rel = src.relative_to(project_root).as_posix()
            except ValueError:
                continue
            if _is_excluded(rel, exclude):
                continue
            arcname = f"{staging_root.name}/{_PROJECT_REL}/{rel}"
            if arcname in seen_arcnames:
                continue
            seen_arcnames.add(arcname)
            with contextlib.suppress(OSError):
                total += src.stat().st_size
            entries.append((src, arcname))

    return entries, total


def _open_tarfile(
    path: Path, compression: Compression
) -> tarfile.TarFile:
    """Open a writable tarfile for the requested compression mode."""
    if compression is Compression.xz:
        # preset=9 for max compression, deterministic output.
        return tarfile.open(path, mode="w:xz", preset=9)
    if compression is Compression.none:
        return tarfile.open(path, mode="w")
    if compression is Compression.zstd:
        try:
            import zstandard
        except ImportError as exc:
            raise TarballBuildError(
                "zstandard not installed; pip install zstandard"
            ) from exc
        # zstandard's stream writer wraps a binary file; we open the
        # tarfile in uncompressed streaming mode against that wrapper.
        # ``threads=0`` keeps compression single-threaded — multi-threaded
        # zstd with ``stream_writer`` picks flush points based on thread
        # scheduling, so two builds of identical sources could produce
        # byte-different (still-valid) output. That breaks the
        # "byte-identical bundle for identical inputs" guarantee
        # documented in docs/COMMANDS.md.
        cctx = zstandard.ZstdCompressor(level=19, threads=0)
        raw = path.open("wb")
        compressor = cctx.stream_writer(raw)
        sink = _ZstdSink(compressor, raw)
        # tarfile in stream-write mode treats a caller-supplied fileobj
        # as external (``_extfileobj=True``) and never closes it, so we
        # attach the sink to the returned TarFile and close it
        # explicitly in ``build_tarball`` after the tar context exits.
        tf = tarfile.open(fileobj=sink, mode="w|")  # noqa: SIM115 - caller owns the tar; build_tarball closes it explicitly
        tf._rove_zstd_sink = sink  # type: ignore[attr-defined]
        return tf
    raise TarballBuildError(f"unsupported compression: {compression!r}")  # pragma: no cover - defensive: Compression StrEnum has only xz/zstd/none, all handled above


class _ZstdSink(io.RawIOBase):
    """Tiny adapter that exposes a zstd stream writer as a binary file."""

    def __init__(self, compressor: Any, underlying: Any) -> None:
        super().__init__()
        self._compressor = compressor
        self._underlying = underlying
        self._closed = False

    def writable(self) -> bool:
        return True

    def write(self, b: Any) -> int:
        # ``stream_writer`` exposes a write() that returns bytes consumed.
        data = bytes(b)
        written = self._compressor.write(data)
        return int(written) if written is not None else len(data)

    def close(self) -> None:
        if self._closed:
            return
        try:
            # Flush + close the zstd frame.
            self._compressor.close()
        finally:
            try:
                self._underlying.close()
            finally:
                self._closed = True
        super().close()


def _sha256_file(path: Path) -> str:
    """Stream-compute the SHA-256 of ``path``."""
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(_CHUNK_SIZE)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def build_tarball(opts: TarballBuildOptions) -> TarballBuildResult:
    """Build the deterministic wheelhouse tarball described by ``opts``.

    Args:
        opts: Validated :class:`TarballBuildOptions`. ``opts.target``
            must be a concrete :class:`Target` (resolve before calling).

    Returns:
        A :class:`TarballBuildResult` carrying the produced tarball
        path, the populated (but **unsigned**) manifest, and the
        compressed/uncompressed byte counts.

    Raises:
        TarballBuildError: Any layout, IO, or compression problem.
    """
    if opts.target is Target.host:
        raise TarballBuildError(
            "TarballBuildOptions.target is Target.host — resolve to a concrete "
            "target with rove.targets.resolve before calling build_tarball."
        )

    output_dir = opts.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    tarball_name = _tarball_filename(
        opts.project_name, opts.target, opts.runtime_version, opts.compression
    )
    tarball_path = (output_dir / tarball_name).resolve()

    # Staging "root" name — only the basename matters; we never write the
    # bundle to a temp dir on disk, the path drives arcname prefixes only.
    staging_root = Path(
        f"{opts.project_name}-{opts.target.value}-{opts.runtime_version}"
    )

    # Collect (source, arcname) pairs in deterministic order.
    python_entries: list[tuple[Path, str]] = []
    python_bytes = 0
    if opts.python_root is not None:
        python_entries, python_bytes = _stage_python(opts.python_root, staging_root)

    wheel_entries, wheel_bytes = _stage_wheels(opts.wheels_dir, staging_root)
    project_entries, project_bytes = _stage_project(
        opts.project_root, opts.include, opts.exclude, staging_root
    )

    all_entries = python_entries + wheel_entries + project_entries
    # Final sort to guarantee a stable tar order regardless of which
    # subtree contributed each path.
    all_entries.sort(key=lambda pair: pair[1])

    # Track files for the manifest's `files` field (relative to the
    # bundle root, *without* the staging_root prefix).
    bundle_files: list[str] = []
    prefix = staging_root.name + "/"

    # Open output tarball.
    if tarball_path.exists():
        try:
            tarball_path.unlink()
        except OSError as exc:
            raise TarballBuildError(
                f"cannot remove existing tarball {tarball_path}: {exc}"
            ) from exc

    try:
        tar = _open_tarfile(tarball_path, opts.compression)
        try:
            # Top-level dir entry (so ``tar tf`` shows it consistently).
            _add_directory_entry(tar, staging_root.name)

            # Add intermediate dir entries for python/, wheelhouse/, project/.
            for sub in (_PYTHON_REL, _WHEELS_REL, _PROJECT_REL):
                # Only add if at least one file lives under that prefix.
                sub_prefix = f"{staging_root.name}/{sub}/"
                if any(arc.startswith(sub_prefix) for _, arc in all_entries):
                    _add_directory_entry(tar, f"{staging_root.name}/{sub}")

            for src, arcname in all_entries:
                preserve_exec = _is_executable_python_bin(
                    arcname[len(prefix):] if arcname.startswith(prefix) else arcname
                )
                _add_file(tar, src, arcname, preserve_exec=preserve_exec)
                if arcname.startswith(prefix):  # pragma: no branch - all entries are constructed with the staging-root prefix
                    bundle_files.append(arcname[len(prefix):])
        finally:
            tar.close()
            # tarfile in streaming mode does not close caller-supplied
            # fileobjs; finalize the zstd frame ourselves.
            sink = getattr(tar, "_rove_zstd_sink", None)
            if sink is not None:
                sink.close()
    except TarballBuildError:
        raise
    except (OSError, tarfile.TarError) as exc:
        # Best-effort cleanup of a partially written tarball.
        with contextlib.suppress(OSError):
            tarball_path.unlink(missing_ok=True)
        raise TarballBuildError(f"failed to write tarball {tarball_path}: {exc}") from exc

    # Hash + size accounting.
    try:
        compressed_size = tarball_path.stat().st_size
    except OSError as exc:
        raise TarballBuildError(
            f"cannot stat produced tarball {tarball_path}: {exc}"
        ) from exc

    tarball_sha256 = _sha256_file(tarball_path)
    uncompressed_size = python_bytes + wheel_bytes + project_bytes

    # Resolve python_rel_path.
    if opts.python_root is not None:
        python_rel = _resolve_python_rel(opts.python_root)
    else:
        python_rel = _DEFAULT_PYTHON_REL

    manifest = WheelhouseManifest(
        project_name=opts.project_name,
        runtime_version=opts.runtime_version,
        target=opts.target,
        compression=opts.compression,
        tarball_name=tarball_name,
        tarball_sha256=tarball_sha256,
        compressed_size_bytes=compressed_size,
        uncompressed_size_bytes=uncompressed_size,
        python_rel_path=python_rel,
        project_root_rel_path=_PROJECT_REL,
        wheels_rel_path=_WHEELS_REL,
        python_path_entries=list(opts.python_path_entries),
        files=bundle_files,
        extra_env=dict(opts.extra_env),
        patches_applied=list(opts.patches_applied),
        signature=_PLACEHOLDER_SIGNATURE,
        python_version=opts.python_version if opts.python_root is not None else None,
        built_at=datetime.now(UTC).isoformat(timespec="seconds"),
        builder=opts.builder_id,
    )

    return TarballBuildResult(
        tarball_path=tarball_path,
        manifest=manifest,
        compressed_size_bytes=compressed_size,
        uncompressed_size_bytes=uncompressed_size,
    )


def _resolve_python_rel(python_root: Path) -> str:
    """Return the relative path to the bundled CPython binary.

    On POSIX targets the standalone tree ships ``python/bin/python3``;
    on Windows it ships ``python/python.exe``. We probe the actual tree
    so the manifest reflects what the bundle contains.
    """
    candidates_posix = ("bin/python3", "bin/python3.13", "bin/python")
    candidates_windows = ("python.exe",)
    for rel in candidates_posix:
        if (python_root / rel).exists():
            return f"{_PYTHON_REL}/{rel}"
    for rel in candidates_windows:
        if (python_root / rel).exists():
            return f"{_PYTHON_REL}/{rel}"
    # Fall back to the conventional placeholder; the bundle is still
    # usable, only the manifest hint is approximate.
    return _DEFAULT_PYTHON_REL



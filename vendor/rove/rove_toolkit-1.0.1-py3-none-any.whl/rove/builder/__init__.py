"""Build subsystem — pip orchestration, Zig cross-compile, patch application."""

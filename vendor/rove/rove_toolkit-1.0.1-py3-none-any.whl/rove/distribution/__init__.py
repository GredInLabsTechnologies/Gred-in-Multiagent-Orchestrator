"""Distribution subsystem — HTTP fetch/serve + pluggable backend protocol."""

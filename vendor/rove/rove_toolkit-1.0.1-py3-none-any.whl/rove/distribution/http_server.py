"""
Lightweight HTTP server that publishes a directory of Rove bundles.

Used by ``rove serve`` (CLI) and by tests. Wraps stdlib
:class:`http.server.ThreadingHTTPServer` with a request handler that:

* Serves files from a fixed ``bundle_dir``.
* Sets correct ``Content-Type`` for ``.tar.xz`` (``application/x-xz``),
  ``.tar.zst`` (``application/zstd``), and ``.json`` (``application/json``).
* Honors HTTP ``Range`` requests via Python 3.9+'s native
  :class:`SimpleHTTPRequestHandler` support — so the matching
  :func:`rove.distribution.http_fetcher.fetch_bundle` can resume.
* Is quiet by default: logs go to a :class:`rich.console.Console` at
  warning-level, never to stderr.

The server runs in a daemon thread so tests can :meth:`start` / :meth:`stop`
without blocking, or use it as a context manager.
"""
from __future__ import annotations

import os
import re
import threading
from http import HTTPStatus
from http import server as http_server
from pathlib import Path
from types import TracebackType
from typing import Any

from pydantic import BaseModel, Field
from rich.console import Console

from rove.distribution.plugin import DistributionError

__all__ = [
    "HttpServerOptions",
    "NoFQDNThreadingHTTPServer",
    "RoveHttpServer",
    "serve",
]


class NoFQDNThreadingHTTPServer(http_server.ThreadingHTTPServer):
    """``ThreadingHTTPServer`` that skips the reverse-DNS lookup.

    Stdlib's :meth:`http.server.BaseHTTPServer.server_bind` calls
    :func:`socket.getfqdn` on the bound host. On macOS GitHub Actions
    runners that reverse lookup for ``127.0.0.1`` hangs indefinitely —
    the test-suite timeout eventually fires. The FQDN is only used for
    cosmetic ``Server:`` header output, which Rove does not emit, so we
    bypass it entirely.

    Exported as a public name so tests that spin up auxiliary servers
    (e.g. redirect integration tests) can reuse the same workaround
    instead of importing the stdlib class directly and re-hitting the
    hang.
    """

    def server_bind(self) -> None:
        import socketserver

        socketserver.TCPServer.server_bind(self)
        host, port = self.server_address[:2]
        self.server_name = str(host)
        self.server_port = int(port)

_BUNDLE_GLOBS: tuple[str, ...] = ("*.tar.xz", "*.tar.zst", "*.tar.gz", "*.tar")

_EXTRA_MIME_TYPES: dict[str, str] = {
    ".xz": "application/x-xz",
    ".zst": "application/zstd",
    ".json": "application/json",
}

# RFC 7233 byte-range header: ``bytes=START-END`` (END optional).
# We intentionally support only single-range requests, which is what every
# resume-capable HTTP downloader (curl, urllib, requests) actually sends.
_RANGE_RE = re.compile(r"^bytes=(\d+)-(\d*)$")


class HttpServerOptions(BaseModel):
    """Parameters for :class:`RoveHttpServer`."""

    bundle_dir: Path = Field(
        description=(
            "Directory containing ``*.tar.xz`` (or ``.tar.zst``) bundles "
            "alongside their ``*.manifest.json`` siblings."
        ),
    )
    host: str = Field(
        default="0.0.0.0",
        description=(
            "Bind address. ``0.0.0.0`` exposes on the LAN (intended for "
            "mesh peers); use ``127.0.0.1`` for local-only."
        ),
    )
    port: int = Field(
        default=8080,
        ge=1,
        le=65535,
        description="TCP port to bind.",
    )


class _BundleRequestHandler(http_server.SimpleHTTPRequestHandler):
    """Serves a fixed directory with correct MIME types and Range support.

    Python's stdlib ``SimpleHTTPRequestHandler`` does not implement HTTP
    ``Range`` requests, so we override :meth:`do_GET` to add single-range
    support — enough for :func:`rove.distribution.http_fetcher.fetch_bundle`
    to resume interrupted downloads. Multi-range requests fall back to a
    full 200 response.
    """

    # Set per-server in :meth:`RoveHttpServer.start`.
    server_console: Console
    server_directory: str

    # ------------------------------------------------------------------
    # SimpleHTTPRequestHandler hooks
    # ------------------------------------------------------------------
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        # Pin the served directory for this request (Python 3.7+).
        super().__init__(*args, directory=self.server_directory, **kwargs)

    def guess_type(self, path: str) -> str:  # type: ignore[override]
        suffix = Path(path).suffix.lower()
        if suffix in _EXTRA_MIME_TYPES:
            return _EXTRA_MIME_TYPES[suffix]
        return super().guess_type(path)

    # ------------------------------------------------------------------
    # Range-aware GET
    # ------------------------------------------------------------------
    def do_GET(self) -> None:
        """Serve a GET, honoring single-range ``Range: bytes=START-END`` headers."""
        range_header = self.headers.get("Range")
        if not range_header:
            super().do_GET()
            return

        match = _RANGE_RE.match(range_header.strip())
        if not match:
            # Multi-range or malformed — degrade gracefully to a full 200.
            super().do_GET()
            return

        # Resolve the requested file using the parent's ``translate_path``;
        # this respects the ``directory=`` arg and applies normal safety
        # checks (no traversal outside ``server_directory``). Then fully
        # resolve symlinks and reject any result that escapes the served
        # directory — stdlib's ``translate_path`` does NOT follow symlinks,
        # so a bundle_dir containing a symlink to ``/etc/passwd`` would
        # otherwise be served verbatim.
        local_path = self.translate_path(self.path)
        try:
            real_local = os.path.realpath(local_path)
            real_root = os.path.realpath(self.server_directory)
        except OSError:  # pragma: no cover - realpath on an unreachable path is rare; stdlib generally returns input unchanged rather than raising. Defensive guard against exotic filesystems (overlayfs, broken mounts).
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return
        # ``os.path.commonpath`` raises on mismatched drives (Windows);
        # fall back to prefix compare which is correct after realpath.
        prefix = real_root + os.sep
        if real_local != real_root and not real_local.startswith(prefix):
            self.send_error(
                HTTPStatus.NOT_FOUND,
                "File not found",  # avoid leaking the refusal reason
            )
            return

        try:
            stat = os.stat(real_local)
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return
        if not os.path.isfile(real_local):
            # Directory listings don't make sense for Range; fall back.
            super().do_GET()
            return
        local_path = real_local

        size = stat.st_size
        start = int(match.group(1))
        end_raw = match.group(2)
        end = int(end_raw) if end_raw else size - 1

        if start >= size or end < start:
            self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
            self.send_header("Content-Range", f"bytes */{size}")
            self.end_headers()
            return

        end = min(end, size - 1)
        length = end - start + 1
        ctype = self.guess_type(local_path)

        try:
            with open(local_path, "rb") as fh:
                fh.seek(start)
                self.send_response(HTTPStatus.PARTIAL_CONTENT)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(length))
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
                self.send_header("Accept-Ranges", "bytes")
                self.end_headers()

                remaining = length
                while remaining > 0:
                    chunk = fh.read(min(64 * 1024, remaining))
                    if not chunk:  # pragma: no cover - file truncated mid-stream between stat and read; defensive guard against TOCTOU
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)
        except OSError:  # pragma: no cover - race between os.stat and open(); both touch the same path so this is unreachable in practice
            self.send_error(HTTPStatus.NOT_FOUND, "File not found")
            return

    # ------------------------------------------------------------------
    # Logging — quiet by default, only surface errors
    # ------------------------------------------------------------------
    def log_message(self, format: str, *args: Any) -> None:
        """Route stdlib log lines to our :class:`Console`, warning-level only."""
        # SimpleHTTPRequestHandler logs every request at "info" level by
        # writing to stderr; keep that off by default and only emit error
        # responses (4xx/5xx) to the console.
        try:
            status = int(args[1])
        except (IndexError, ValueError, TypeError):
            status = 0
        if status >= 400:
            self.server_console.print(
                f"[yellow]http {status}[/yellow] {self.address_string()} "
                f"{format % args}"
            )

    def log_error(self, format: str, *args: Any) -> None:
        self.server_console.print(
            f"[red]http error[/red] {self.address_string()} {format % args}"
        )


class RoveHttpServer:
    """Daemon-threaded HTTP server exposing a Rove bundle directory.

    Use as a context manager in tests, or call :meth:`start` / :meth:`stop`
    explicitly. :func:`serve` is the blocking foreground entry point used
    by the CLI.
    """

    def __init__(
        self,
        opts: HttpServerOptions,
        *,
        console: Console | None = None,
    ) -> None:
        self._opts = opts
        self._console = console or Console(stderr=True, quiet=False)
        self._httpd: http_server.ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    def start(self) -> None:
        """Bind, listen, and start serving in a daemon thread.

        Returns once the socket is bound and the serving thread is alive.

        Raises:
            DistributionError: ``bundle_dir`` does not exist or contains no
                bundles.
            OSError: bind failure (port in use, permission denied, ...).
        """
        bundle_dir = self._opts.bundle_dir.resolve()
        if not bundle_dir.is_dir():
            raise DistributionError(
                f"bundle_dir does not exist or is not a directory: {bundle_dir}"
            )
        if not any(next(bundle_dir.glob(pat), None) for pat in _BUNDLE_GLOBS):
            raise DistributionError(
                f"bundle_dir {bundle_dir} contains no bundles "
                f"(expected one of: {', '.join(_BUNDLE_GLOBS)})"
            )

        # Build a per-server handler class so the served directory + console
        # are baked in without using class-level mutation across servers.
        directory = str(bundle_dir)
        console = self._console

        class _Handler(_BundleRequestHandler):
            server_directory = directory
            server_console = console

        httpd = NoFQDNThreadingHTTPServer(
            (self._opts.host, self._opts.port),
            _Handler,
        )
        # daemon_threads = True so request handler threads do not block exit.
        httpd.daemon_threads = True

        thread = threading.Thread(
            target=httpd.serve_forever,
            name=f"rove-http-{self._opts.port}",
            daemon=True,
        )
        thread.start()

        self._httpd = httpd
        self._thread = thread
        self._console.print(
            f"[green]rove serve[/green] listening on {self.url()} "
            f"(dir={bundle_dir})"
        )

    def stop(self) -> None:
        """Shut down the server and join the serving thread."""
        if self._httpd is None:
            return
        self._httpd.shutdown()
        self._httpd.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5.0)
        self._httpd = None
        self._thread = None

    def url(self) -> str:
        """Return the base URL of the running server, e.g. ``http://0.0.0.0:8080``."""
        if self._httpd is None:
            return f"http://{self._opts.host}:{self._opts.port}"
        host, port = self._httpd.server_address[:2]
        # Some platforms return ``host`` as bytes; coerce to str defensively.
        host_str = host.decode() if isinstance(host, bytes) else str(host)
        return f"http://{host_str}:{port}"

    # ------------------------------------------------------------------
    # Context-manager sugar
    # ------------------------------------------------------------------
    def __enter__(self) -> RoveHttpServer:
        self.start()
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.stop()


def serve(opts: HttpServerOptions) -> None:
    """Blocking foreground entry point used by the CLI.

    Starts the server and blocks until ``KeyboardInterrupt``, then shuts
    down cleanly.
    """
    server = RoveHttpServer(opts)
    server.start()
    try:
        # Block on the serving thread; it never returns until ``stop`` is
        # called, so we just wait for SIGINT.
        thread = server._thread
        assert thread is not None
        while thread.is_alive():
            thread.join(timeout=1.0)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()

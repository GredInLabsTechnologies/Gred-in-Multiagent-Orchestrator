"""
Pluggable distribution backend protocol for Rove.

Rove core ships only the HTTP backend (see :mod:`rove.distribution.http_server`
and :mod:`rove.distribution.http_fetcher`). Other transports — Iroh blob
relay, S3, mesh adapters, IPFS — live in consumer projects and must
implement :class:`DistributionBackend` to interoperate with the rest of the
toolchain (CLI, builder, runtime upgrader).

The protocol is intentionally tiny: ``publish`` to expose a bundle, ``fetch``
to discover/verify/download one. Local cache layout, version discovery, and
auth are backend-specific.
"""
from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

from rove.manifest import WheelhouseManifest
from rove.targets import Target

__all__ = ["DistributionBackend", "DistributionError"]


class DistributionError(RuntimeError):
    """Raised by any distribution backend on transport, integrity, or trust failure.

    Backends MUST raise this (or a subclass) instead of propagating bare
    :class:`OSError`/:class:`urllib.error.URLError`/etc., so that callers
    have a single exception type to catch.
    """


@runtime_checkable
class DistributionBackend(Protocol):
    """Protocol for pluggable bundle distribution backends.

    Implementations live in consumer projects (e.g. a peer-to-peer mesh
    adapter, or a generic S3/Iroh plug-in). Rove core ships only
    :class:`HttpDistributionBackend` in
    :mod:`rove.distribution.http_server` / :mod:`rove.distribution.http_fetcher`.
    """

    def publish(self, manifest: WheelhouseManifest, payload: Path) -> str:
        """Make ``payload`` available; return a discovery URI/handle.

        The returned string MUST be re-usable as input to :meth:`fetch`'s
        ``source`` argument by some peer (e.g. ``"http://192.168.0.16:8080"``,
        ``"iroh://blob/<hash>"``, ``"s3://bucket/path"``).
        """
        ...

    def fetch(
        self,
        target: Target,
        version: str | None = None,
    ) -> tuple[WheelhouseManifest, Path]:
        """Resolve, download, verify; return (manifest, local_payload_path).

        The local payload path is owned by the caller and MUST be a real file
        on disk (extracted, signature-verified). Backends decide their own
        local cache layout.
        """
        ...

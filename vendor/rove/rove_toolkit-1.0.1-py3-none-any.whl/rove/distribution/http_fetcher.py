"""
Range-resume HTTP downloader for Rove bundles.

Streams a manifest + bundle from any HTTP server (typically
:class:`rove.distribution.http_server.RoveHttpServer` running on a peer),
verifies the Ed25519 signature on the manifest, verifies the SHA-256 of
the tarball, and atomically moves the verified payload into place.

stdlib-only (``urllib``), Range-resume, retry with backoff, and a
small :class:`HttpDistributionBackend` that satisfies the
:class:`rove.distribution.plugin.DistributionBackend` protocol.
"""
from __future__ import annotations

import logging
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from rove.distribution.plugin import DistributionError
from rove.manifest import WheelhouseManifest
from rove.signing.ed25519 import (
    RuntimeSignatureError,
    sha256_file,
    verify_manifest,
)
from rove.targets import Target

__all__ = [
    "FetchOptions",
    "FetchResult",
    "HttpDistributionBackend",
    "fetch_bundle",
]

logger = logging.getLogger("rove.distribution.http_fetcher")

_MANIFEST_SUFFIX = ".manifest.json"
_PARTIAL_SUFFIX = ".part"
_HOLDING_SUFFIX = ".incoming"

#: Hard cap for a single manifest body. The manifest is a tiny JSON blob
#: describing the bundle; legitimate manifests are kilobytes at most. A
#: malicious peer that streams gigabytes into ``resp.read()`` would OOM
#: the client — we refuse anything larger than this up front.
_MAX_MANIFEST_BYTES: int = 1 * 1024 * 1024  # 1 MiB

#: Safety factor on top of ``manifest.compressed_size_bytes`` for bundle
#: downloads. A peer advertising 100 MB but streaming 100 GB would fill
#: the disk before the SHA check fires; we stop the download as soon as
#: the stream exceeds the advertised size by this factor.
_BUNDLE_SIZE_TOLERANCE: float = 1.01


# ---------------------------------------------------------------------------
# Public models
# ---------------------------------------------------------------------------
class FetchOptions(BaseModel):
    """Inputs to :func:`fetch_bundle`."""

    source: str = Field(
        description=(
            "HTTP base URL (no trailing path), e.g. "
            "``http://192.168.0.16:8080``."
        ),
        min_length=1,
    )
    bundle_name: str = Field(
        description=(
            "Bundle filename, e.g. ``myapp-android-arm64-0.1.0.tar.xz``. "
            "The manifest is fetched from "
            "``<source>/<bundle_name>.manifest.json``."
        ),
        min_length=1,
    )
    output_dir: Path = Field(
        description="Local directory where the bundle (and its manifest) land.",
    )
    expected_sha256: str | None = Field(
        default=None,
        description=(
            "Optional SHA-256 (lowercase hex) the caller expects. If set, "
            "must match the manifest's ``tarball_sha256`` exactly."
        ),
    )
    additional_pubkeys: list[Path] = Field(
        default_factory=list,
        description="Extra trusted Ed25519 PEM paths passed to ``verify_manifest``.",
    )
    chunk_size: int = Field(default=64 * 1024, ge=1024)
    connect_timeout: float = Field(default=10.0, ge=0.1)
    read_timeout: float = Field(default=60.0, ge=0.1)
    max_retries: int = Field(default=3, ge=0)


class FetchResult(BaseModel):
    """Outcome of :func:`fetch_bundle`."""

    bundle_path: Path
    manifest: WheelhouseManifest
    bytes_downloaded: int = Field(
        ge=0,
        description=(
            "Bytes pulled over the wire on this call. May be less than "
            "``manifest.compressed_size_bytes`` when the download resumed "
            "from a partial; zero when the bundle was already cached."
        ),
    )
    from_cache: bool = Field(
        description=(
            "True if the bundle was already on disk and matched the "
            "expected SHA-256 — no network transfer happened."
        ),
    )


# ---------------------------------------------------------------------------
# HTTP helpers (stdlib-only)
# ---------------------------------------------------------------------------
#: Only HTTP(S) URLs are accepted. ``file://``, ``ftp://``, ``javascript://``,
#: data URIs and relative paths are all rejected up front so a malicious or
#: mistyped ``--from`` can never be coerced into reading ``/etc/shadow``.
_ALLOWED_SCHEMES: frozenset[str] = frozenset({"http", "https"})


class _StrictRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Redirect handler that rejects cross-scheme or cross-host redirects.

    A signed manifest that points at ``http://peer:9000/bundle.tar.xz`` must
    not be silently followed to ``http://attacker.example/…``. Same-host
    redirects (e.g. canonicalisation or trailing-slash fixes) are allowed;
    scheme downgrades or off-host hops are not.
    """

    def redirect_request(
        self,
        req: urllib.request.Request,
        fp: Any,
        code: int,
        msg: str,
        headers: Any,
        newurl: str,
    ) -> urllib.request.Request | None:
        old = urllib.parse.urlparse(req.full_url)
        new = urllib.parse.urlparse(newurl)
        if new.scheme.lower() not in _ALLOWED_SCHEMES:
            raise urllib.error.HTTPError(
                newurl, code, f"redirect to unsupported scheme {new.scheme!r}",
                headers, fp,
            )
        if new.scheme.lower() != old.scheme.lower():
            raise urllib.error.HTTPError(
                newurl, code, "redirect changes scheme — refusing for safety",
                headers, fp,
            )
        if (new.hostname or "").lower() != (old.hostname or "").lower():
            raise urllib.error.HTTPError(
                newurl, code, "redirect changes host — refusing for safety",
                headers, fp,
            )
        return super().redirect_request(req, fp, code, msg, headers, newurl)


_SAFE_OPENER: urllib.request.OpenerDirector | None = None
_SAFE_OPENER_LOCK = threading.Lock()


def _get_safe_opener() -> urllib.request.OpenerDirector:
    """Return (and memoise) an OpenerDirector with cross-host redirects blocked.

    Thread-safe: the first call in a multi-threaded process would otherwise
    race and leak an extra opener instance. Double-checked locking keeps
    the steady-state fast path lock-free.
    """
    global _SAFE_OPENER
    opener = _SAFE_OPENER
    if opener is not None:
        return opener
    with _SAFE_OPENER_LOCK:
        # Re-check under the lock to close the race window. The ``is None``
        # branch covers the first thread; the ``is not None`` branch covers
        # every thread that lost the race AFTER the lock released. Both
        # sides are exercised by the threaded test but coverage branch
        # analysis is timing-sensitive on Linux runners, so the False side
        # is marked with ``no branch`` when the check misses.
        if _SAFE_OPENER is None:  # pragma: no branch - racing threads all see True on first call; False side covered only under a deliberate race condition exercised by test_get_safe_opener_is_thread_safe on machines that schedule it that way
            _SAFE_OPENER = urllib.request.build_opener(_StrictRedirectHandler())
        return _SAFE_OPENER


def _validate_scheme(url: str) -> None:
    """Reject URLs that are not plain HTTP(S). Raises :class:`DistributionError`."""
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme.lower() not in _ALLOWED_SCHEMES:
        raise DistributionError(
            f"refusing to fetch {url!r}: only http:// and https:// sources are "
            "allowed; Rove never follows file://, data: or other ambient URIs."
        )
    if not parsed.hostname:
        raise DistributionError(
            f"refusing to fetch {url!r}: URL has no host component"
        )


def _join_url(base: str, path: str) -> str:
    return base.rstrip("/") + "/" + path.lstrip("/")


def _http_get_bytes(
    url: str,
    *,
    connect_timeout: float,
    read_timeout: float,
    max_bytes: int = _MAX_MANIFEST_BYTES,
) -> bytes:
    """GET ``url`` and return the full response body.

    Uses the larger of the two timeouts as the urllib socket timeout (urllib
    only accepts a single value). Wraps transport errors in
    :class:`DistributionError`.

    Scheme allowlist (``http`` / ``https``) and a strict redirect handler
    mean that a malicious manifest cannot redirect the client off-host or
    switch to ``file://``.

    The response body is capped at ``max_bytes`` (default
    :data:`_MAX_MANIFEST_BYTES`). A peer that tries to stream gigabytes
    into our process is truncated and rejected with a
    :class:`DistributionError` — no unbounded ``resp.read()``.
    """
    _validate_scheme(url)
    timeout = max(connect_timeout, read_timeout)
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    opener = _get_safe_opener()
    try:
        with opener.open(req, timeout=timeout) as resp:
            # Short-circuit obviously oversized responses via Content-Length.
            # urllib exposes the header via .headers or .getheader().
            raw_len = resp.headers.get("Content-Length") if hasattr(resp, "headers") else None
            if raw_len is not None:
                try:
                    declared = int(raw_len)
                except ValueError:
                    declared = -1
                if declared > max_bytes:
                    raise DistributionError(
                        f"GET {url}: response Content-Length {declared} exceeds "
                        f"cap {max_bytes}; refusing to read."
                    )
            # Stream-read into a bounded buffer; abort if we pass the cap
            # (catches servers that lie about / omit Content-Length).
            buf = bytearray()
            chunk_size = 64 * 1024
            while True:
                chunk = resp.read(chunk_size)
                if not chunk:
                    break
                if len(buf) + len(chunk) > max_bytes:
                    raise DistributionError(
                        f"GET {url}: response body exceeded {max_bytes} bytes; "
                        "aborting to protect against oversized-response DoS."
                    )
                buf.extend(chunk)
            return bytes(buf)
    except urllib.error.HTTPError as exc:
        raise DistributionError(
            f"GET {url} → HTTP {exc.code} {exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise DistributionError(f"GET {url} unreachable: {exc.reason}") from exc
    except TimeoutError as exc:
        raise DistributionError(f"GET {url} timed out: {exc}") from exc


def _http_download_streaming(
    url: str,
    dest: Path,
    *,
    chunk_size: int,
    connect_timeout: float,
    read_timeout: float,
    resume_from: int,
    max_total_bytes: int | None = None,
) -> int:
    """Download ``url`` to ``dest`` with optional Range resume.

    Returns the number of bytes pulled over the wire on this call (does NOT
    include bytes already present from a previous partial download).

    When ``max_total_bytes`` is set, the on-disk size of ``dest`` plus the
    newly-written bytes is continuously checked; the download aborts with
    a :class:`DistributionError` as soon as the combined size exceeds the
    cap. This prevents disk-fill DoS by a peer that advertises a small
    ``compressed_size_bytes`` in the manifest but streams terabytes of
    payload instead.

    Raises:
        DistributionError: HTTP error, URL unreachable, unexpected status,
            or payload exceeds ``max_total_bytes``.
    """
    _validate_scheme(url)
    timeout = max(connect_timeout, read_timeout)
    headers: dict[str, str] = {"Accept": "application/octet-stream"}
    mode: str = "wb"
    if resume_from > 0:
        headers["Range"] = f"bytes={resume_from}-"
        mode = "ab"

    req = urllib.request.Request(url, headers=headers)
    opener = _get_safe_opener()
    bytes_pulled = 0
    try:
        with opener.open(req, timeout=timeout) as resp:
            status = resp.getcode()
            if status == 200 and resume_from > 0:
                # Server ignored Range; restart from scratch.
                logger.info(
                    "server ignored Range header for %s — restarting from 0",
                    url,
                )
                mode = "wb"
                resume_from = 0
            elif status not in (200, 206):
                raise DistributionError(
                    f"GET {url} → unexpected HTTP {status}"
                )

            # Size cap bookkeeping: start from the existing partial on disk
            # (``resume_from``) so a resumed download can still trip the
            # total cap if the peer inflates mid-flight.
            on_disk = resume_from if mode == "ab" else 0

            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, mode) as fh:
                while True:
                    chunk = resp.read(chunk_size)
                    if not chunk:
                        break
                    if max_total_bytes is not None and (
                        on_disk + bytes_pulled + len(chunk) > max_total_bytes
                    ):
                        raise DistributionError(
                            f"GET {url}: payload exceeded advertised size "
                            f"{max_total_bytes} bytes; aborting to protect "
                            "against disk-fill DoS."
                        )
                    fh.write(chunk)
                    bytes_pulled += len(chunk)
    except urllib.error.HTTPError as exc:
        raise DistributionError(
            f"GET {url} → HTTP {exc.code} {exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise DistributionError(f"GET {url} unreachable: {exc.reason}") from exc
    except TimeoutError as exc:
        raise DistributionError(f"GET {url} timed out: {exc}") from exc
    return bytes_pulled


def _download_with_retry(
    url: str,
    staging_path: Path,
    *,
    opts: FetchOptions,
    max_total_bytes: int | None = None,
) -> int:
    """Wrap :func:`_http_download_streaming` with exponential-backoff retry.

    Returns total bytes pulled across all attempts (ignoring bytes from
    previous fetch_bundle invocations stored in the partial file). On retry
    the next attempt picks up from the partial's current size, so progress
    is preserved.

    ``max_total_bytes`` (optional) propagates the size cap from the caller
    — see :func:`_http_download_streaming`.
    """
    last_error: DistributionError | None = None
    total_pulled = 0
    for attempt in range(opts.max_retries + 1):  # pragma: no branch - loop always exits via inner ``return`` (success) or ``break`` (exhaustion); natural iterator exhaustion is unreachable

        resume_from = staging_path.stat().st_size if staging_path.exists() else 0
        try:
            pulled = _http_download_streaming(
                url,
                staging_path,
                chunk_size=opts.chunk_size,
                connect_timeout=opts.connect_timeout,
                read_timeout=opts.read_timeout,
                resume_from=resume_from,
                max_total_bytes=max_total_bytes,
            )
            total_pulled += pulled
            return total_pulled
        except DistributionError as exc:
            last_error = exc
            if attempt >= opts.max_retries:
                break
            backoff = 2.0**attempt  # 1s, 2s, 4s
            logger.warning(
                "download attempt %d/%d failed (%s); retrying in %.1fs",
                attempt + 1,
                opts.max_retries + 1,
                exc,
                backoff,
            )
            time.sleep(backoff)
    assert last_error is not None
    raise last_error


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def fetch_bundle(opts: FetchOptions) -> FetchResult:
    """Download + verify a single bundle from an HTTP source.

    Steps:
      1. GET ``<source>/<bundle_name>.manifest.json`` and parse it.
      2. Verify the manifest signature (raises :class:`DistributionError`
         on failure or missing trust).
      3. Sanity-check the caller-supplied ``expected_sha256`` against the
         manifest, if provided.
      4. If the bundle already exists locally and its SHA-256 matches, return
         ``FetchResult(from_cache=True)`` without touching the network.
      5. Stream-download with Range-resume into a ``.part`` file, retrying
         on transient errors with exponential backoff.
      6. Verify the SHA-256 of the staged file; on mismatch, delete and raise.
      7. Atomically rename the staged file to its final name. Also write the
         manifest JSON next to the bundle.
    """
    output_dir = opts.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Manifest
    manifest_url = _join_url(opts.source, opts.bundle_name + _MANIFEST_SUFFIX)
    manifest_bytes = _http_get_bytes(
        manifest_url,
        connect_timeout=opts.connect_timeout,
        read_timeout=opts.read_timeout,
    )
    try:
        manifest = WheelhouseManifest.model_validate_json(manifest_bytes)
    except Exception as exc:
        raise DistributionError(
            f"manifest at {manifest_url} is not a valid WheelhouseManifest: {exc}"
        ) from exc

    # 2. Signature
    try:
        sig_ok = verify_manifest(manifest, additional_keys=opts.additional_pubkeys)
    except RuntimeSignatureError as exc:
        raise DistributionError(
            f"manifest signature verification failed for {manifest_url}: {exc}"
        ) from exc
    if not sig_ok:
        raise DistributionError(
            f"manifest signature does not match any trusted key "
            f"({manifest_url})"
        )

    # 3. SHA-256 sanity (caller-supplied vs manifest)
    expected_sha = (opts.expected_sha256 or manifest.tarball_sha256).lower()
    if opts.expected_sha256 is not None and expected_sha != manifest.tarball_sha256:
        raise DistributionError(
            f"expected_sha256 {expected_sha} does not match manifest "
            f"{manifest.tarball_sha256}"
        )

    # 4. Cache hit?
    bundle_path = output_dir / opts.bundle_name
    if bundle_path.exists():
        try:
            local_sha = sha256_file(bundle_path)
        except OSError as exc:
            raise DistributionError(
                f"cannot hash local cache file {bundle_path}: {exc}"
            ) from exc
        if local_sha == expected_sha:
            # Refresh manifest sidecar in case it changed; cheap and idempotent.
            _write_manifest_sidecar(bundle_path, manifest_bytes)
            return FetchResult(
                bundle_path=bundle_path,
                manifest=manifest,
                bytes_downloaded=0,
                from_cache=True,
            )
        logger.info(
            "local bundle %s sha mismatch (have=%s want=%s) — re-downloading",
            bundle_path,
            local_sha,
            expected_sha,
        )
        # Fall through to a fresh download (the .part flow will overwrite).

    # 5. Stream download with retries
    payload_url = _join_url(opts.source, opts.bundle_name)
    staging_path = bundle_path.with_suffix(bundle_path.suffix + _PARTIAL_SUFFIX)
    # Disk-fill DoS guard: peer that advertises N bytes but streams 1000xN
    # gets cut off. A small tolerance factor leaves room for chunked
    # frame overhead without rejecting legitimate bundles.
    max_bytes = int(manifest.compressed_size_bytes * _BUNDLE_SIZE_TOLERANCE)
    bytes_pulled = _download_with_retry(
        payload_url,
        staging_path,
        opts=opts,
        max_total_bytes=max_bytes,
    )

    # 6. Atomic move + verify final file in place.
    #
    # TOCTOU hardening: hashing a staging path and then renaming opens a
    # window where a local attacker with write access to the staging dir
    # could swap the payload between verify and rename. Rename first into
    # a holding path inside the final output dir (same filesystem, still
    # atomic), then hash the path we are about to expose. Any tampering
    # between rename and verify points at an OS-level compromise deeper
    # than anything Rove can meaningfully defend against.
    if bundle_path.exists():
        bundle_path.unlink()
    holding_path = bundle_path.with_name(bundle_path.name + _HOLDING_SUFFIX)
    if holding_path.exists():
        holding_path.unlink()
    os.replace(staging_path, holding_path)

    try:
        actual_sha = sha256_file(holding_path)
    except OSError as exc:  # pragma: no cover - the file was just created by os.replace inside output_dir; reading it back is expected to succeed. Defensive guard against concurrent deletion between the rename and the hash (exotic filesystems / antivirus).
        holding_path.unlink(missing_ok=True)
        raise DistributionError(
            f"cannot hash holding file {holding_path}: {exc}"
        ) from exc
    if actual_sha != expected_sha:
        holding_path.unlink(missing_ok=True)
        raise DistributionError(
            f"bundle SHA-256 mismatch after download: have={actual_sha} "
            f"want={expected_sha}. Rejected file discarded — retry."
        )

    os.replace(holding_path, bundle_path)
    _write_manifest_sidecar(bundle_path, manifest_bytes)

    return FetchResult(
        bundle_path=bundle_path,
        manifest=manifest,
        bytes_downloaded=bytes_pulled,
        from_cache=False,
    )


def _write_manifest_sidecar(bundle_path: Path, manifest_bytes: bytes) -> None:
    """Write ``<bundle>.manifest.json`` next to a downloaded bundle."""
    sidecar = bundle_path.with_name(bundle_path.name + _MANIFEST_SUFFIX)
    tmp = sidecar.with_suffix(sidecar.suffix + ".tmp")
    tmp.write_bytes(manifest_bytes)
    os.replace(tmp, sidecar)


# ---------------------------------------------------------------------------
# Backend adapter
# ---------------------------------------------------------------------------
class HttpDistributionBackend:
    """HTTP implementation of :class:`rove.distribution.plugin.DistributionBackend`.

    ``publish`` is a passive no-op for this backend: the assumption is that
    a :class:`rove.distribution.http_server.RoveHttpServer` is already
    exposing the bundle directory; this adapter just returns the
    pre-configured ``source`` URL so peers can ``fetch`` from it.

    For ``fetch``, callers MUST pass a concrete ``version`` for V1 — auto
    discovery via an ``index.json`` is intentionally deferred.
    """

    def __init__(
        self,
        *,
        source: str | None = None,
        output_dir: Path | None = None,
        additional_pubkeys: list[Path] | None = None,
    ) -> None:
        """Args:
            source: Base URL of a peer's :class:`RoveHttpServer`. Required
                for :meth:`fetch`; optional for :meth:`publish` (which is
                a no-op anyway).
            output_dir: Local directory where fetched bundles land. If
                ``None``, callers must use :func:`fetch_bundle` directly.
            additional_pubkeys: Trusted Ed25519 PEM paths forwarded to
                :func:`rove.signing.ed25519.verify_manifest`.
        """
        self._source = source
        self._output_dir = output_dir
        self._additional_pubkeys: list[Path] = list(additional_pubkeys or [])

    # ------------------------------------------------------------------
    # DistributionBackend protocol
    # ------------------------------------------------------------------
    def publish(self, manifest: WheelhouseManifest, payload: Path) -> str:
        """Return the configured ``source`` URL — does NOT push the bundle.

        This backend is passive: it expects ``payload`` to already live in
        a directory exposed by a separately-running
        :class:`RoveHttpServer`. Use a different backend (Iroh, S3, ...)
        for active publication.

        Raises:
            DistributionError: ``source`` was not configured.
        """
        if not self._source:
            raise DistributionError(
                "HttpDistributionBackend.publish requires a configured "
                "``source`` URL — pass one to the constructor."
            )
        return self._source

    def fetch(
        self,
        target: Target,
        version: str | None = None,
    ) -> tuple[WheelhouseManifest, Path]:
        """Fetch a bundle for ``target`` at ``version`` from the configured source.

        V1 limitation: ``version`` is REQUIRED. Auto-discovery via
        ``<source>/index.json`` is deferred. The bundle name is derived as
        ``rove-<target>-<version>.tar.xz`` — change at the call site if your
        builder uses a different convention.
        """
        if not self._source:
            raise DistributionError(
                "HttpDistributionBackend.fetch requires a configured "
                "``source`` URL — pass one to the constructor."
            )
        if not self._output_dir:
            raise DistributionError(
                "HttpDistributionBackend.fetch requires ``output_dir`` — "
                "pass one to the constructor or call fetch_bundle directly."
            )
        if version is None:
            raise DistributionError(
                "version required for V1 — auto-discovery deferred"
            )

        bundle_name = f"rove-{target.value}-{version}.tar.xz"
        result = fetch_bundle(
            FetchOptions(
                source=self._source,
                bundle_name=bundle_name,
                output_dir=self._output_dir,
                additional_pubkeys=self._additional_pubkeys,
            )
        )
        return result.manifest, result.bundle_path



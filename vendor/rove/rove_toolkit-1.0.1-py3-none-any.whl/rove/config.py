"""Rove configuration loader.

Reads ``[tool.rove]`` from a ``pyproject.toml`` or a stand-alone
``rove.toml`` file. The schema is intentionally small and explicit —
Rove is a build tool; surprising defaults make builds non-reproducible.

Public API:

* :class:`RoveConfig` — Pydantic model of the parsed config.
* :class:`ConfigError` — raised on any structural / value problem.
* :func:`load`        — locate + parse + merge config files.
"""
from __future__ import annotations

import os
import re
import tomllib
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from rove.targets import Target
from rove.targets import parse as parse_target

__all__ = ["ConfigError", "RoveConfig", "load"]


class ConfigError(ValueError):
    """Raised on any Rove config problem (missing file, bad value, ...)."""


_PROJECT_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")
_ENV_VAR_RE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class RoveConfig(BaseModel):
    """Parsed ``[tool.rove]`` section.

    All fields have defaults except ``project_name`` so a minimal
    ``rove.toml`` can be ``project_name = "foo"``.
    """

    # ``extra="forbid"``: reject unknown keys so typos like ``requrements``
    # fail the build instead of silently dropping a field and producing a
    # bundle with empty requirements.
    model_config = ConfigDict(extra="forbid")

    project_name: str = Field(
        ...,
        min_length=1,
        description=(
            "Project identifier — lowercase letters, digits, dots, hyphens "
            "and underscores; must start with [a-z0-9]."
        ),
    )
    version: str = Field(
        default="0.0.0",
        min_length=1,
        description="Project version (defaults to 0.0.0 if unset).",
    )
    include: list[str] = Field(
        default_factory=lambda: ["src"],
        description="Globs/paths bundled into the wheelhouse.",
    )
    exclude: list[str] = Field(
        default_factory=lambda: ["tests/", "*.pyc", "__pycache__/"],
        description="Globs/paths excluded from the bundle.",
    )
    targets: list[Target] = Field(
        default_factory=lambda: [Target.host],
        description="Targets to build for.",
    )
    patches: list[str] = Field(
        default_factory=list,
        description="Named patch sets to apply during the build.",
    )
    sign_key: str | None = Field(
        default=None,
        description=(
            "Path or identifier of the Ed25519 signing key. "
            "Supports ``${ENV_VAR}`` expansion at load time."
        ),
    )
    requirements: list[str] | None = Field(
        default=None,
        description=(
            "Explicit dependency pin list. When set, overrides the "
            "``[project].dependencies`` from pyproject."
        ),
    )

    @field_validator("project_name")
    @classmethod
    def _validate_project_name(cls, v: str) -> str:
        if not _PROJECT_NAME_RE.match(v):
            raise ValueError(
                f"project_name {v!r} must match {_PROJECT_NAME_RE.pattern} "
                "(lowercase letters, digits, dots, hyphens, underscores; "
                "must start with [a-z0-9])"
            )
        return v

    @field_validator("targets", mode="before")
    @classmethod
    def _coerce_targets(cls, v: Any) -> Any:
        if v is None:
            return v
        if not isinstance(v, list):
            raise ValueError("targets must be a list of strings")
        out: list[Target] = []
        for entry in v:
            if isinstance(entry, Target):
                out.append(entry)
            elif isinstance(entry, str):
                out.append(parse_target(entry))
            else:
                raise ValueError(
                    f"target entry must be str or Target, got {type(entry).__name__}"
                )
        return out


def _read_toml(path: Path) -> dict[str, Any]:
    try:
        with path.open("rb") as fh:
            return tomllib.load(fh)
    except OSError as exc:
        raise ConfigError(f"cannot read {path}: {exc}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"invalid TOML in {path}: {exc}") from exc


def _expand_env(value: str) -> str:
    """Expand ``${VAR}`` syntax; raise if any referenced var is unset."""
    missing: list[str] = []

    def _sub(match: re.Match[str]) -> str:
        name = match.group(1)
        env_value = os.environ.get(name)
        if env_value is None:
            missing.append(name)
            return ""
        return env_value

    expanded = _ENV_VAR_RE.sub(_sub, value)
    if missing:
        raise ConfigError(
            f"sign_key references unset environment variable(s): "
            f"{', '.join(sorted(set(missing)))}"
        )
    return expanded


def _search_upward(start: Path) -> Path | None:
    """Walk upward from ``start`` looking for ``rove.toml`` or ``pyproject.toml``."""
    current = start.resolve()
    while True:
        rove_toml = current / "rove.toml"
        if rove_toml.is_file():
            return rove_toml
        pyproject = current / "pyproject.toml"
        if pyproject.is_file():
            return pyproject
        if current.parent == current:
            return None
        current = current.parent


def load(
    config_path: Path | None = None,
    *,
    project_root: Path | None = None,
) -> RoveConfig:
    """Locate, parse, and merge a Rove config file.

    Args:
        config_path: Explicit path to a ``rove.toml`` or ``pyproject.toml``.
            When ``None``, walks upward from ``project_root`` (or cwd) until
            one is found.
        project_root: Directory to start the upward search from. Defaults
            to the current working directory.

    Returns:
        Parsed :class:`RoveConfig`.

    Raises:
        FileNotFoundError: No config file found by upward search.
        ConfigError: TOML invalid, schema violation, or unset env var
            referenced by ``sign_key``.
    """
    if config_path is None:
        start = project_root if project_root is not None else Path.cwd()
        found = _search_upward(start)
        if found is None:
            raise FileNotFoundError(
                "no rove.toml or pyproject.toml found in "
                f"{start} or any parent directory"
            )
        config_path = found
    elif not config_path.is_file():
        raise FileNotFoundError(f"config file does not exist: {config_path}")

    data = _read_toml(config_path)

    pyproject_project: dict[str, Any] = {}
    if config_path.name == "pyproject.toml":
        raw_project = data.get("project")
        if isinstance(raw_project, dict):
            pyproject_project = raw_project

    raw_tool = data.get("tool", {})
    if not isinstance(raw_tool, dict):
        raise ConfigError(f"[tool] in {config_path} must be a table")
    raw_rove = raw_tool.get("rove", {})
    if not isinstance(raw_rove, dict):
        raise ConfigError(f"[tool.rove] in {config_path} must be a table")

    # If config is a stand-alone rove.toml (no [tool.rove] wrapper), the
    # top level is itself the rove section.
    if config_path.name == "rove.toml" and not raw_rove:
        raw_rove = {k: v for k, v in data.items() if k != "tool"}

    merged: dict[str, Any] = {}
    if pyproject_project:
        if "name" in pyproject_project:
            merged["project_name"] = pyproject_project["name"]
        if "version" in pyproject_project:
            merged["version"] = pyproject_project["version"]
        deps = pyproject_project.get("dependencies")
        if isinstance(deps, list):
            merged["requirements"] = list(deps)

    # [tool.rove] wins over pyproject [project] on overlap.
    merged.update(raw_rove)

    sign_key = merged.get("sign_key")
    if isinstance(sign_key, str):
        merged["sign_key"] = _expand_env(sign_key)

    try:
        return RoveConfig(**merged)
    except ConfigError:  # pragma: no cover - defensive: Pydantic wraps validator errors in ValidationError, never re-raises a bare ConfigError
        raise
    except Exception as exc:
        raise ConfigError(f"invalid Rove config in {config_path}: {exc}") from exc

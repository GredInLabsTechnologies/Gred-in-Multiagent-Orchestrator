"""
Rove command-line interface.

Exposes the user-facing ``rove`` entry point declared in
``pyproject.toml`` (``[project.scripts] rove = "rove.cli:main"``).

Subcommands:

* ``rove keygen``   — generate an Ed25519 signing keypair.
* ``rove build``    — assemble a wheelhouse bundle for a target.
* ``rove sign``     — sign an already-built bundle's manifest.
* ``rove verify``   — verify a bundle's tarball + manifest signature.
* ``rove serve``    — serve a directory of bundles over HTTP (V1 stub).
* ``rove fetch``    — download a bundle + manifest and verify it.

The CLI uses :mod:`typer` for argument parsing and :mod:`rich` for
status output. Any unrecoverable error exits with a non-zero code via
:class:`typer.Exit`.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from rove import __version__
from rove.builder.patches import (
    PatchApplyError,
    apply_env_patches,
    read_toml_overrides,
)
from rove.builder.pip_runner import PipError, PipRunOptions, run_pip_download
from rove.builder.python_standalone import (
    StandaloneFetchError,
    fetch_standalone_python,
)
from rove.builder.tarball import (
    TarballBuildError,
    TarballBuildOptions,
    build_tarball,
)
from rove.builder.zig import ZigNotFoundError, build_env_for
from rove.config import ConfigError, RoveConfig, load
from rove.distribution.http_fetcher import FetchOptions, fetch_bundle
from rove.distribution.http_server import HttpServerOptions
from rove.distribution.http_server import serve as http_serve
from rove.distribution.plugin import DistributionError
from rove.manifest import WheelhouseManifest
from rove.patches.loader import (
    PatchEntry,
    PatchKind,
    PatchLoadError,
    load_patch_set,
    resolve_patches,
)
from rove.signing.ed25519 import (
    RuntimeSignatureError,
    sha256_file,
    sign_manifest,
    verify_manifest,
)
from rove.signing.keygen import generate_keypair
from rove.targets import Compression, Target
from rove.targets import parse as parse_target
from rove.targets import resolve as resolve_target

__all__ = ["app", "main"]

console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    no_args_is_help=True,
    add_completion=False,
    help="Rove — deterministic wheelhouse builder.",
    rich_markup_mode="rich",
)


def _version_callback(value: bool) -> None:
    """Print the package version and exit, for ``rove --version``."""
    if value:
        console.print(f"rove {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            help="Print the rove version and exit.",
            callback=_version_callback,
            is_eager=True,
        ),
    ] = None,
) -> None:
    """Root callback — exposes the top-level ``--version`` flag."""
    del version  # consumed by callback

_REQ_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*")


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
def _ok(msg: str) -> None:
    # ASCII-only markers so the legacy Windows console (cp1252) doesn't crash
    # on the U+2713 / U+2717 glyphs Rich would otherwise emit. UTF-8 terminals
    # see the same prefix; no information lost.
    console.print(f"[green][ok][/green] {msg}")


def _info(msg: str) -> None:
    console.print(msg)


def _warn(msg: str) -> None:
    err_console.print(f"[yellow][warn][/yellow] {msg}")


def _fail(msg: str, *, code: int = 1) -> typer.Exit:
    err_console.print(f"[red][fail][/red] {msg}")
    return typer.Exit(code=code)


def _parse_target_str(value: str) -> Target:
    try:
        return parse_target(value)
    except ValueError as exc:
        raise typer.BadParameter(str(exc)) from exc


def _parse_compression(value: str) -> Compression:
    norm = value.strip().lower()
    if norm in ("xz",):
        return Compression.xz
    if norm in ("zstd", "zst"):
        return Compression.zstd
    if norm in ("none", "tar", ""):
        return Compression.none
    raise typer.BadParameter(
        f"unknown compression {value!r}; expected one of: xz, zstd, none"
    )


def _requirement_package(spec: str) -> str:
    """Extract the bare package name from a requirement string."""
    match = _REQ_NAME_RE.match(spec.strip())
    if not match:
        return spec.strip()
    return match.group(0).lower()


def _python_executable_for(python_root: Path | None) -> Path:
    """Locate a usable interpreter for ``pip download``.

    When a standalone python tree is available, prefer it (so cross
    builds use the bundled interpreter). Otherwise fall back to the
    interpreter currently running rove.
    """
    if python_root is not None:
        for rel in ("bin/python3", "bin/python3.13", "bin/python", "python.exe"):
            candidate = python_root / rel
            if candidate.exists():
                return candidate
    return Path(sys.executable)


def _manifest_path_for(bundle: Path) -> Path:
    """Conventional manifest sibling: ``<bundle>.manifest.json``."""
    return bundle.with_name(bundle.name + ".manifest.json")


def _load_manifest(path: Path) -> WheelhouseManifest:
    if not path.is_file():
        raise _fail(f"manifest file does not exist: {path}", code=2)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise _fail(f"cannot parse manifest {path}: {exc}", code=2) from exc
    try:
        return WheelhouseManifest.model_validate(data)
    except Exception as exc:
        raise _fail(f"manifest {path} failed schema validation: {exc}", code=2) from exc


def _write_manifest(manifest: WheelhouseManifest, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = manifest.model_dump(mode="json")
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------
@app.command("keygen")
def keygen_cmd(
    out: Annotated[
        Path,
        typer.Option(
            "--out",
            "-o",
            help="Directory to write private.pem + public.pem into.",
            file_okay=False,
            dir_okay=True,
            resolve_path=True,
        ),
    ],
    overwrite: Annotated[
        bool,
        typer.Option(
            "--overwrite",
            help="Overwrite existing key files instead of failing.",
        ),
    ] = False,
) -> None:
    """Generate an Ed25519 signing keypair."""
    try:
        priv, pub = generate_keypair(out, overwrite=overwrite)
    except FileExistsError as exc:
        raise _fail(str(exc), code=1) from exc
    except OSError as exc:
        raise _fail(f"failed to write keypair: {exc}", code=1) from exc

    _ok(f"private key: {priv}")
    _ok(f"public  key: {pub}")


@app.command("build")
def build_cmd(
    target: Annotated[
        str,
        typer.Option(
            "--target",
            "-t",
            help="Target tuple (e.g. linux-x86_64, host).",
        ),
    ],
    config_path: Annotated[
        Path | None,
        typer.Option(
            "--config",
            "-c",
            help="Path to rove.toml or pyproject.toml. Auto-detected if omitted.",
            exists=False,
            dir_okay=False,
        ),
    ] = None,
    output: Annotated[
        Path,
        typer.Option(
            "--output",
            "-o",
            help="Output directory for the produced bundle + manifest.",
            file_okay=False,
        ),
    ] = Path("dist"),
    python_version: Annotated[
        str,
        typer.Option(
            "--python-version",
            help="CPython version (short '3.13' or full '3.13.13').",
        ),
    ] = "3.13",
    patch_set: Annotated[
        Path | None,
        typer.Option(
            "--patch-set",
            help="Path to a rove-patches directory or manifest.json.",
            exists=False,
        ),
    ] = None,
    no_python: Annotated[
        bool,
        typer.Option(
            "--no-python",
            help="Skip bundling python-build-standalone (consumer provides it).",
        ),
    ] = False,
    compression: Annotated[
        str,
        typer.Option(
            "--compression",
            help="Compression algorithm: xz | zstd | none.",
        ),
    ] = "xz",
) -> None:
    """Build a wheelhouse bundle for ``--target``."""
    parsed_target = _parse_target_str(target)
    compression_enum = _parse_compression(compression)

    # 1. Load config.
    try:
        cfg: RoveConfig = load(config_path)
    except FileNotFoundError as exc:
        raise _fail(str(exc), code=2) from exc
    except ConfigError as exc:
        raise _fail(f"config error: {exc}", code=2) from exc

    # 2. Resolve target.
    resolved = resolve_target(parsed_target)
    _info(f"target: [bold]{resolved.value}[/bold]  project: [bold]{cfg.project_name}[/bold]")

    # 3. Optionally fetch python-build-standalone.
    python_root: Path | None = None
    if not no_python:
        try:
            python_root = fetch_standalone_python(
                resolved, python_version=python_version
            )
        except NotImplementedError as exc:
            raise _fail(
                f"{exc}. Run with --no-python and provide an Android-compatible "
                "interpreter via the rove-patches workflow.",
                code=2,
            ) from exc
        except StandaloneFetchError as exc:
            raise _fail(f"failed to fetch standalone CPython: {exc}", code=1) from exc
        _ok(f"python-build-standalone: {python_root}")
    else:
        _info("skipping python-build-standalone (--no-python)")

    # 4. Resolve dependency list.
    requirements = list(cfg.requirements or [])
    if not requirements:
        raise _fail(
            "no requirements declared (set [tool.rove].requirements or "
            "[project].dependencies in your pyproject.toml).",
            code=2,
        )

    # 5. Patches (best-effort env + toml; diff patches deferred).
    extra_env: dict[str, str] = {}
    patches_applied: list[str] = []
    if patch_set is not None:
        if not patch_set.exists():
            raise _fail(f"patch set does not exist: {patch_set}", code=2)
        try:
            ps = load_patch_set(patch_set)
        except PatchLoadError as exc:
            raise _fail(f"failed to load patch set {patch_set}: {exc}", code=1) from exc

        package_names = [_requirement_package(r) for r in requirements]
        resolved_patches: list[PatchEntry] = resolve_patches(
            ps, packages=package_names, target=resolved
        )

        diff_entries = [p for p in resolved_patches if p.kind is PatchKind.patch]
        if diff_entries:
            _warn(
                f"{len(diff_entries)} unified-diff patch(es) deferred — "
                "diff application against unpacked sdists is not implemented in V1."
            )

        non_diff_entries = [p for p in resolved_patches if p.kind is not PatchKind.patch]
        patch_set_root = patch_set.parent if patch_set.is_file() else patch_set
        try:
            env_overrides = apply_env_patches(non_diff_entries, patch_set_root)
            toml_overrides = read_toml_overrides(non_diff_entries, patch_set_root)
        except PatchApplyError as exc:
            raise _fail(f"patch application failed: {exc}", code=1) from exc

        if env_overrides:
            extra_env.update(env_overrides)
        if toml_overrides:
            _info(f"toml overrides parsed: {len(toml_overrides)}")
        patches_applied = [p.id for p in resolved_patches]
        if patches_applied:
            _ok(f"patches resolved: {len(patches_applied)}")

    # 6. Cross-compile env from Zig (when not building for the host).
    cross_env: dict[str, str] = {}
    host_target = None
    try:
        from rove.targets import detect_host as _detect_host

        host_target = _detect_host()
    except RuntimeError:
        host_target = None

    if host_target is None or resolved is not host_target:
        try:
            zig_env = build_env_for(resolved)
            cross_env.update(zig_env.extra_env)
            cross_env.setdefault("CC", zig_env.cc)
            cross_env.setdefault("CXX", zig_env.cxx)
            cross_env.setdefault("AR", zig_env.ar)
            _ok(f"zig cross env ready (cargo target: {zig_env.cargo_build_target})")
        except (ZigNotFoundError, ValueError) as exc:
            _warn(
                f"zig cross env unavailable ({exc}); pip will attempt prebuilt wheels only."
            )

    # 7. Run pip download into a temp wheelhouse.
    tmp_wheels = Path(tempfile.mkdtemp(prefix="rove-wheels-"))
    try:
        merged_env = {**cross_env, **extra_env}
        pip_opts = PipRunOptions(
            requirements=requirements,
            target=resolved,
            python_executable=_python_executable_for(python_root),
            output_dir=tmp_wheels,
            prefer_binary=True,
            extra_env=merged_env,
        )
        try:
            pip_result = run_pip_download(pip_opts)
        except PipError as exc:
            raise _fail(f"pip download failed: {exc}", code=1) from exc
        _ok(f"wheels downloaded: {len(pip_result.wheels_collected)}")

        # 8. Build the tarball.
        project_root = (config_path.parent if config_path else Path.cwd()).resolve()
        runtime_version = cfg.version

        try:
            opts = TarballBuildOptions(
                project_name=cfg.project_name,
                runtime_version=runtime_version,
                target=resolved,
                compression=compression_enum,
                output_dir=output.resolve(),
                python_root=python_root,
                wheels_dir=tmp_wheels,
                project_root=project_root,
                include=cfg.include,
                exclude=cfg.exclude,
                extra_env=extra_env,
                patches_applied=patches_applied,
                python_version=python_version if not no_python else None,
                builder_id=os.environ.get("ROVE_BUILDER_ID"),
            )
            result = build_tarball(opts)
        except TarballBuildError as exc:
            raise _fail(f"tarball build failed: {exc}", code=1) from exc

        manifest_path = _manifest_path_for(result.tarball_path)
        _write_manifest(result.manifest, manifest_path)

        _ok(f"bundle:   {result.tarball_path}")
        _ok(f"manifest: {manifest_path}")
        _info(
            f"size: {result.compressed_size_bytes:,} bytes compressed "
            f"({result.uncompressed_size_bytes:,} uncompressed)"
        )
        _info(f"sha256: {result.manifest.tarball_sha256}")
    finally:
        shutil.rmtree(tmp_wheels, ignore_errors=True)


@app.command("sign")
def sign_cmd(
    bundle: Annotated[
        Path,
        typer.Option(
            "--bundle",
            "-b",
            help="Path to the produced tarball.",
            exists=True,
            dir_okay=False,
            resolve_path=True,
        ),
    ],
    key: Annotated[
        Path,
        typer.Option(
            "--key",
            "-k",
            help="Path to the Ed25519 private key PEM.",
            exists=True,
            dir_okay=False,
            resolve_path=True,
        ),
    ],
    output: Annotated[
        Path | None,
        typer.Option(
            "--output",
            "-o",
            help="Where to write the signed manifest. Defaults to <bundle>.sig.",
        ),
    ] = None,
) -> None:
    """Sign an existing bundle's manifest with an Ed25519 private key."""
    manifest_path = _manifest_path_for(bundle)
    if not manifest_path.is_file():
        raise _fail(
            f"manifest not found next to bundle: expected {manifest_path}", code=2
        )

    manifest = _load_manifest(manifest_path)

    # Re-derive the tarball SHA-256 to ensure the manifest matches the
    # on-disk tarball before signing.
    actual_sha = sha256_file(bundle)
    if actual_sha != manifest.tarball_sha256:
        raise _fail(
            f"refusing to sign: tarball sha256 mismatch (manifest={manifest.tarball_sha256} "
            f"actual={actual_sha})",
            code=1,
        )

    try:
        signed = sign_manifest(manifest, key)
    except RuntimeSignatureError as exc:
        raise _fail(f"signing failed: {exc}", code=1) from exc

    out_path = output if output is not None else bundle.with_name(bundle.name + ".sig")
    _write_manifest(signed, out_path)
    # Also overwrite the canonical manifest sibling so subsequent
    # ``verify`` runs pick it up by default.
    _write_manifest(signed, manifest_path)

    _ok(f"signed manifest: {out_path}")
    _ok(f"updated:         {manifest_path}")


@app.command("verify")
def verify_cmd(
    bundle: Annotated[
        Path,
        typer.Option(
            "--bundle",
            "-b",
            help="Path to the bundle tarball to verify.",
            exists=True,
            dir_okay=False,
            resolve_path=True,
        ),
    ],
    pubkey: Annotated[
        list[Path] | None,
        typer.Option(
            "--pubkey",
            "-p",
            help=(
                "Additional Ed25519 public key(s) to trust for this verification. "
                "Repeat the flag to pass several. Env- and user-dir-trusted keys "
                "are still consulted."
            ),
        ),
    ] = None,
) -> None:
    """Verify a bundle's tarball SHA-256 and Ed25519 signature."""
    manifest_path = _manifest_path_for(bundle)
    if not manifest_path.is_file():
        raise _fail(
            f"manifest not found next to bundle: expected {manifest_path}", code=2
        )

    manifest = _load_manifest(manifest_path)

    actual_sha = sha256_file(bundle)
    if actual_sha != manifest.tarball_sha256:
        raise _fail(
            f"sha256 mismatch: manifest={manifest.tarball_sha256} actual={actual_sha}",
            code=1,
        )
    _ok(f"sha256 ok: {actual_sha}")

    try:
        ok = verify_manifest(manifest, additional_keys=list(pubkey or []))
    except RuntimeSignatureError as exc:
        raise _fail(f"signature verification error: {exc}", code=1) from exc

    if not ok:
        raise _fail("signature did not match any trusted key", code=1)
    _ok("signature ok")
    _ok(f"bundle verified: {bundle}")


@app.command("serve")
def serve_cmd(
    bundle_dir: Annotated[
        Path,
        typer.Option(
            "--bundle-dir",
            "-d",
            help="Directory of bundles to serve.",
            exists=True,
            file_okay=False,
            resolve_path=True,
        ),
    ],
    port: Annotated[int, typer.Option("--port", help="TCP port to bind.")] = 8080,
    host: Annotated[
        str, typer.Option("--host", help="Host/interface to bind.")
    ] = "0.0.0.0",
) -> None:
    """Serve a directory of bundles with HTTP Range support."""
    _info(f"serving {bundle_dir} on http://{host}:{port}/  (Ctrl-C to stop)")
    try:
        http_serve(HttpServerOptions(bundle_dir=bundle_dir, host=host, port=port))
    except KeyboardInterrupt:
        raise typer.Exit(code=0) from None
    except DistributionError as exc:
        raise _fail(str(exc), code=1) from exc


@app.command("fetch")
def fetch_cmd(
    src: Annotated[
        str,
        typer.Option(
            "--from",
            help="Base URL hosting <bundle> + <bundle>.manifest.json.",
        ),
    ],
    target: Annotated[
        str,
        typer.Option(
            "--target",
            "-t",
            help="Target tuple of the bundle to fetch.",
        ),
    ],
    out: Annotated[
        Path,
        typer.Option(
            "--out",
            "-o",
            help="Local directory to download the bundle into.",
            file_okay=False,
        ),
    ],
    pubkey: Annotated[
        Path | None,
        typer.Option(
            "--pubkey",
            "-p",
            help="Optional public key PEM trusted for this fetch.",
        ),
    ] = None,
    project_name: Annotated[
        str | None,
        typer.Option(
            "--project-name",
            help="Project name (defaults to inferred from the URL).",
        ),
    ] = None,
    runtime_version: Annotated[
        str | None,
        typer.Option(
            "--runtime-version",
            help="Bundle version (required to build the canonical filename).",
        ),
    ] = None,
    compression: Annotated[
        str,
        typer.Option(
            "--compression",
            help="Compression of the remote bundle (xz|zstd|none).",
        ),
    ] = "xz",
) -> None:
    """Download ``<bundle>`` + ``<bundle>.manifest.json`` and verify locally."""
    parsed_target = _parse_target_str(target)
    # Resolve ``host`` to the concrete target of the current machine,
    # matching what ``rove build`` does. Without this, ``rove fetch
    # --target host`` asks the server for a file literally named
    # ``foo-host-0.1.0.tar.xz`` which no builder ever produces.
    resolved_target = resolve_target(parsed_target)
    compression_enum = _parse_compression(compression)

    if not project_name or not runtime_version:
        raise typer.BadParameter(
            "both --project-name and --runtime-version are required to "
            "construct the canonical bundle filename"
        )

    ext_map = {Compression.xz: "tar.xz", Compression.zstd: "tar.zst", Compression.none: "tar"}
    ext = ext_map[compression_enum]
    bundle_name = f"{project_name}-{resolved_target.value}-{runtime_version}.{ext}"

    out.mkdir(parents=True, exist_ok=True)
    _info(f"fetching {bundle_name} from {src}")
    try:
        result = fetch_bundle(
            FetchOptions(
                source=src,
                bundle_name=bundle_name,
                output_dir=out,
                additional_pubkeys=[pubkey] if pubkey else [],
            )
        )
    except DistributionError as exc:
        raise _fail(str(exc), code=1) from exc
    except RuntimeSignatureError as exc:
        raise _fail(f"signature verification error: {exc}", code=1) from exc

    if result.from_cache:
        _ok(f"already on disk + verified: {result.bundle_path}")
    else:
        _ok(f"downloaded {result.bytes_downloaded} bytes")
    _ok(f"sha256 ok: {result.manifest.tarball_sha256}")
    _ok(f"signature ok — bundle ready at {result.bundle_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def main() -> None:
    """Typer entrypoint referenced by ``[project.scripts] rove``."""
    app()


if __name__ == "__main__":  # pragma: no cover - script entry
    main()

"""Rove — cross-platform peer-built signed wheelhouse forge.

See :mod:`rove.cli` for the command-line entrypoint and
:mod:`rove.manifest` for the canonical manifest schema.
"""

__version__ = "1.0.0"

__all__ = ["__version__"]

"""
Rove Target tuples and host detection.

Targets follow the python-build-standalone convention ``<os>-<arch>``
(e.g. ``linux-x86_64``, ``android-arm64``, ``windows-x86_64``). String
values are stable across Rove releases so that bundle manifests
produced by older versions remain readable.

A special sentinel value ``Target.host`` represents "whatever the
current machine is"; it must be resolved to a concrete target via
:func:`resolve` (or :func:`detect_host`) before being persisted into a
manifest.
"""
from __future__ import annotations

import platform
from enum import StrEnum


class Target(StrEnum):
    """Supported hardware/OS tuples.

    Values follow the python-build-standalone convention ``<os>-<arch>``.
    The ``host`` member is a sentinel meaning "the current machine"; it
    must be resolved with :func:`resolve` to a concrete target before
    use in a manifest or build artifact.
    """

    android_arm64 = "android-arm64"
    android_armv7 = "android-armv7"
    android_x86_64 = "android-x86_64"
    linux_x86_64 = "linux-x86_64"
    linux_arm64 = "linux-arm64"
    darwin_arm64 = "darwin-arm64"
    darwin_x86_64 = "darwin-x86_64"
    windows_x86_64 = "windows-x86_64"
    host = "host"


class Compression(StrEnum):
    """Compression algorithm applied to a wheelhouse tarball."""

    xz = "xz"
    zstd = "zstd"
    none = "none"


# Aliases accepted by :func:`parse`. Keys are normalized (lowercase,
# hyphens collapsed to underscores) before lookup; values are the
# canonical Target member names.
_ALIASES: dict[str, Target] = {
    # Android
    "android_arm64": Target.android_arm64,
    "android_aarch64": Target.android_arm64,
    "android_arm8": Target.android_arm64,
    "android_armv7": Target.android_armv7,
    "android_arm": Target.android_armv7,
    "android_armv7a": Target.android_armv7,
    "android_armeabi_v7a": Target.android_armv7,
    "android_x86_64": Target.android_x86_64,
    "android_x64": Target.android_x86_64,
    "android_amd64": Target.android_x86_64,
    # Linux
    "linux_x86_64": Target.linux_x86_64,
    "linux_x64": Target.linux_x86_64,
    "linux_amd64": Target.linux_x86_64,
    "linux_arm64": Target.linux_arm64,
    "linux_aarch64": Target.linux_arm64,
    # macOS
    "darwin_arm64": Target.darwin_arm64,
    "darwin_aarch64": Target.darwin_arm64,
    "macos_arm64": Target.darwin_arm64,
    "macos_aarch64": Target.darwin_arm64,
    "darwin_x86_64": Target.darwin_x86_64,
    "darwin_x64": Target.darwin_x86_64,
    "darwin_amd64": Target.darwin_x86_64,
    "macos_x86_64": Target.darwin_x86_64,
    "macos_x64": Target.darwin_x86_64,
    # Windows
    "windows_x86_64": Target.windows_x86_64,
    "windows_x64": Target.windows_x86_64,
    "windows_amd64": Target.windows_x86_64,
    "win_x86_64": Target.windows_x86_64,
    "win_x64": Target.windows_x86_64,
    "win_amd64": Target.windows_x86_64,
    # Sentinel
    "host": Target.host,
    "current": Target.host,
    "native": Target.host,
}


def detect_host() -> Target:
    """Return the concrete :class:`Target` matching the current machine.

    Inspects :func:`platform.system` and :func:`platform.machine` to map
    the running interpreter to a concrete target value. Never returns
    :attr:`Target.host` — callers that want the sentinel should use it
    directly.

    Raises:
        RuntimeError: if the running platform is not in the supported
            target matrix. Cross-platform builds are produced on CI; the
            host detector intentionally rejects unknown combinations
            instead of guessing.
    """
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == "linux":
        if machine in ("x86_64", "amd64"):
            return Target.linux_x86_64
        if machine in ("aarch64", "arm64"):
            return Target.linux_arm64
    elif system == "darwin":
        if machine in ("arm64", "aarch64"):
            return Target.darwin_arm64
        if machine in ("x86_64", "amd64"):
            return Target.darwin_x86_64
    elif system == "windows":
        if machine in ("amd64", "x86_64"):
            return Target.windows_x86_64
        # Windows on ARM64 (Surface Pro X, Copilot+ PCs). ``platform.machine()``
        # on Windows 11 ARM64 returns ``"ARM64"`` which .lower() normalises
        # to ``"arm64"``. We don't have a dedicated Target yet — surface the
        # gap explicitly instead of silently falling through to the generic
        # RuntimeError below, so Rove users on these boxes know what to do.
        if machine in ("arm64", "aarch64"):
            raise RuntimeError(
                "Windows ARM64 hosts are detected but not yet a supported "
                "Rove build target. Run rove under x86_64 emulation via "
                "Prism, or produce bundles on a Linux/macOS CI runner."
            )

    raise RuntimeError(
        f"Unsupported host platform: system={system!r} machine={machine!r}. "
        "Cross-platform builds must be produced on a CI runner with the "
        "matching target toolchain."
    )


def parse(value: str) -> Target:
    """Parse a string into a :class:`Target`.

    Accepts the canonical hyphenated form (``"linux-x86_64"``), the
    underscore form (``"linux_x86_64"``), and a curated set of common
    aliases (``"linux-x64"``, ``"android-aarch64"``, ``"win-amd64"``,
    ``"host"``, ...). Matching is case-insensitive.

    Args:
        value: The string to parse.

    Returns:
        The matching :class:`Target` member.

    Raises:
        ValueError: if ``value`` is empty or does not match any known
            target or alias. The error message lists the canonical
            target values to aid the user.
    """
    if not isinstance(value, str) or not value.strip():
        raise ValueError("target string must be a non-empty str")

    normalized = value.strip().lower().replace("-", "_")
    target = _ALIASES.get(normalized)
    if target is not None:
        return target

    valid = ", ".join(sorted(t.value for t in Target))
    raise ValueError(
        f"unknown target {value!r}; expected one of: {valid} "
        "(hyphens or underscores accepted; see rove.targets._ALIASES "
        "for the full alias list)"
    )


def resolve(target: Target) -> Target:
    """Resolve a possibly-sentinel target to a concrete target.

    If ``target`` is :attr:`Target.host`, returns the result of
    :func:`detect_host`. Otherwise returns ``target`` unchanged. Use
    this at the boundary of any code path that needs a concrete target
    (manifest construction, tarball naming, signing payload, ...).

    Args:
        target: A :class:`Target` value, possibly the ``host`` sentinel.

    Returns:
        A concrete :class:`Target` (never :attr:`Target.host`).
    """
    if target is Target.host:
        return detect_host()
    return target
